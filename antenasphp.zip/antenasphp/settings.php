<?php

require_once(__DIR__ . '/database/Parameters.php');

$dbParameters = new api\database\Parameters();
/*
$dbParameters->server = "localhost";
$dbParameters->user = "root";
$dbParameters->password = "Santi693";
$dbParameters->schema = "antenas";
*/
$dbParameters->server = "160.153.154.161";
$dbParameters->user = "antenas";
$dbParameters->password = "Colombia2021";
$dbParameters->schema = "antenas";

