<?php
require_once(__DIR__ . '/business/Sector.php');
include_once(__DIR__ . "/settings.php");

$entity = new api\business\Sector($dbParameters);
$aux = $entity->list(0, 100);
$rs = $aux["data"];
?>
<html>
    <head>
        <title>Mapa de ubicación de las antenas</title>
        <style>
            #map {
                width: 800px;
                height: 600px;
            }
        </style>
    </head>
    <body>
        <div id="map"></div>
        <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAY45f1MRO_DRPdtzO49_iFH05Lk7WIDus&callback=initMap"
            defer>
        </script>
        <script>
            function initMap() {
                const map = new google.maps.Map(document.getElementById("map"), {
                    zoom: 6,
                    center: {lat: 4.169556, lng: -73.545750}
                });

<?php foreach ($rs as $row) { ?>
                    const infowindow<?php echo($row->id) ?> = new google.maps.InfoWindow({
                        content: "<div id='content'>" +
                                "<table>" +
                                "<tr>" +
                                "<td><b>Nombre:</b></td>" +
                                "<td><?php echo($row->name) ?></td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td colspan='2'><i>Anterior</i></td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td><b>Altura:</b></td>" +
                                "<td><?php echo($row->altitudeBefore) ?></td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td><b>Azimuth:</b></td>" +
                                "<td><?php echo($row->altitudeBefore) ?></td>" +
                                "</tr>" +
                                "<td colspan='2'><i>Posterior</i></td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td><b>Altura:</b></td>" +
                                "<td><?php echo($row->altitudeAfter) ?></td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td><b>Azimuth:</b></td>" +
                                "<td><?php echo($row->altitudeAfter) ?></td>" +
                                "</tr>" +
                                "</table>" +
                                "</div>"
                    });
                    const marker<?php echo($row->id) ?> = new google.maps.Marker({
                        position: {lat: <?php echo($row->latitude) ?>, lng: <?php echo($row->longitude) ?>},
                        map: map
                    });

                    marker<?php echo($row->id) ?>.addListener("click", () => {
                        infowindow<?php echo($row->id) ?>.open(map, marker<?php echo($row->id) ?>);
                    });
<?php } ?>
            }
        </script>
    </body>
</html>
