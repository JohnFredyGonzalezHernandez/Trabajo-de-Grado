<?php

namespace api\entities;

require_once(__DIR__ . "/Enb.php");
require_once(__DIR__ . "/Aerial.php");

/**
 * Sector del enb al que se le hace mantenimiento
 * 
 * @property int $id Identificador del sector
 * @property Enb $enb Enb al que pertenece el sector
 * @property string $name Nombre del sector
 * @property boolean $type Tipo de sector
 * @property int $altitudeBefore Altitud antes del mantenimiento
 * @property int $azimuthBefore Azimuth antes del mantenimiento
 * @property int $electricTiltBefore Inclinación eléctrica antes del mantenimiento
 * @property int $mechanicalTiltBefore Inclinación mecánica antes del mantenimiento
 * @property int $altitudeAfter Altitud después del mantenimiento
 * @property int $azimuthAfter Azimuth después del mantenimiento
 * @property int $electricTiltAfter Inclinación eléctrica después del mantenimiento
 * @property int $mechanicalTiltAfter Inclinación mecánica después del mantenimiento
 * @property Aerial $aerial Tipo de antena a la que se le hace mantenimiento
 * @property string $gnetTrack Ruta de la imagen con los valores tomados de la aplicación GNET
 * @property string $orientationBefore Ruta de la imagen de la orientación antes del mantenimiento
 * @property string $orientationEarthBefore Ruta de la imagen de la orientación antes del mantenimiento de la aplicación Google Earth
 * @property string $orientationAfter Ruta de la imagen de la orientación después del mantenimiento
 * @property string $orientationEarthAfter Ruta de la imagen de la orientación después del mantenimiento de la aplicación Google Earth
 * @property float $latitude Latitud geográfica donde se ubica el sector
 * @property float $longitude Longitud geográfica donde se ubica el sector
 * @author Leandro Baena Torres
 */
class Sector implements \JsonSerializable {
    //<editor-fold desc="Constructores" defaultstate="collapsed">

    /**
     * Crea un nuevo sector con un determinado identificador
     * @param int $id Identificador del sector
     */
    public function __construct($id = 0) {
        $this->id = $id;
        $this->enb = new Enb();
        $this->name = "";
        $this->type = false;
        $this->altitudeBefore = 0;
        $this->azimuthBefore = 0;
        $this->electricTiltBefore = 0;
        $this->mechanicalTiltBefore = 0;
        $this->altitudeAfter = 0;
        $this->azimuthAfter = 0;
        $this->electricTiltAfter = 0;
        $this->mechanicalTiltAfter = 0;
        $this->aerial = new Aerial();
        $this->gnetTrack = "";
        $this->orientationBefore = "";
        $this->orientationEarthBefore = "";
        $this->orientationAfter = "";
        $this->orientationEarthAfter = "";
        $this->latitude = 0;
        $this->longitude = 0;
    }

    //</editor-fold>
    //<editor-fold desc="Métodos" defaultstate="collapsed">

    /**
     * Trae un atributo
     *
     * @param string $field Atributo a traerle el valor
     * @return mixed Valor del atributo
     */
    public function __get($field) {
        return $this->$field;
    }

    /**
     * Cambia el valor de un atributo
     *
     * @param string $field Atributo a cambiarle el valor
     * @param mixed $value Nuevo valor del atributo
     */
    public function __set($field, $value) {
        $this->$field = $value;
    }

    /**
     * Serializa el objeto
     * @return string
     */
    public function jsonSerialize() {
        return ['id' => $this->id,
            'enb' => $this->enb,
            'name' => $this->name,
            'type' => $this->type,
            'altitudeBefore' => $this->altitudeBefore,
            'azimuthBefore' => $this->azimuthBefore,
            'electricTiltBefore' => $this->electricTiltBefore,
            'mechanicalTiltBefore' => $this->mechanicalTiltBefore,
            'altitudeAfter' => $this->altitudeAfter,
            'azimuthAfter' => $this->azimuthAfter,
            'electricTiltAfter' => $this->electricTiltAfter,
            'mechanicalTiltAfter' => $this->mechanicalTiltAfter,
            'aerial' => $this->aerial,
            'gnetTrack' => $this->gnetTrack,
            'orientationBefore' => $this->orientationBefore,
            'orientationEarthBefore' => $this->orientationEarthBefore,
            'orientationAfter' => $this->orientationAfter,
            'orientationEarthAfter' => $this->orientationEarthAfter,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude
        ];
    }

    //</editor-fold>
    //<editor-fold desc="Atributos" defaultstate="collapsed">

    /**
     * Identificador del sector
     * @var int
     */
    private $id;

    /**
     * Enb al que pertenece el sector
     * @var Enb
     */
    private $enb;

    /**
     * Nombre del sector
     * @var string
     */
    private $name;

    /**
     * Tipo de sector
     * @var boolean
     */
    private $type;

    /**
     * Altitud antes del mantenimiento
     * @var int
     */
    private $altitudeBefore;

    /**
     * Azimuth antes del mantenimiento
     * @var int
     */
    private $azimuthBefore;

    /**
     * Inclinación eléctrica antes del mantenimiento
     * @var int
     */
    private $electricTiltBefore;

    /**
     * Inclinación mecánica antes del mantenimiento
     * @var int
     */
    private $mechanicalTiltBefore;

    /**
     * Altitud después del mantenimiento
     * @var int
     */
    private $altitudeAfter;

    /**
     * Azimuth después del mantenimiento
     * @var int
     */
    private $azimuthAfter;

    /**
     * Inclinación eléctrica después del mantenimiento
     * @var int
     */
    private $electricTiltAfter;

    /**
     * Inclinación mecánica después del mantenimiento
     * @var int
     */
    private $mechanicalTiltAfter;

    /**
     * Tipo de antena a la que se le hace mantenimiento
     * @var Aerial
     */
    private $aerial;

    /**
     * Ruta de la imagen con los valores tomados de la aplicación GNET
     * @var string
     */
    private $gnetTrack;

    /**
     * Ruta de la imagen de la orientación antes del mantenimiento
     * @var string
     */
    private $orientationBefore;

    /**
     * Ruta de la imagen de la orientación antes del mantenimiento de la
     * aplicación Google Earth
     * @var string
     */
    private $orientationEarthBefore;

    /**
     * Ruta de la imagen de la orientación después del mantenimiento
     * @var string
     */
    private $orientationAfter;

    /**
     * Ruta de la imagen de la orientación después del mantenimiento de la
     * aplicación Google Earth
     * @var string
     */
    private $orientationEarthAfter;

    /**
     * Latitud geográfica donde se ubica el sector
     * @var float
     */
    private $latitude;

    /**
     * Longitud geográfica donde se ubica el sector
     * @var float
     */
    private $longitude;

    //</editor-fold>
}
