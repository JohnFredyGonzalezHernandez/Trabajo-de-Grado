<?php

namespace api\entities;

require_once(__DIR__ . "/Regional.php");

/**
 * Ciudad donde se ubica una antena
 * 
 * @property int $id Identificador de la ciudad
 * @property string $name Nombre de la ciudad
 * @property Regional $regional Regional a la que pertenece la ciudad
 * @author Leandro Baena Torres
 */
class City implements \JsonSerializable {
    //<editor-fold desc="Constructores" defaultstate="collapsed">

    /**
     * Crea una nueva ciudad con un determinado identificador
     * @param int $id Identificador de la ciudad
     */
    public function __construct($id = 0) {
        $this->id = $id;
        $this->name = "";
        $this->regional = new Regional();
    }

    //</editor-fold>
    //<editor-fold desc="Métodos" defaultstate="collapsed">

    /**
     * Trae un atributo
     *
     * @param string $field Atributo a traerle el valor
     * @return mixed Valor del atributo
     */
    public function __get($field) {
        return $this->$field;
    }

    /**
     * Cambia el valor de un atributo
     *
     * @param string $field Atributo a cambiarle el valor
     * @param mixed $value Nuevo valor del atributo
     */
    public function __set($field, $value) {
        $this->$field = $value;
    }

    /**
     * Serializa el objeto
     * @return string
     */
    public function jsonSerialize() {
        return ['id' => $this->id, 'name' => $this->name, 'regional' => $this->regional];
    }

    //</editor-fold>
    //<editor-fold desc="Atributos" defaultstate="collapsed">

    /**
     * Identificador de la ciudad
     * @var int
     */
    private $id;

    /**
     * Nombre de la ciudad
     * @var string
     */
    private $name;

    /**
     * Regional a la que pertenece la ciudad
     * @var Regional
     */
    private $regional;

    //</editor-fold>
}
