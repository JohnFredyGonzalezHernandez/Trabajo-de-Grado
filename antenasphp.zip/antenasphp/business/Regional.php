<?php

namespace api\business;

require_once(__DIR__ . "/../database/Regional.php");
require_once(__DIR__ . "/../database/Parameters.php");

use api\database\Regional as DbMgr;
use api\entities\Regional as Entity;
use api\database\Parameters;
use api\database\Database;

/**
 * Lógica de negocio para las regionales
 *
 * @author Leandro Baena
 */
class Regional {
    //<editor-fold defaultstate="collapsed" desc="Constructores">

    /**
     * Inicializa la conexión a la base de datos
     * @param Parameters $parameters Parámetros de conexión a la base de datos
     */
    public function __construct($parameters) {
        $this->connection = new Database($parameters->server, $parameters->user, $parameters->password, $parameters->schema);
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae el listado de regionales
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de regionales leidos
     */
    public function list($start, $offset) {
        $dbMgr = new DbMgr();
        $list = $dbMgr->list($this->connection, $start, $offset);
        return $list;
    }

    /**
     * Trae una regional
     * @param int $id Identificador de la regional que se quiere leer
     * @return Entity Regional leida
     */
    public function read($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        return $dbMgr->read($this->connection, $entity);
    }

    /**
     * Crea una regional
     * @param string $name Nombre de la regional que se quiere crear
     * @return Entity Regional creada
     */
    public function insert($name) {
        $dbMgr = new DbMgr();
        $entity = new Entity();
        $entity->name = $name;
        return $dbMgr->insert($this->connection, $entity);
    }

    /**
     * Actualiza una regional
     * @param int $id Identificador de la regional que se quiere actualizar
     * @param string $name Nombre de la ciudad que se quiere actualizar
     * @return Entity Regional actualizada
     */
    public function update($id, $name) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $entity->name = $name;
        return $dbMgr->update($this->connection, $entity);
    }

    /**
     * Elimina una regional
     * @param int $id Identificador de la regional que se quiere eliminar
     * @return Entity Regional eliminada
     */
    public function delete($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $dbMgr->delete($this->connection, $entity);
        return $entity;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Atributos">

    /**
     * Conexión a la base de datos
     * @var Database Conexión a la base de datos
     */
    private $connection;

    //</editor-fold>
}
