<?php

namespace api\business;

require_once(__DIR__ . "/../database/Sector.php");
require_once(__DIR__ . "/../database/Parameters.php");

use api\database\Sector as DbMgr;
use api\entities\Sector as Entity;
use api\database\Parameters;
use api\database\Database;

/**
 * Lógica de negocio para los sectores
 *
 * @author Leandro Baena
 */
class Sector {
    //<editor-fold defaultstate="collapsed" desc="Constructores">

    /**
     * Inicializa la conexión a la base de datos
     * @param Parameters $parameters Parámetros de conexión a la base de datos
     */
    public function __construct($parameters) {
        $this->connection = new Database($parameters->server, $parameters->user, $parameters->password, $parameters->schema);
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae el listado de sectores
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de sectores leidos
     */
    public function list($start, $offset) {
        $dbMgr = new DbMgr();
        $list = $dbMgr->list($this->connection, $start, $offset);
        return $list;
    }

    /**
     * Trae un sector
     * @param int $id Identificador del sector que se quiere leer
     * @return Entity Sector leido
     */
    public function read($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        return $dbMgr->read($this->connection, $entity);
    }

    /**
     * Crea un sector
     * @param int $enb Identificador del enb al que pertenece el sector que se quiere crear
     * @param string $name Nombre del sector que se quiere crear
     * @param boolean $type Tipo de sector que se quiere crear
     * @param int $altitudeBefore
     * @param int $azimuthBefore
     * @param int $electricTiltBefore
     * @param int $mechanicalTiltBefore
     * @param int $altitudeAfter
     * @param int $azimuthAfter
     * @param int $electricTiltAfter
     * @param int $mechanicalTiltAfter
     * @param int $aerial
     * @param string $gnetTrack
     * @param string $orientationBefore
     * @param string $orientationEarthBefore
     * @param string $orientationAfter
     * @param string $orientationEarthAfter
     * @param float $latitude
     * @param float $longitude
     * @return Entity Sector creado
     */
    public function insert($enb, $name, $type,
            $altitudeBefore, $azimuthBefore, $electricTiltBefore,
            $mechanicalTiltBefore, $altitudeAfter, $azimuthAfter,
            $electricTiltAfter, $mechanicalTiltAfter, $aerial,
            $gnetTrack, $orientationBefore, $orientationEarthBefore,
            $orientationAfter, $orientationEarthAfter, $latitude,
            $longitude) {
        $dbMgr = new DbMgr();
        $entity = new Entity();
        $entity->enb = new \api\entities\Enb($enb);
        $entity->name = $name;
        $entity->type = $type;
        $entity->altitudeBefore = $altitudeBefore;
        $entity->azimuthBefore = $azimuthBefore;
        $entity->electricTiltBefore = $electricTiltBefore;
        $entity->mechanicalTiltBefore = $mechanicalTiltBefore;
        $entity->altitudeAfter = $altitudeAfter;
        $entity->azimuthAfter = $azimuthAfter;
        $entity->electricTiltAfter = $electricTiltAfter;
        $entity->mechanicalTiltAfter = $mechanicalTiltAfter;
        $entity->aerial = new \api\entities\Aerial($aerial);
        $entity->gnetTrack = $gnetTrack;
        $entity->orientationBefore = $orientationBefore;
        $entity->orientationEarthBefore = $orientationEarthBefore;
        $entity->orientationAfter = $orientationAfter;
        $entity->orientationEarthAfter = $orientationEarthAfter;
        $entity->latitude = $latitude;
        $entity->longitude = $longitude;
        return $dbMgr->insert($this->connection, $entity);
    }

    /**
     * Actualiza un sector
     * @param int $id Identificador del sector que se quiere actualizar
     * @param int $enb Identificador del enb al que pertenece el sector que se quiere crear
     * @param string $name Nombre del sector que se quiere crear
     * @param boolean $type Tipo de sector que se quiere crear
     * @param int $altitudeBefore
     * @param int $azimuthBefore
     * @param int $electricTiltBefore
     * @param int $mechanicalTiltBefore
     * @param int $altitudeAfter
     * @param int $azimuthAfter
     * @param int $electricTiltAfter
     * @param int $mechanicalTiltAfter
     * @param int $aerial
     * @param string $gnetTrack
     * @param string $orientationBefore
     * @param string $orientationEarthBefore
     * @param string $orientationAfter
     * @param string $orientationEarthAfter
     * @param float $latitude
     * @param float $longitude
     * @return Entity Sector actualizado
     */
    public function update($id, $enb, $name, $type,
            $altitudeBefore, $azimuthBefore, $electricTiltBefore,
            $mechanicalTiltBefore, $altitudeAfter, $azimuthAfter,
            $electricTiltAfter, $mechanicalTiltAfter, $aerial,
            $gnetTrack, $orientationBefore, $orientationEarthBefore,
            $orientationAfter, $orientationEarthAfter, $latitude,
            $longitude) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $entity->enb = new \api\entities\Enb($enb);
        $entity->name = $name;
        $entity->type = $type;
        $entity->altitudeBefore = $altitudeBefore;
        $entity->azimuthBefore = $azimuthBefore;
        $entity->electricTiltBefore = $electricTiltBefore;
        $entity->mechanicalTiltBefore = $mechanicalTiltBefore;
        $entity->altitudeAfter = $altitudeAfter;
        $entity->azimuthAfter = $azimuthAfter;
        $entity->electricTiltAfter = $electricTiltAfter;
        $entity->mechanicalTiltAfter = $mechanicalTiltAfter;
        $entity->aerial = new \api\entities\Aerial($aerial);
        $entity->gnetTrack = $gnetTrack;
        $entity->orientationBefore = $orientationBefore;
        $entity->orientationEarthBefore = $orientationEarthBefore;
        $entity->orientationAfter = $orientationAfter;
        $entity->orientationEarthAfter = $orientationEarthAfter;
        $entity->latitude = $latitude;
        $entity->longitude = $longitude;
        return $dbMgr->update($this->connection, $entity);
    }

    /**
     * Elimina un sector
     * @param int $id Identificador del sector que se quiere eliminar
     * @return Entity Sector eliminado
     */
    public function delete($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $dbMgr->delete($this->connection, $entity);
        return $entity;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Atributos">

    /**
     * Conexión a la base de datos
     * @var Database Conexión a la base de datos
     */
    private $connection;

    //</editor-fold>
}
