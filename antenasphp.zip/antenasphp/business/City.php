<?php

namespace api\business;

require_once(__DIR__ . "/../database/City.php");
require_once(__DIR__ . "/../database/Parameters.php");

use api\database\City as DbMgr;
use api\entities\City as Entity;
use api\database\Parameters;
use api\database\Database;

/**
 * Lógica de negocio para las ciudades
 *
 * @author Leandro Baena
 */
class City {
    //<editor-fold defaultstate="collapsed" desc="Constructores">

    /**
     * Inicializa la conexión a la base de datos
     * @param Parameters $parameters Parámetros de conexión a la base de datos
     */
    public function __construct($parameters) {
        $this->connection = new Database($parameters->server, $parameters->user, $parameters->password, $parameters->schema);
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae el listado de ciudades
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de ciudades leidos
     */
    public function list($start, $offset) {
        $dbMgr = new DbMgr();
        $list = $dbMgr->list($this->connection, $start, $offset);
        return $list;
    }

    /**
     * Trae una ciudad
     * @param int $id Identificador de la ciudad que se quiere leer
     * @return Entity Ciudad leida
     */
    public function read($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        return $dbMgr->read($this->connection, $entity);
    }

    /**
     * Crea una ciudad
     * @param string $name Nombre de la ciudad que se quiere crear
     * @param int $regional Identificador de la regional a la que pertenece la ciudad que se quiere crear
     * @return Entity Ciudad creado
     */
    public function insert($name, $regional) {
        $dbMgr = new DbMgr();
        $entity = new Entity();
        $entity->name = $name;
        $entity->regional = new \api\entities\Regional($regional);
        return $dbMgr->insert($this->connection, $entity);
    }

    /**
     * Actualiza una ciudad
     * @param int $id Identificador de la ciudad que se quiere actualizar
     * @param string $name Nombre de la ciudad que se quiere actualizar
     * @param int $regional identificador de la regional a la que pertenece la ciudad que se quiere actualizar
     * @return Entity Ciudad actualizado
     */
    public function update($id, $name, $regional) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $entity->name = $name;
        $entity->regional = new \api\entities\Regional($regional);
        return $dbMgr->update($this->connection, $entity);
    }

    /**
     * Elimina una ciudad
     * @param int $id Identificador de la ciudad que se quiere eliminar
     * @return Entity Ciudad eliminada
     */
    public function delete($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $dbMgr->delete($this->connection, $entity);
        return $entity;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Atributos">

    /**
     * Conexión a la base de datos
     * @var Database Conexión a la base de datos
     */
    private $connection;

    //</editor-fold>
}
