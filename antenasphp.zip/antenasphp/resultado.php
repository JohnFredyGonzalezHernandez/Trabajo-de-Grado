<?php
require_once(__DIR__ . '/business/Sector.php');
include_once(__DIR__ . "/settings.php");

$entity = new api\business\Sector($dbParameters);
$aux = $entity->list(0, 100);
$rs = $aux["data"];
?>
<html>
    <head>
        <title>Listado de datos de la aplicación</title>
        <style>
            table, tr, th, td {
                border: 1px solid #EAEAEA;
                padding: 0px;
                margin: 0px;
            }
        </style>
    </head>
    <body>
        <table>
            <thead>
                <tr>
                    <th rowspan="2">ID</th>
                    <th colspan="13">ENB</th>
                    <th rowspan="2">Nombre sector</th>
                    <th rowspan="2">Tipo</th>
                    <th colspan="6">Anterior</th>
                    <th colspan="6">Posterior</th>
                    <th>Tipo de antena</th>
                    <th rowspan="2">Imagen GNET</th>
                    <th rowspan="2">Latitud</th>
                    <th rowspan="2">Longitud</th>
                </tr>
                <tr>
                    <th>Nombre</th>
                    <th>Código</th>
                    <th>Dirección</th>
                    <th>Ciudad</th>
                    <th>Regional</th>
                    <th>Llaves</th>
                    <th>Solicitado por</th>
                    <th>Fecha solicitud</th>
                    <th>Ejecutado por</th>
                    <th>Fecha ejecución</th>
                    <th>Motivo</th>
                    <th>Observaciones técnicas</th>
                    <th>Observaciones logísticas</th>
                    <th>Altitud</th>
                    <th>Azimuth</th>
                    <th>Inclinación eléctrica</th>
                    <th>Inclinación mecánica</th>
                    <th>Imagen orientación</th>
                    <th>Imagen orientación Google Earth</th>
                    <th>Altitud </th>
                    <th>Azimuth</th>
                    <th>Inclinación eléctrica</th>
                    <th>Inclinación mecánica</th>
                    <th>Imagen orientación</th>
                    <th>Imagen orientación Google Earth</th>
                    <th>antena</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rs as $row) { ?>
                    <tr>
                        <td><?php echo($row->id) ?></td>
                        <td><?php echo($row->enb->name) ?></td>
                        <td><?php echo($row->enb->code) ?></td>
                        <td><?php echo($row->enb->address) ?></td>
                        <td><?php echo($row->enb->city->name) ?></td>
                        <td><?php echo($row->enb->city->regional->name) ?></td>
                        <td><?php echo($row->enb->keys) ?></td>
                        <td><?php echo($row->enb->requestEng) ?></td>
                        <td><?php echo($row->enb->requestDate)->format("Y-m-d") ?></td>
                        <td><?php echo($row->enb->executeEng) ?></td>
                        <td><?php echo($row->enb->executeDate)->format("Y-m-d") ?></td>
                        <td><?php echo($row->enb->reason) ?></td>
                        <td><?php echo($row->enb->tecObservations) ?></td>
                        <td><?php echo($row->enb->logObservations) ?></td>
                        <td><?php echo($row->name) ?></td>
                        <td><?php echo($row->type ? "AWS" : "ATP") ?></td>
                        <td><?php echo($row->altitudeBefore) ?></td>
                        <td><?php echo($row->azimuthBefore) ?></td>
                        <td><?php echo($row->electricTiltBefore) ?></td>
                        <td><?php echo($row->mechanicalTiltBefore) ?></td>
                        <td><?php echo("<img src=\"images/" . $row->orientationBefore . "\" width=50 height=50 />"); ?></td>
                        <td><?php echo("<img src=\"images/" . $row->orientationEarthBefore . "\" width=50 height=50 />"); ?></td>
                        <td><?php echo($row->altitudeAfter) ?></td>
                        <td><?php echo($row->azimuthAfter) ?></td>
                        <td><?php echo($row->electricTiltAfter) ?></td>
                        <td><?php echo($row->mechanicalTiltAfter) ?></td>
                        <td><?php echo("<img src=\"images/" . $row->orientationAfter . "\" width=50 height=50 />"); ?></td>
                        <td><?php echo("<img src=\"images/" . $row->orientationEarthAfter . "\" width=50 height=50 />"); ?></td>
                        <td><?php echo($row->aerial->name) ?></td>
                        <td><?php echo("<img src=\"images/" . $row->gnetTrack . "\" width=50 height=50 />"); ?></td>
                        <td><?php echo($row->latitude) ?></td>
                        <td><?php echo($row->longitude) ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </body>
</html>