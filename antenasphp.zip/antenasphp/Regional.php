<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization");
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

require_once(__DIR__ . '/business/Regional.php');

include_once(__DIR__ . "/settings.php");

if (is_string($_SERVER["REQUEST_METHOD"])) {
    $requestMethod = $_SERVER["REQUEST_METHOD"];
    if ($requestMethod == "OPTIONS") {
        http_response_code(200);
    } else {
        try {
            $entity = new api\business\Regional($dbParameters);
        } catch (Exception $e) {
            echo($e->getMessage());
        }
        if (is_string($_SERVER["REQUEST_METHOD"])) {
            $requestMethod = $_SERVER["REQUEST_METHOD"];
            switch ($requestMethod) {
                case "GET"://Consultar
                    $pageNumber = 0;
                    $pageSize = 25;
                    $start = 0;
                    if (isset($_GET["pageNumber"])) {
                        $pageNumber = $_GET["pageNumber"];
                        $start = $pageNumber * $pageSize;
                    }
                    if (isset($_GET["pageSize"])) {
                        $offset = $_GET["pageSize"];
                    }
                    if (!isset($_GET["id"])) { //Todos las regionales
                        http_response_code(200);
                        $rs = $entity->list($start, $pageSize);
                    } else { //Una sola regional
                        $id = (int) $_GET["id"];
                        $rs = $entity->read($id);
                        if ($rs->name != "") {
                            http_response_code(200);
                        } else {
                            http_response_code(404);
                            $rs = "Regional no encontrada";
                        }
                    }
                    break;
                case "POST"://Insertar
                    $data = json_decode(file_get_contents('php://input'));
                    if (isset($data)) {
                        http_response_code(201);
                        $rs = $entity->insert($data->name);
                    } else {
                        http_response_code(400);
                        $rs = "Datos inválidos";
                    }
                    break;
                case "PUT"://Actualizar
                    $data = json_decode(file_get_contents('php://input'));
                    if (isset($data)) {
                        $aux = $entity->read($data->id);
                        if ($aux->name == "") {
                            http_response_code(404);
                            $rs = "Regional no encontrada";
                        } else {
                            $rs = $entity->update($data->id, $data->name);
                            http_response_code(200);
                        }
                    } else {
                        http_response_code(400);
                        $rs = "Datos inválidos";
                    }
                    break;
                case "DELETE"://Eliminar
                    if (!isset($_GET["id"])) {
                        http_response_code(400);
                        $rs = "Datos inválidos";
                    } else {
                        $id = (int) $_GET["id"];
                        $aux = $entity->read($id);
                        if ($aux->name == "") {
                            http_response_code(404);
                            $rs = "Regional no encontrada";
                        } else {
                            $rs = $entity->delete($id);
                            http_response_code(200);
                        }
                    }
                    break;
                default:
                    http_response_code(405);
                    $rs = "Método no disponible";
                    break;
            }
        } else {
            http_response_code(405);
            $rs = "Método no disponible";
        }
    }
} else {
    http_response_code(405);
    $rs = "Método no disponible";
}
echo json_encode($rs);
