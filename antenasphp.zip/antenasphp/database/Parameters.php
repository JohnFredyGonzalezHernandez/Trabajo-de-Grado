<?php

namespace api\database;

/**
 * Parametros de conexión a la base de datos
 *
 * @property string $server Ip o nombre del servidor de base de datos
 * @property string $user Usuario con que se conecta a la base de datos
 * @property string $password Contraseña con que se conecta a la base de datos
 * @property string $schema Base de datos a la que se conecta
 * @author Leandro Baena
 */
class Parameters {
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae el valor de un atributo de la clase
     * @param string $field Nombre del atributo que se quiere traer
     * @return mixed
     */
    public function __get($field) {
        return $this->$field;
    }

    /**
     * Cambia el valor de un atributo de la clase
     * @param string $field Nombre del atriibuto a cambiar
     * @param mixed $value Nuevo valor del atributo
     */
    public function __set($field, $value) {
        $this->$field = $value;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Atributos">

    /**
     * Ip o nombre del servidor de base de datos
     * @var string
     */
    private $server;

    /**
     * Usuario con que se conecta a la base de datos
     * @var string
     */
    private $user;

    /**
     * Contraseña con que se conecta a la base de datos
     * @var string
     */
    private $password;

    /**
     * Base de datos a la que se conecta
     * @var string
     */
    private $schema;

    //</editor-fold>
}
