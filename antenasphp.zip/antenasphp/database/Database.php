<?php

namespace api\database;

/**
 * Conexión a la base de datos
 *
 * @author Leandro Baena Torres
 */
class Database {
    // <editor-fold defaultstate="collapsed" desc="Constructores">

    /**
     * Crea una conexión a la base de datos
     * @param string $server Servidor al que se conecta
     * @param string $user usuario con el que se desa conectar
     * @param string $password Contraseña con la que se desea conectar
     * @param string $schema Esquema al que se desea conectar
     * @throws BDException Si no conecta al motor de base de datos
     */
    public function __construct($server, $user, $password, $schema) {
        $this->server = $server;
        $this->user = $user;
        $this->password = $password;
        $this->schema = $schema;
        if (!class_exists("\\mysqli")) {
            throw new \Exception("PHP no tiene soporte para MySQLi", 0);
        }
        $this->link = new \mysqli($this->server, $this->user, $this->password, $this->schema);
        if (\mysqli_connect_errno()) {
            throw new \Exception(\mysqli_connect_error(), \mysqli_connect_errno());
        } else {
            $this->link->set_charset("utf8");
        }
    }

    // </editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae el resultado de una consulta
     * @param string $sql Consulta enviada a la base de datos
     * @return array Listado de objetos resultado de la consulta
     * @throws \Exception Si hubo un error al realizar la consulta
     */
    public function select($sql) {
        $rs = $this->link->query($sql);
        if ($rs == null) {
            throw new \Exception($this->link->error, $sql);
        } else {
            $list = array();
            while ($row = $rs->fetch_object()) {
                array_push($list, $row);
            }
            $rs->close();
            return $list;
        }
    }

    /**
     * Inserta un registro en una tabla
     * @param string $sql Sentencia de inserción enviada a la base de datos
     * @return int Id autogenerado por la inserción
     * @throws \Exception Si hubo un error al realizar la consulta
     */
    public function insert($sql) {
        $this->link->query($sql);
        return $this->link->insert_id;
    }

    /**
     * Actualiza un registro en una tabla
     * @param string $sql Sentencia de actualización enviada a la base de datos
     * @throws \Exception Si hubo un error al realizar la consulta
     */
    public function update($sql) {
        $this->link->query($sql);
    }

    /**
     * Elimina un registro en una tabla
     * @param string $sql Sentencia de eliminación enviada a la base de datos
     * @throws \Exception Si hubo un error al realizar la consulta
     */
    public function delete($sql) {
        $this->link->query($sql);
    }

    //</editor-fold>
    // <editor-fold defaultstate="collapsed" desc="Atributos">

    /**
     * Conexión física a la base de datos
     * @var mixed
     */
    protected $link = null;

    /**
     * IP o nombre del servidor de base de datos
     * @var string
     */
    protected $server;

    /**
     * Usuario de acceso al servidor de base de datos
     * @var string
     */
    protected $user;

    /**
     * Clave de acceso al servidor de base de datos
     * @var string
     */
    protected $password;

    /**
     * Base de datos a la que se conectara en el servidor de base de datos
     * @var string
     */
    protected $schema;

    // </editor-fold>
}
