<?php

namespace api\database;

require_once(__DIR__ . '/Database.php');
require_once(__DIR__ . '/../entities/Aerial.php');

use api\database\Database;
use api\entities\Aerial as Entity;

/**
 * Permite la manipulación de los tipos de antenas en la base de datos
 *
 * @author Leandro Baena
 */
class Aerial {
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae todos los tipos de antenas
     * @param Database $database Conexión a la base de datos
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de tipos de antenas
     */
    public function list($database, $start, $offset) {
        $total = 0;
        $list = array();
        $rs = $database->select("SELECT aerial_id, name FROM aerial LIMIT $start, $offset");
        foreach ($rs as $row) {
            $entity = new Entity((int)$row->aerial_id);
            $entity->name = $row->name;
            array_push($list, $entity);
        }
        $rsTotal = $database->select("SELECT COUNT(aerial_id) AS total FROM aerial");
        foreach ($rsTotal as $row) {
            $total = (int)$row->total;
        }
        return ["data" => $list, "total" => $total];
    }

    /**
     * Trae un tipo de antena
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Tipo de antena que se quiere leer
     * @return Entity Tipo de antena leido
     */
    public function read($database, $entity) {
        $sql = "SELECT name FROM aerial WHERE aerial_id = $entity->id";
        $rs = $database->select($sql);
        foreach ($rs as $row) {
            $entity->name = $row->name;
        }
        return $entity;
    }

    /**
     * Crea un tipo de antena
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Tipo de antena que se quiere crear
     * @return Entity Tipo de antena creado
     */
    public function insert($database, $entity) {
        $rs = $database->insert("INSERT INTO aerial (name) VALUES ('$entity->name')");
        $entity->id = $rs;
        return $entity;
    }

    /**
     * Actualiza un tipo de antena
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Tipo de antena que se quiere actualizar
     * @return Entity Tipo de antena actualizado
     */
    public function update($database, $entity) {
        $database->update("UPDATE aerial SET name = '$entity->name' WHERE aerial_id = $entity->id");
        return $entity;
    }

    /**
     * Elimina un tipo de antena
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Tipo de antena que se quiere eliminar
     * @return Entity Tipo de antena eliminado
     */
    public function delete($database, $entity) {
        $database->delete("DELETE FROM aerial WHERE aerial_id = $entity->id");
        return $entity;
    }

    //</editor-fold>
}
