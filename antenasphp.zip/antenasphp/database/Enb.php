<?php

namespace api\database;

require_once(__DIR__ . '/Database.php');
require_once(__DIR__ . '/../entities/Enb.php');

use api\database\Database;
use api\entities\Enb as Entity;

/**
 * Permite la manipulación de los enb en la base de datos
 *
 * @author Leandro Baena
 */
class Enb {
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae todos los enb
     * @param Database $database Conexión a la base de datos
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de enb
     */
    public function list($database, $start, $offset) {
        $total = 0;
        $list = array();
        $rs = $database->select(
                "SELECT "
                . "e.enb_id, e.name, e.code, "
                . "e.address, c.city_id, c.name as city, "
                . "r.regional_id, r.name as regional, e.keys, "
                . "e.request_eng, e.request_date, e.execute_eng, "
                . "e.execute_date, e.reason, e.tec_observations, "
                . "e.log_observations "
                . "FROM enb e "
                . "INNER JOIN city c ON e.city_id = c.city_id "
                . "INNER JOIN regional r ON c.regional_id = r.regional_id "
                . "LIMIT $start, $offset");
        foreach ($rs as $row) {
            $entity = new Entity((int) $row->enb_id);
            $entity->name = $row->name;
            $entity->code = $row->code;
            $entity->address = $row->address;
            $entity->city = new \api\entities\City((int) $row->city_id);
            $entity->city->name = $row->city;
            $entity->city->regional = new \api\entities\Regional((int) $row->regional_id);
            $entity->city->regional->name = $row->regional;
            $entity->keys = $row->keys;
            $entity->requestEng = $row->request_eng;
            $entity->requestDate = \DateTime::createFromFormat("Y-m-d", $row->request_date);
            $entity->executeEng = $row->execute_eng;
            $entity->executeDate = \DateTime::createFromFormat("Y-m-d", $row->execute_date);
            $entity->reason = $row->reason;
            $entity->tecObservations = $row->tec_observations;
            $entity->logObservations = $row->log_observations;
            array_push($list, $entity);
        }
        $rsTotal = $database->select("SELECT COUNT(enb_id) AS total FROM enb");
        foreach ($rsTotal as $row) {
            $total = (int) $row->total;
        }
        return ["data" => $list, "total" => $total];
    }

    /**
     * Trae un enb
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Enb que se quiere leer
     * @return Entity Enb leido
     */
    public function read($database, $entity) {
        $sql = "SELECT "
                . "e.enb_id, e.name, e.code, "
                . "e.address, c.city_id, c.name as city, "
                . "r.regional_id, r.name as regional, e.keys, "
                . "e.request_eng, e.request_date, e.execute_eng, "
                . "e.execute_date, e.reason, e.tec_observations, "
                . "e.log_observations "
                . "FROM enb e "
                . "INNER JOIN city c ON e.city_id = c.city_id "
                . "INNER JOIN regional r ON c.regional_id = r.regional_id "
                . "WHERE enb_id = $entity->id";
        $rs = $database->select($sql);
        foreach ($rs as $row) {
            $entity->name = $row->name;
            $entity->code = $row->code;
            $entity->address = $row->address;
            $entity->city = new \api\entities\City((int) $row->city_id);
            $entity->city->name = $row->city;
            $entity->city->regional = new \api\entities\Regional((int) $row->regional_id);
            $entity->city->regional->name = $row->regional;
            $entity->keys = $row->keys;
            $entity->requestEng = $row->request_eng;
            $entity->requestDate = \DateTime::createFromFormat("Y-m-d", $row->request_date);
            $entity->executeEng = $row->execute_eng;
            $entity->executeDate = \DateTime::createFromFormat("Y-m-d", $row->execute_date);
            $entity->reason = $row->reason;
            $entity->tecObservations = $row->tec_observations;
            $entity->logObservations = $row->log_observations;
        }
        return $entity;
    }

    /**
     * Crea un enb
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Enb que se quiere crear
     * @return Entity Enb creado
     */
    public function insert($database, $entity) {
        $rs = $database->insert("INSERT INTO enb "
                . "(name, `code`, address, "
                . "city_id, `keys`, request_eng, "
                . "request_date, execute_eng, execute_date, "
                . "reason, tec_observations, log_observations "
                . ") "
                . "VALUES "
                . "('$entity->name', '$entity->code', '$entity->address', "
                . $entity->city->id . ", '$entity->keys', '$entity->requestEng', "
                . "'" . $entity->requestDate->format("Y-m-d") . "', '$entity->executeEng', '" . $entity->executeDate->format("Y-m-d") . "', "
                . "'$entity->reason', '$entity->tecObservations', '$entity->logObservations')");
        $entity->id = $rs;
        return $entity;
    }

    /**
     * Actualiza un enb
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Enb que se quiere actualizar
     * @return Entity Enb actualizado
     */
    public function update($database, $entity) {
        $database->update("UPDATE enb SET "
                . "name = '$entity->name', "
                . "`code` = '$entity->code', "
                . "address = '$entity->address', "
                . "city_id = " . $entity->city->id . ", "
                . "`keys` = '$entity->keys', "
                . "request_eng = '$entity->requestEng', "
                . "request_date = '" . $entity->requestDate->format("Y-m-d") . "', "
                . "execute_eng = '$entity->executeEng', "
                . "execute_date = '" . $entity->executeDate->format("Y-m-d") . "', "
                . "reason = '$entity->reason', "
                . "tec_observations = '$entity->tecObservations', "
                . "log_observations = '$entity->logObservations' "
                . "WHERE enb_id = $entity->id");
        return $entity;
    }

    /**
     * Elimina un enb
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Enb que se quiere eliminar
     * @return Entity Enb eliminado
     */
    public function delete($database, $entity) {
        $database->delete("DELETE FROM enb WHERE enb_id = $entity->id");
        return $entity;
    }

    //</editor-fold>
}
