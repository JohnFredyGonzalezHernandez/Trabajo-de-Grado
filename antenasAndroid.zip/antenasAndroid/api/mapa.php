<?php
require_once(__DIR__ . '/business/Sector.php');
include_once(__DIR__ . "/settings.php");

$entity = new api\business\Sector($dbParameters);
$aux = $entity->list(0, 100);
$rs = $aux["data"];
?>
<html>
    <head>
        <title>Mapa de ubicación de las antenas</title>
        <style>
            #map {
                width: 800px;
                height: 600px;
            }
        </style>
    </head>
    <body>
        <div id="map"></div>
        <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAY45f1MRO_DRPdtzO49_iFH05Lk7WIDus&callback=initMap"
            defer>
        </script>
        <script>
            function initMap() {
                const map = new google.maps.Map(document.getElementById("map"), {
                    zoom: 6,
                    center: {lat: 4.169556, lng: -73.545750}
                });
<?php foreach ($rs as $row) { ?>
                    new google.maps.Marker({
                        position: {lat: <?php echo($row->latitude) ?>, lng: <?php echo($row->longitude) ?>},
                        map: map
                    });
<?php } ?>
            }
        </script>
    </body>
</html>
