<?php

namespace api\business;

require_once(__DIR__ . "/../database/Enb.php");
require_once(__DIR__ . "/../database/Parameters.php");

use api\database\Enb as DbMgr;
use api\entities\Enb as Entity;
use api\database\Parameters;
use api\database\Database;

/**
 * Lógica de negocio para los enb
 *
 * @author Leandro Baena
 */
class Enb {
    //<editor-fold defaultstate="collapsed" desc="Constructores">

    /**
     * Inicializa la conexión a la base de datos
     * @param Parameters $parameters Parámetros de conexión a la base de datos
     */
    public function __construct($parameters) {
        $this->connection = new Database($parameters->server, $parameters->user, $parameters->password, $parameters->schema);
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae el listado de enb
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de enb leidos
     */
    public function list($start, $offset) {
        $dbMgr = new DbMgr();
        $list = $dbMgr->list($this->connection, $start, $offset);
        return $list;
    }

    /**
     * Trae un enb
     * @param int $id Identificador del enb que se quiere leer
     * @return Entity Enb leido
     */
    public function read($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        return $dbMgr->read($this->connection, $entity);
    }

    /**
     * Crea un enb
     * @param string $name Nombre del enb que se quiere crear
     * @param string $code Código del enb que se quiere crear
     * @param string $address Direción del enb que se quiere crear
     * @param int $city Identificador de la ciudad donde se ubica el enb que se quiere crear
     * @param string $keys Llaves del enb que se quiere crear
     * @param string $requestEng Ingeniero que realizó la solicitud de mantenimiento del enb que se quiere crear
     * @param \DateTime $requestDate Fecha en que se realizó la solicitud de mantenimiento del enb que se quiere crear
     * @param string $executeEng Ingeniero que realizó el mantenimiento del enb que se quiere crear
     * @param \DateTime $executeDate Fecha en que se realizó el mantenimiento del enb que se quiere crear
     * @param string $reason Motivo del mantenimiento del enb que se quiere crear
     * @param string $tecObservations Observaciones técnicas del mantenimiento del enb que se quiere crear
     * @param string $logObservations Observaciones logísticas del mantenimiento del enb que se quiere crear
     * @return Entity Enb creado
     */
    public function insert($name, $code, $address,
            $city, $keys, $requestEng,
            $requestDate, $executeEng, $executeDate,
            $reason, $tecObservations, $logObservations) {
        $dbMgr = new DbMgr();
        $entity = new Entity();
        $entity->name = $name;
        $entity->code = $code;
        $entity->address = $address;
        $entity->city = new \api\entities\City($city);
        $entity->keys = $keys;
        $entity->requestEng = $requestEng;
        $entity->requestDate = $requestDate;
        $entity->executeEng = $executeEng;
        $entity->executeDate = $executeDate;
        $entity->reason = $reason;
        $entity->tecObservations = $tecObservations;
        $entity->logObservations = $logObservations;
        return $dbMgr->insert($this->connection, $entity);
    }

    /**
     * Actualiza un sector
     * @param int $id Identificador del sector que se quiere actualizar
     * @param string $name Nombre del enb que se quiere crear
     * @param string $code Código del enb que se quiere crear
     * @param string $address Direción del enb que se quiere crear
     * @param int $city Identificador de la ciudad donde se ubica el enb que se quiere crear
     * @param string $keys Llaves del enb que se quiere crear
     * @param string $requestEng Ingeniero que realizó la solicitud de mantenimiento del enb que se quiere crear
     * @param \DateTime $requestDate Fecha en que se realizó la solicitud de mantenimiento del enb que se quiere crear
     * @param string $executeEng Ingeniero que realizó el mantenimiento del enb que se quiere crear
     * @param \DateTime $executeDate Fecha en que se realizó el mantenimiento del enb que se quiere crear
     * @param string $reason Motivo del mantenimiento del enb que se quiere crear
     * @param string $tecObservations Observaciones técnicas del mantenimiento del enb que se quiere crear
     * @param string $logObservations Observaciones logísticas del mantenimiento del enb que se quiere crear
     * @return Entity Sector actualizado
     */
    public function update($id, $name, $code, $address,
            $city, $keys, $requestEng,
            $requestDate, $executeEng, $executeDate,
            $reason, $tecObservations, $logObservations) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $entity->name = $name;
        $entity->code = $code;
        $entity->address = $address;
        $entity->city = new \api\entities\City($city);
        $entity->keys = $keys;
        $entity->requestEng = $requestEng;
        $entity->requestDate = $requestDate;
        $entity->executeEng = $executeEng;
        $entity->executeDate = $executeDate;
        $entity->reason = $reason;
        $entity->tecObservations = $tecObservations;
        $entity->logObservations = $logObservations;
        return $dbMgr->update($this->connection, $entity);
    }

    /**
     * Elimina un sector
     * @param int $id Identificador del sector que se quiere eliminar
     * @return Entity Sector eliminado
     */
    public function delete($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $dbMgr->delete($this->connection, $entity);
        return $entity;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Atributos">

    /**
     * Conexión a la base de datos
     * @var Database Conexión a la base de datos
     */
    private $connection;

    //</editor-fold>
}
