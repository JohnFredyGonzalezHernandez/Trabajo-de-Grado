<?php

namespace api\business;

require_once(__DIR__ . "/../database/Aerial.php");
require_once(__DIR__ . "/../database/Parameters.php");

use api\database\Aerial as DbMgr;
use api\entities\Aerial as Entity;
use api\database\Parameters;
use api\database\Database;

/**
 * Lógica de negocio para los tipos de antenas
 *
 * @author Leandro Baena
 */
class Aerial {
    //<editor-fold defaultstate="collapsed" desc="Constructores">

    /**
     * Inicializa la conexión a la base de datos
     * @param Parameters $parameters Parámetros de conexión a la base de datos
     */
    public function __construct($parameters) {
        $this->connection = new Database($parameters->server, $parameters->user, $parameters->password, $parameters->schema);
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae el listado de tipos de antenas
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de tipos de antenas leidos
     */
    public function list($start, $offset) {
        $dbMgr = new DbMgr();
        $list = $dbMgr->list($this->connection, $start, $offset);
        return $list;
    }

    /**
     * Trae un tipo de antena
     * @param int $id Identificador del tipo de antena que se quiere leer
     * @return Entity Tipo de antena leido
     */
    public function read($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        return $dbMgr->read($this->connection, $entity);
    }

    /**
     * Crea un tipo de antena
     * @param string $name Nombre del tipo de antena que se quiere crear
     * @return Entity Tipo de antena creado
     */
    public function insert($name) {
        $dbMgr = new DbMgr();
        $entity = new Entity();
        $entity->name = $name;
        return $dbMgr->insert($this->connection, $entity);
    }

    /**
     * Actualiza un tipo de antena
     * @param int $id Identificador del tipo de antena que se quiere actualizar
     * @param string $name Nombre del tipo de antena que se quiere actualizar
     * @return Entity Tipo de antena actualizado
     */
    public function update($id, $name) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $entity->name = $name;
        return $dbMgr->update($this->connection, $entity);
    }

    /**
     * Elimina un tipo de antena
     * @param int $id Identificador del tipo de antena que se quiere eliminar
     * @return Entity Tipo de antena eliminado
     */
    public function delete($id) {
        $dbMgr = new DbMgr();
        $entity = new Entity($id);
        $dbMgr->delete($this->connection, $entity);
        return $entity;
    }

    //</editor-fold>
    //<editor-fold defaultstate="collapsed" desc="Atributos">

    /**
     * Conexión a la base de datos
     * @var Database Conexión a la base de datos
     */
    private $connection;

    //</editor-fold>
}
