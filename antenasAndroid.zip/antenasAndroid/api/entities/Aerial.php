<?php

namespace api\entities;

/**
 * Tipo de antena
 * 
 * @property int $id Identificador del tipo de antena
 * @property string $name Nombre del tipo de antena
 * @author Leandro Baena Torres
 */
class Aerial implements \JsonSerializable {
    //<editor-fold desc="Constructores" defaultstate="collapsed">

    /**
     * Crea un nuevo tipo de antena con un determinado identificador
     * @param int $id Identificador del tipo de antena
     */
    public function __construct($id = 0) {
        $this->id = $id;
        $this->name = "";
    }

    //</editor-fold>
    //<editor-fold desc="Métodos" defaultstate="collapsed">

    /**
     * Trae un atributo
     *
     * @param string $field Atributo a traerle el valor
     * @return mixed Valor del atributo
     */
    public function __get($field) {
        return $this->$field;
    }

    /**
     * Cambia el valor de un atributo
     *
     * @param string $field Atributo a cambiarle el valor
     * @param mixed $value Nuevo valor del atributo
     */
    public function __set($field, $value) {
        $this->$field = $value;
    }

    /**
     * Serializa el objeto
     * @return string
     */
    public function jsonSerialize() {
        return ['id' => $this->id, 'name' => $this->name];
    }

    //</editor-fold>
    //<editor-fold desc="Atributos" defaultstate="collapsed">

    /**
     * Identificador del tipo de antena
     * @var int
     */
    private $id;

    /**
     * Nombre del tipo de antena
     * @var string
     */
    private $name;

    //</editor-fold>
}
