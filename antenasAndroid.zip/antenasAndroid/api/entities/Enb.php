<?php

namespace api\entities;

require_once(__DIR__ . "/City.php");

/**
 * Enb al que se le hace mantenimiento
 * 
 * @property int $id Identificador del enb
 * @property string $name Nombre del enb
 * @property string $code Código del enb
 * @property string $address Dirección del enb
 * @property City $city Ciudad del enb
 * @property string $keys Llaves del enb
 * @property string $requestEng Ingeniero que hace la solicitud de mantenimiento del enb
 * @property \DateTime $requestDate Fecha en que se hace la solicitud de mantenimiento del enb
 * @property string $executeEng Ingeniero que realiza el mantenimiento del enb
 * @property \DateTime $executeDate Fecha en que se realiza el mantenimiento del enb
 * @property string $reason Motivo por el cual se realiza el mantenimiento del enb
 * @property string $tecObservations Observaciones técnicas para el mantenimiento del enb
 * @property string $logObservations Observaciones logísticas para el mantenimiento del enb
 * @author Leandro Baena Torres
 */
class Enb implements \JsonSerializable {
    //<editor-fold desc="Constructores" defaultstate="collapsed">

    /**
     * Crea un nuevo enb con un determinado identificador
     * @param int $id Identificador del enb
     */
    public function __construct($id = 0) {
        $this->id = $id;
        $this->name = "";
        $this->code = "";
        $this->address = "";
        $this->city = new City();
        $this->keys = "";
        $this->requestEng = "";
        $this->requestDate = new \DateTime();
        $this->executeEng = "";
        $this->executeDate = new \DateTime();
        $this->reason = "";
        $this->tecObservations = "";
        $this->logObservations = "";
    }

    //</editor-fold>
    //<editor-fold desc="Métodos" defaultstate="collapsed">

    /**
     * Trae un atributo
     *
     * @param string $field Atributo a traerle el valor
     * @return mixed Valor del atributo
     */
    public function __get($field) {
        return $this->$field;
    }

    /**
     * Cambia el valor de un atributo
     *
     * @param string $field Atributo a cambiarle el valor
     * @param mixed $value Nuevo valor del atributo
     */
    public function __set($field, $value) {
        $this->$field = $value;
    }

    /**
     * Serializa el objeto
     * @return string
     */
    public function jsonSerialize() {
        return ['id' => $this->id,
            'name' => $this->name,
            'code' => $this->code,
            'address' => $this->address,
            'city' => $this->city,
            'keys' => $this->keys,
            'requestEng' => $this->requestEng,
            'requestDate' => $this->requestDate->format("Y-m-d"),
            'executeEng' => $this->executeEng,
            'executeDate' => $this->executeDate->format("Y-m-d"),
            'reason' => $this->reason,
            'tecObservations' => $this->tecObservations,
            'logObservations' => $this->logObservations];
    }

    //</editor-fold>
    //<editor-fold desc="Atributos" defaultstate="collapsed">

    /**
     * Identificador del enb
     * @var int
     */
    private $id;

    /**
     * Nombre del enb
     * @var string
     */
    private $name;

    /**
     * Cóigo del enb
     * @var string
     */
    private $code;

    /**
     * Dirección del enb
     * @var string
     */
    private $address;

    /**
     * Ciudad donde se encuentra del enb
     * @var City
     */
    private $city;

    /**
     * Llaves del enb
     * @var string
     */
    private $keys;

    /**
     * Ingeniero que hace la solicitud de mantenimiento del enb
     * @var string
     */
    private $requestEng;

    /**
     * Fecha en que se hace la solicitud de mantenimiento del enb
     * @var \DateTime
     */
    private $requestDate;

    /**
     * Ingeniero que realiza el mantenimiento del enb
     * @var string
     */
    private $executeEng;

    /**
     * Fecha en que se realiza el mantenimiento del enb
     * @var \DateTime
     */
    private $executeDate;

    /**
     * Motivo por el cual se realiza el mantenimiento del enb
     * @var string
     */
    private $reason;

    /**
     * Observaciones técnicas para el mantenimiento del enb
     * @var string
     */
    private $tecObservations;

    /**
     * Observaciones logísticas para el mantenimiento del enb
     * @var string
     */
    private $logObservations;

    //</editor-fold>
}
