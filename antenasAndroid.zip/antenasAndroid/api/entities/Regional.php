<?php

namespace api\entities;

/**
 * Regional donde se ubican una ciudad
 * 
 * @property int $id Identificador de la regional
 * @property string $name Nombre de la regional
 * @author Leandro Baena Torres
 */
class Regional implements \JsonSerializable {
    //<editor-fold desc="Constructores" defaultstate="collapsed">

    /**
     * Crea una nueva regional con un determinado identificador
     * @param int $id Identificador de la regional
     */
    public function __construct($id = 0) {
        $this->id = $id;
        $this->name = "";
    }

    //</editor-fold>
    //<editor-fold desc="Métodos" defaultstate="collapsed">

    /**
     * Trae un atributo
     *
     * @param string $field Atributo a traerle el valor
     * @return mixed Valor del atributo
     */
    public function __get($field) {
        return $this->$field;
    }

    /**
     * Cambia el valor de un atributo
     *
     * @param string $field Atributo a cambiarle el valor
     * @param mixed $value Nuevo valor del atributo
     */
    public function __set($field, $value) {
        $this->$field = $value;
    }

    /**
     * Serializa el objeto
     * @return string
     */
    public function jsonSerialize() {
        return ['id' => $this->id, 'name' => $this->name];
    }

    //</editor-fold>
    //<editor-fold desc="Atributos" defaultstate="collapsed">

    /**
     * Identificador de la regional
     * @var int
     */
    private $id;

    /**
     * Nombre de la regional
     * @var string
     */
    private $name;

    //</editor-fold>
}
