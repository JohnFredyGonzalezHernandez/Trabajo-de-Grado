<?php

namespace api\database;

require_once(__DIR__ . '/Database.php');
require_once(__DIR__ . '/../entities/Sector.php');

use api\database\Database;
use api\entities\Sector as Entity;

/**
 * Permite la manipulación de los sectores en la base de datos
 *
 * @author Leandro Baena
 */
class Sector {
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae todos los sectores
     * @param Database $database Conexión a la base de datos
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de sectores
     */
    public function list($database, $start, $offset) {
        $total = 0;
        $list = array();
        $rs = $database->select(
                "SELECT "
                . "s.sector_id, s.name, s.enb_id, "
                . "e.name as enb, e.code, e.address, "
                . "e.city_id, c.name as city, c.regional_id, "
                . "r.name as regional, e.keys, e.request_eng, "
                . "e.request_date, e.execute_eng, e.execute_date, "
                . "e.reason, e.tec_observations, e.log_observations, "
                . "s.type, s.altitude_before, s.azimuth_before, "
                . "s.electric_tilt_before, s.mechanical_tilt_before, s.altitude_after, "
                . "s.azimuth_after, s.electric_tilt_after, s.mechanical_tilt_after, "
                . "a.aerial_id, a.name as aerial, s.gnet_track, "
                . "s.orientation_before, s.orientation_earth_before, s.orientation_after, "
                . "s.orientation_earth_after, s.latitude, s.longitude "
                . "FROM "
                . "sector s "
                . "INNER JOIN enb e ON s.enb_id = e.enb_id "
                . "INNER JOIN city c ON e.city_id = c.city_id "
                . "INNER JOIN regional r ON c.regional_id = r.regional_id "
                . "INNER JOIN aerial a ON s.aerial_id = a.aerial_id "
                . "LIMIT $start, $offset");
        foreach ($rs as $row) {
            $entity = new Entity((int) $row->sector_id);
            $entity->name = $row->name;
            $entity->enb = new \api\entities\Enb((int) $row->enb_id);
            $entity->enb->name = $row->enb;
            $entity->enb->code = $row->code;
            $entity->enb->address = $row->address;
            $entity->enb->city = new \api\entities\City((int) $row->city_id);
            $entity->enb->city->name = $row->city;
            $entity->enb->city->regional = new \api\entities\Regional((int) $row->regional_id);
            $entity->enb->city->regional->name = $row->regional;
            $entity->enb->keys = $row->keys;
            $entity->enb->requestEng = $row->request_eng;
            $entity->enb->requestDate = \DateTime::createFromFormat("Y-m-d", $row->request_date);
            $entity->enb->executeEng = $row->execute_eng;
            $entity->enb->executeDate = \DateTime::createFromFormat("Y-m-d", $row->execute_date);
            $entity->enb->reason = $row->reason;
            $entity->enb->tecObservations = $row->tec_observations;
            $entity->enb->logObservations = $row->log_observations;
            $entity->type = $row->type == 1;
            $entity->altitudeBefore = (int) $row->altitude_before;
            $entity->azimuthBefore = (int) $row->azimuth_before;
            $entity->electricTiltBefore = (int) $row->electric_tilt_before;
            $entity->mechanicalTiltBefore = (int) $row->mechanical_tilt_before;
            $entity->altitudeAfter = (int) $row->altitude_after;
            $entity->azimuthAfter = (int) $row->azimuth_after;
            $entity->electricTiltAfter = (int) $row->electric_tilt_after;
            $entity->mechanicalTiltAfter = (int) $row->mechanical_tilt_after;
            $entity->aerial = new \api\entities\Aerial((int) $row->aerial_id);
            $entity->aerial->name = $row->aerial;
            $entity->gnetTrack = $row->gnet_track;
            $entity->orientationBefore = $row->orientation_before;
            $entity->orientationEarthBefore = $row->orientation_earth_before;
            $entity->orientationAfter = $row->orientation_after;
            $entity->orientationEarthAfter = $row->orientation_earth_after;
            $entity->latitude = (float) $row->latitude;
            $entity->longitude = (float) $row->longitude;
            array_push($list, $entity);
        }
        $rsTotal = $database->select("SELECT COUNT(sector_id) AS total FROM sector");
        foreach ($rsTotal as $row) {
            $total = (int) $row->total;
        }
        return ["data" => $list, "total" => $total];
    }

    /**
     * Trae un sector
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Sector que se quiere leer
     * @return Entity Sector leido
     */
    public function read($database, $entity) {
        $sql = "SELECT "
                . "s.sector_id, s.name, s.enb_id, "
                . "s.type, s.altitude_before, s.azimuth_before, "
                . "s.electric_tilt_before, s.mechanical_tilt_before, s.altitude_after, "
                . "s.azimuth_after, s.electric_tilt_after, s.mechanical_tilt_after, "
                . "a.aerial_id, a.name as aerial, s.gnet_track, "
                . "s.orientation_before, s.orientation_earth_before, s.orientation_after, "
                . "s.orientation_earth_after, s.latitude, s.longitude "
                . "FROM "
                . "sector s "
                . "INNER JOIN aerial a ON s.aerial_id = a.aerial_id "
                . "WHERE sector_id = $entity->id";
        $rs = $database->select($sql);
        foreach ($rs as $row) {
            $entity->name = $row->name;
            $entity->enb = new \api\entities\Enb((int) $row->enb_id);
            $entity->type = $row->type == 1;
            $entity->altitudeBefore = (int) $row->altitude_before;
            $entity->azimuthBefore = (int) $row->azimuth_before;
            $entity->electricTiltBefore = (int) $row->electric_tilt_before;
            $entity->mechanicalTiltBefore = (int) $row->mechanical_tilt_before;
            $entity->altitudeAfter = (int) $row->altitude_after;
            $entity->azimuthAfter = (int) $row->azimuth_after;
            $entity->electricTiltAfter = (int) $row->electric_tilt_after;
            $entity->mechanicalTiltAfter = (int) $row->mechanical_tilt_after;
            $entity->aerial = new \api\entities\Aerial((int) $row->aerial_id);
            $entity->aerial->name = $row->aerial;
            $entity->gnetTrack = $row->gnet_track;
            $entity->orientationBefore = $row->orientation_before;
            $entity->orientationEarthBefore = $row->orientation_earth_before;
            $entity->orientationAfter = $row->orientation_after;
            $entity->orientationEarthAfter = $row->orientation_earth_after;
            $entity->latitude = (float) $row->latitude;
            $entity->longitude = (float) $row->longitude;
        }
        return $entity;
    }

    /**
     * Crea un sector
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Sector que se quiere crear
     * @return Entity Sector creado
     */
    public function insert($database, $entity) {
        $rs = $database->insert("INSERT INTO sector "
                . "(enb_id, name, type, "
                . "altitude_before, azimuth_before, electric_tilt_before, "
                . "mechanical_tilt_before, altitude_after, azimuth_after, "
                . "electric_tilt_after, mechanical_tilt_after, aerial_id, "
                . "gnet_track, orientation_before, orientation_earth_before, "
                . "orientation_after, orientation_earth_after, latitude, "
                . "longitude) "
                . "VALUES "
                . "(" . $entity->enb->id . ", '$entity->name', " . ($entity->type ? "1" : "0") . ", "
                . "$entity->altitudeBefore, $entity->azimuthBefore, $entity->electricTiltBefore, "
                . "$entity->mechanicalTiltBefore, $entity->altitudeAfter, $entity->azimuthAfter, "
                . "$entity->electricTiltAfter, $entity->mechanicalTiltAfter, " . $entity->aerial->id . ", "
                . "'$entity->gnetTrack', '$entity->orientationBefore', '$entity->orientationEarthBefore', "
                . "'$entity->orientationAfter', '$entity->orientationEarthAfter', $entity->latitude, "
                . "$entity->longitude)");
        $entity->id = $rs;
        return $entity;
    }

    /**
     * Actualiza un sector
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Sector que se quiere actualizar
     * @return Entity Sector actualizado
     */
    public function update($database, $entity) {
        $database->update("UPDATE sector SET "
                . "enb_id = " . $entity->enb->id . ", "
                . "name = '$entity->name', "
                . "type = " . ($entity->type ? "1" : "0") . ", "
                . "altitude_before = $entity->altitudeBefore, "
                . "azimuth_before = $entity->azimuthBefore, "
                . "electric_tilt_before = $entity->electricTiltBefore, "
                . "mechanical_tilt_before = $entity->mechanicalTiltBefore, "
                . "altitude_after = $entity->altitudeAfter, "
                . "azimuth_after = $entity->azimuthAfter, "
                . "electric_tilt_after = $entity->electricTiltAfter, "
                . "mechanical_tilt_after = $entity->mechanicalTiltAfter, "
                . "aerial_id = " . $entity->aerial->id . ", "
                . "gnet_track = '$entity->gnetTrack', "
                . "orientation_before = '$entity->orientationBefore', "
                . "orientation_earth_before = '$entity->orientationEarthBefore', "
                . "orientation_after = '$entity->orientationAfter', "
                . "orientation_earth_after = '$entity->orientationEarthAfter', "
                . "latitude = $entity->latitude, "
                . "longitude = $entity->longitude "
                . "WHERE sector_id = $entity->id");
        return $entity;
    }

    /**
     * Elimina un sector
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Sector que se quiere eliminar
     * @return Entity Sector eliminado
     */
    public function delete($database, $entity) {
        $database->delete("DELETE FROM sector WHERE sector_id = $entity->id");
        return $entity;
    }

    //</editor-fold>
}
