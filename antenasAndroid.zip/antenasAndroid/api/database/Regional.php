<?php

namespace api\database;

require_once(__DIR__ . '/Database.php');
require_once(__DIR__ . '/../entities/Regional.php');

use api\database\Database;
use api\entities\Regional as Entity;

/**
 * Permite la manipulación de las regionales en la base de datos
 *
 * @author Leandro Baena
 */
class Regional {
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae todos las regionales
     * @param Database $database Conexión a la base de datos
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de regionales
     */
    public function list($database, $start, $offset) {
        $total = 0;
        $list = array();
        $rs = $database->select("SELECT regional_id, name FROM regional LIMIT $start, $offset");
        foreach ($rs as $row) {
            $entity = new Entity((int) $row->regional_id);
            $entity->name = $row->name;
            array_push($list, $entity);
        }
        $rsTotal = $database->select("SELECT COUNT(regional_id) AS total FROM regional");
        foreach ($rsTotal as $row) {
            $total = (int) $row->total;
        }
        return ["data" => $list, "total" => $total];
    }

    /**
     * Trae una regional
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Regional que se quiere leer
     * @return Entity Regional leida
     */
    public function read($database, $entity) {
        $sql = "SELECT name FROM regional WHERE regional_id = $entity->id";
        $rs = $database->select($sql);
        foreach ($rs as $row) {
            $entity->name = $row->name;
        }
        return $entity;
    }

    /**
     * Crea una rgional
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Regional que se quiere crear
     * @return Entity Regional creada
     */
    public function insert($database, $entity) {
        $rs = $database->insert("INSERT INTO regional (name) VALUES ('$entity->name')");
        $entity->id = $rs;
        return $entity;
    }

    /**
     * Actualiza una regional
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Regional que se quiere actualizar
     * @return Entity Regional actualizada
     */
    public function update($database, $entity) {
        $database->update("UPDATE regional SET name = '$entity->name' WHERE regional_id = $entity->id");
        return $entity;
    }

    /**
     * Elimina una regional
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Regional que se quiere eliminar
     * @return Entity Regional eliminada
     */
    public function delete($database, $entity) {
        $database->delete("DELETE FROM regional WHERE regional_id = $entity->id");
        return $entity;
    }

    //</editor-fold>
}
