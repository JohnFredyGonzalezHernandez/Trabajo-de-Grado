<?php

namespace api\database;

require_once(__DIR__ . '/Database.php');
require_once(__DIR__ . '/../entities/City.php');

use api\database\Database;
use api\entities\City as Entity;

/**
 * Permite la manipulación de las ciudades en la base de datos
 *
 * @author Leandro Baena
 */
class City {
    //<editor-fold defaultstate="collapsed" desc="Métodos">

    /**
     * Trae todos las ciudades
     * @param Database $database Conexión a la base de datos
     * @param int $start Registro inicial que se desea obtener
     * @param int $offset Número de registros que se desea obtener
     * @return array Listado de ciudades
     */
    public function list($database, $start, $offset) {
        $total = 0;
        $list = array();
        $rs = $database->select(
                "SELECT "
                . "c.city_id, c.name, r.regional_id, "
                . "r.name as regional "
                . "FROM "
                . "city c "
                . "INNER JOIN regional r ON c.regional_id = r.regional_id "
                . "LIMIT $start, $offset");
        foreach ($rs as $row) {
            $entity = new Entity((int) $row->city_id);
            $entity->name = $row->name;
            $entity->regional = new \api\entities\Regional((int) $row->regional_id);
            $entity->regional->name = $row->regional;
            array_push($list, $entity);
        }
        $rsTotal = $database->select("SELECT COUNT(city_id) AS total FROM city");
        foreach ($rsTotal as $row) {
            $total = (int) $row->total;
        }
        return ["data" => $list, "total" => $total];
    }

    /**
     * Trae una ciudad
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Ciudad que se quiere leer
     * @return Entity Ciudad leida
     */
    public function read($database, $entity) {
        $sql = "SELECT "
                . "c.city_id, c.name, r.regional_id, "
                . "r.name as regional "
                . "FROM "
                . "city c "
                . "INNER JOIN regional r ON c.regional_id = r.regional_id "
                . "WHERE city_id = $entity->id";
        $rs = $database->select($sql);
        foreach ($rs as $row) {
            $entity->name = $row->name;
            $entity->regional = new \api\entities\Regional((int) $row->regional_id);
            $entity->regional->name = $row->regional;
        }
        return $entity;
    }

    /**
     * Crea una ciudad
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Ciudad que se quiere crear
     * @return Entity Ciudad creada
     */
    public function insert($database, $entity) {
        $rs = $database->insert("INSERT INTO city (name, regional_id) VALUES ('$entity->name', " . $entity->regional->id . ")");
        $entity->id = $rs;
        return $entity;
    }

    /**
     * Actualiza una ciudad
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Ciudad que se quiere actualizar
     * @return Entity Ciudad actualizada
     */
    public function update($database, $entity) {
        $database->update("UPDATE city SET name = '$entity->name', regional_id = " . $entity->regional->id . " WHERE city_id = $entity->id");
        return $entity;
    }

    /**
     * Elimina una ciudad
     * @param Database $database Conexión a la base de datos
     * @param Entity $entity Ciudad que se quiere eliminar
     * @return Entity Ciudad eliminada
     */
    public function delete($database, $entity) {
        $database->delete("DELETE FROM city WHERE city_id = $entity->id");
        return $entity;
    }

    //</editor-fold>
}
