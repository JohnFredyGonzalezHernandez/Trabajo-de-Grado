package com.jhongonzalez.lecturadeantenas.entities;

import java.io.Serializable;
import java.util.Date;

/**
 * ENB
 */
public class Enb implements Serializable {

    //region Atributos
    /**
     * Identificador del enb
     */
    private int enbId;

    /**
     * Nombre del enb
     */
    private String name;

    /**
     * Código del enb
     */
    private String code;

    /**
     * Dirección del enb
     */
    private String address;

    /**
     * Ciudad donde se ubica el enb
     */
    private City city;

    /**
     * Llaves del enb
     */
    private String keys;

    /**
     * Ingeniero que realiza la solicitud
     */
    private String requestEng;

    /**
     * Fecha de la solicitud
     */
    private Date requestDate;

    /**
     * Ingeniero que ejecuta la solicitud
     */
    private String executeEng;

    /**
     * Fecha de ejecución de la solicitud
     */
    private Date executeDate;

    /**
     * Motivo de la solicitud
     */
    private String reason;

    /**
     * Observaciones técnicas
     */
    private String tecObservations;

    /**
     * Observaciones logísticas
     */
    private String logObservations;
    //endregion

    //region Constructores

    /**
     * Crea un enb con datos por defecto
     */
    public Enb() {
        this(0);
    }

    /**
     * Crea un enb con un identificador por defecto
     *
     * @param id Identificador del enb
     */
    public Enb(int id) {
        this.enbId = id;
        this.name = "";
        this.code = "";
        this.address = "";
        this.city = new City();
        this.keys = "";
        this.requestEng = "";
        this.requestDate = new Date();
        this.executeEng = "";
        this.executeDate = new Date();
        this.reason = "";
        this.tecObservations = "";
        this.logObservations = "";
    }
    //endregion

    //region Métodos

    /**
     * Trae el identificador del enb
     *
     * @return Identificador del enb
     */
    public int getEnbId() {
        return enbId;
    }

    /**
     * Cambia el identificador del enb
     *
     * @param enbId Nuevo identificador del enb
     */
    public void setEnbId(int enbId) {
        this.enbId = enbId;
    }

    /**
     * Trae el nombre de la ciudad
     *
     * @return Nombre de la ciudad
     */
    public String getName() {
        return name;
    }

    /**
     * Cambia el nombre de la ciudad
     *
     * @param name Nuevo nombre de la ciudad
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Trae el código de la ciudad
     *
     * @return Código de la ciudad
     */
    public String getCode() {
        return code;
    }

    /**
     * Cambia el código de la ciudad
     *
     * @param code Nuevo código de la ciudad
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Trae la dirección del enb
     *
     * @return Dirección del enb
     */
    public String getAddress() {
        return address;
    }

    /**
     * Cambia la dirección del enb
     *
     * @param address Nueva dirección del enb
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Trae la ciudad donde se ubica el enb
     *
     * @return Ciudad donde se ubica el enb
     */
    public City getCity() {
        return city;
    }

    /**
     * Cambia la ciudad donde se ubica el enb
     *
     * @param city Nueva ciudad donde se ubica el enb
     */
    public void setCity(City city) {
        this.city = city;
    }

    /**
     * Trae las llaves del enb
     *
     * @return Llaves del enb
     */
    public String getKeys() {
        return keys;
    }

    /**
     * Cambia las llaves del enb
     *
     * @param keys Nuevas llaves del enb
     */
    public void setKeys(String keys) {
        this.keys = keys;
    }

    /**
     * Trae el ingeniero que realiza la solicitud
     *
     * @return Ingeniero que realiza la solicitud
     */
    public String getRequestEng() {
        return requestEng;
    }

    /**
     * Cambia el ingeniero que realiza la solicitud
     *
     * @param requestEng Nuevo ingeniero que realiza la solicitud
     */
    public void setRequestEng(String requestEng) {
        this.requestEng = requestEng;
    }

    /**
     * Trae la fecha de la solicitud
     *
     * @return Fecha de la solicitud
     */
    public Date getRequestDate() {
        return requestDate;
    }

    /**
     * Cambia la fecha de la solicitud
     *
     * @param requestDate Nueva fecha de la solicitud
     */
    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Trae el ingeniero que ejecuta la solicitud
     *
     * @return Ingeniero que ejecuta la solicitud
     */
    public String getExecuteEng() {
        return executeEng;
    }

    /**
     * Cambia el ingeniero que ejecuta la solicitud
     *
     * @param executeEng Nuevo ingeniero que ejecuta la solicitud
     */
    public void setExecuteEng(String executeEng) {
        this.executeEng = executeEng;
    }

    /**
     * Trae la fecha de ejecución de la solicitud
     *
     * @return Fecha de ejecución de la solicitud
     */
    public Date getExecuteDate() {
        return executeDate;
    }

    /**
     * Cambia la fecha de ejecución de la solicitud
     *
     * @param executeDate Nueva fecha de ejecución de la solicitud
     */
    public void setExecuteDate(Date executeDate) {
        this.executeDate = executeDate;
    }

    /**
     * Trae el motivo de la solicitud
     *
     * @return Motivo de la solicitud
     */
    public String getReason() {
        return reason;
    }

    /**
     * Cambia el motivo de la solicitud
     *
     * @param reason Nuevo motivo de la solicitud
     */
    public void setReason(String reason) {
        this.reason = reason;
    }

    /**
     * Trae las observaciones técnicas
     *
     * @return Observaciones técnicas
     */
    public String getTecObservations() {
        return tecObservations;
    }

    /**
     * Cambia las observaciones técnicas
     *
     * @param tecObservations Nuevas observaciones técnicas
     */
    public void setTecObservations(String tecObservations) {
        this.tecObservations = tecObservations;
    }

    /**
     * Trae las observaciones logísticas
     *
     * @return Observaciones logísticas
     */
    public String getLogObservations() {
        return logObservations;
    }

    /**
     * Cambia las observaciones logísticas
     *
     * @param logObservations Nuevas observaciones logísticas
     */
    public void setLogObservations(String logObservations) {
        this.logObservations = logObservations;
    }

    //endregion
}
