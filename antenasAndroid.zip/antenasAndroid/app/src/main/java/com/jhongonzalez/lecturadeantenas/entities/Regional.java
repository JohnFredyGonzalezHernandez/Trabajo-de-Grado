package com.jhongonzalez.lecturadeantenas.entities;

import java.io.Serializable;

/**
 * Regional a donde pertenece la antena
 */
public class Regional implements Serializable {

    //region Atributos
    /**
     * Identificador de la region
     */
    private int regionalId;

    /**
     * Nombre de la region
     */
    private String name;
    //endregion

    //region Constructores

    /**
     * Crea una región con datos por defecto
     */
    public Regional() {
        this(0);
    }

    /**
     * Crea una región con un identificador por defecto
     *
     * @param id Identificador de la región
     */
    public Regional(int id) {
        this.regionalId = id;
        this.name = "";
    }
    //endregion

    //region Métodos

    /**
     * Trae el identificador de la región
     *
     * @return Identificador de la región
     */
    public int getRegionalId() {
        return regionalId;
    }

    /**
     * Cambia el identificador de la región
     *
     * @param regionalId Nuevo identificador de la región
     */
    public void setRegionalId(int regionalId) {
        this.regionalId = regionalId;
    }

    /**
     * Trae el nombre de la región
     *
     * @return Nombre de la región
     */
    public String getName() {
        return name;
    }

    /**
     * Cambia el nombre de la región
     *
     * @param name Nuevo nombre de la región
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Expresa la regional como un texto mostrando su nombre
     *
     * @return Nombre de la regional
     */
    @Override
    public String toString() {
        return name;
    }

    /**
     * Compara la regional actual con otra
     *
     * @param regional Regional con la que se quiere comparar
     * @return Si son o no iguales
     */
    @Override
    public boolean equals(Object regional) {
        if (regional.getClass() != Regional.class) {
            return false;
        }
        return (((Regional) regional).getRegionalId() == this.regionalId);
    }
    //endregion
}
