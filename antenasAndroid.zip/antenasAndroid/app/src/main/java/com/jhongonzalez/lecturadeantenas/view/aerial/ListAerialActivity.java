package com.jhongonzalez.lecturadeantenas.view.aerial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.adapters.GridAerialAdapter;
import com.jhongonzalez.lecturadeantenas.entities.Aerial;

public class ListAerialActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Adaptador de la tabla de tipos de antenas
     */
    private GridAerialAdapter gridAerialAdapter;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al iniciar la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_aerial);
        this.setTitle(R.string.list_aerials);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView listAerials = findViewById(R.id.listAerials);
        FloatingActionButton fabAddAerial = findViewById(R.id.fabAddAerial);

        gridAerialAdapter = new GridAerialAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        listAerials.setLayoutManager(mLayoutManager);
        listAerials.setItemAnimator(new DefaultItemAnimator());
        listAerials.setAdapter(gridAerialAdapter);

        fabAddAerial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editAerial = new Intent(ListAerialActivity.this, EditAerialActivity.class);
                editAerial.putExtra("aerial", new Aerial());
                startActivity(editAerial);
            }
        });
    }

    /**
     * Se ejecuta al volver de otra actividad a esta
     */
    @Override
    public void onResume() {
        super.onResume();
        gridAerialAdapter.update();
    }
    //endregion
}