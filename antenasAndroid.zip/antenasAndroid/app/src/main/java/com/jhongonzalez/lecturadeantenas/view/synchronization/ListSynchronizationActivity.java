package com.jhongonzalez.lecturadeantenas.view.synchronization;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.adapters.GridSyncAdapter;
import com.jhongonzalez.lecturadeantenas.database.AerialDB;
import com.jhongonzalez.lecturadeantenas.database.CityDB;
import com.jhongonzalez.lecturadeantenas.database.EnbDB;
import com.jhongonzalez.lecturadeantenas.database.RegionalDB;
import com.jhongonzalez.lecturadeantenas.database.SectorDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.City;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.entities.Regional;
import com.jhongonzalez.lecturadeantenas.entities.Sector;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Base64;

public class ListSynchronizationActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Adaptador de la tabla de sincronizaciones
     */
    private GridSyncAdapter gridSyncAdapter;

    /**
     * Administrador de persistencia de los tipos de antenas
     */
    private AerialDB aerialDB;

    /**
     * Administrador de persistencia de las ciudades
     */
    private CityDB cityDB;

    /**
     * Administrador de persistencia de los enb
     */
    private EnbDB enbDB;

    /**
     * Administrador de persistencia de las regionales
     */
    private RegionalDB regionalDB;

    /**
     * Administrador de persistencia de los sectores
     */
    private SectorDB sectorDB;

    /**
     * Administrador de persistencia de las sincronizaciones
     */
    private SynchronizationDB synchronizationDB;

    /**
     * Barra de progreso para el envío de la información al servidor
     */
    private ProgressBar synProcessing;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al iniciar la actividad
     *
     * @param savedInstanceState Estado actual de la actividad
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_sync);
        this.setTitle(R.string.list_syncs);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView listSyncs = findViewById(R.id.listSyncs);
        FloatingActionButton fabSync = findViewById(R.id.fabSync);
        synProcessing = findViewById(R.id.sync_processing);
        synProcessing.setVisibility(View.INVISIBLE);
        gridSyncAdapter = new GridSyncAdapter(this);
        aerialDB = new AerialDB(this);
        cityDB = new CityDB(this);
        synchronizationDB = new SynchronizationDB(this);
        regionalDB = new RegionalDB(this);
        enbDB = new EnbDB(this);
        sectorDB = new SectorDB(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        listSyncs.setLayoutManager(mLayoutManager);
        listSyncs.setItemAnimator(new DefaultItemAnimator());
        listSyncs.setAdapter(gridSyncAdapter);

        fabSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String url = "http://192.168.31.248/leandrobaena_com/antenas/"; //local
                String url = "http://leandrobaena.com/antenas/"; //pruebas

                RequestQueue queue = Volley.newRequestQueue(ListSynchronizationActivity.this);

                for (final Synchronization sync : gridSyncAdapter.getList()) {
                    JSONObject data = new JSONObject();
                    switch (sync.getTableName()) {
                        case "aerial":
                            url += "Aerial.php";
                            Aerial aerial = aerialDB.read(new Aerial(sync.getTableId()));
                            try {
                                data.put("id", aerial.getAerialId());
                                data.put("name", aerial.getName());
                            } catch (JSONException e) {
                                Toast.makeText(ListSynchronizationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            break;
                        case "city":
                            url += "City.php";
                            City city = cityDB.read(new City(sync.getTableId()));
                            try {
                                data = new JSONObject("{\"id\": " + city.getCityId() + ", " +
                                        "\"name\": \"" + city.getName() + "\", " +
                                        "\"regional\": {" +
                                        "\"id\": " + city.getRegional().getRegionalId() + ", " +
                                        "\"name\": \"" + city.getRegional().getName() + "\"" +
                                        "}}");
                            } catch (JSONException e) {
                                Toast.makeText(ListSynchronizationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            break;
                        case "enb":
                            url += "Enb.php";
                            Enb enb = enbDB.read(new Enb(sync.getTableId()));
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                            try {
                                data = new JSONObject("{\"id\": " + enb.getEnbId() + ", " +
                                        "\"name\": \"" + enb.getName() + "\", " +
                                        "\"code\": \"" + enb.getCode() + "\", " +
                                        "\"address\": \"" + enb.getAddress() + "\", " +
                                        "\"city\": {" +
                                        "\"id\": " + enb.getCity().getCityId() + ", " +
                                        "\"name\": \"" + enb.getCity().getName() + "\", " +
                                        "\"regional\": {" +
                                        "\"id\": " + enb.getCity().getRegional().getRegionalId() + ", " +
                                        "\"name\": \"" + enb.getCity().getRegional().getName() + "\"" +
                                        "}}, " +
                                        "\"keys\": \"" + enb.getKeys() + "\", " +
                                        "\"requestEng\": \"" + enb.getRequestEng() + "\", " +
                                        "\"requestDate\": \"" + sdf.format(enb.getRequestDate()) + "\", " +
                                        "\"executeEng\": \"" + enb.getExecuteEng() + "\", " +
                                        "\"executeDate\": \"" + sdf.format(enb.getExecuteDate()) + "\", " +
                                        "\"reason\": \"" + enb.getReason() + "\", " +
                                        "\"tecObservations\": \"" + enb.getTecObservations() + "\", " +
                                        "\"logObservations\": \"" + enb.getLogObservations() + "\"" +
                                        "}");
                            } catch (JSONException e) {
                                Toast.makeText(ListSynchronizationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            break;
                        case "regional":
                            url += "Regional.php";
                            Regional regional = regionalDB.read(new Regional(sync.getTableId()));
                            try {
                                data.put("id", regional.getRegionalId());
                                data.put("name", regional.getName());
                            } catch (JSONException e) {
                                Toast.makeText(ListSynchronizationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            break;
                        case "sector":
                            url += "Sector.php";
                            Sector sector = sectorDB.read(new Sector(sync.getTableId()));

                            try {
                                data = new JSONObject("{\"id\": " + sector.getSectorId() + ", " +
                                        "\"enb\": {" +
                                        "\"id\": " + sector.getEnb().getEnbId() + ", " +
                                        "\"name\": \"" + sector.getEnb().getName() + "\"" +
                                        "}, " +
                                        "\"name\": \"" + sector.getName() + "\", " +
                                        "\"type\": " + (sector.getType() ? "true" : "false") + ", " +
                                        "\"altitudeBefore\": " + sector.getAltitudeBefore() + ", " +
                                        "\"azimuthBefore\": " + sector.getAzimuthBefore() + ", " +
                                        "\"electricTiltBefore\": " + sector.getElectricTiltBefore() + ", " +
                                        "\"mechanicalTiltBefore\": " + sector.getMechanicalTiltBefore() + ", " +
                                        "\"altitudeAfter\": " + sector.getAltitudeAfter() + ", " +
                                        "\"azimuthAfter\": " + sector.getAzimuthAfter() + ", " +
                                        "\"electricTiltAfter\": " + sector.getElectricTiltAfter() + ", " +
                                        "\"mechanicalTiltAfter\": " + sector.getMechanicalTiltAfter() + ", " +
                                        "\"aerial\": {" +
                                        "\"id\": " + sector.getAerial().getAerialId() + ", " +
                                        "\"name\": \"" + sector.getAerial().getName() + "\"" +
                                        "}, " +
                                        "\"gnetTrack\": \"" + sector.getGnetTrack() + "\", " +
                                        "\"gnetTrackData\": \"" + encodeFileToBase64Binary(getFilesDir() + "/" + sector.getGnetTrack()) + "\", " +
                                        "\"orientationBefore\": \"" + sector.getOrientationBefore() + "\", " +
                                        "\"orientationBeforeData\": \"" + encodeFileToBase64Binary(getFilesDir() + "/" + sector.getOrientationBefore()) + "\", " +
                                        "\"orientationEarthBefore\": \"" + sector.getOrientationEarthBefore() + "\", " +
                                        "\"orientationEarthBeforeData\": \"" + encodeFileToBase64Binary(getFilesDir() + "/" + sector.getOrientationEarthBefore()) + "\", " +
                                        "\"orientationAfter\": \"" + sector.getOrientationAfter() + "\", " +
                                        "\"orientationAfterData\": \"" + encodeFileToBase64Binary(getFilesDir() + "/" + sector.getOrientationAfter()) + "\", " +
                                        "\"orientationEarthAfter\": \"" + sector.getOrientationEarthAfter() + "\", " +
                                        "\"orientationEarthAfterData\": \"" + encodeFileToBase64Binary(getFilesDir() + "/" + sector.getOrientationEarthAfter()) + "\", " +
                                        "\"latitude\": " + sector.getLatitude() + ", " +
                                        "\"longitude\": " + sector.getLongitude() +
                                        "}");
                            } catch (JSONException e) {
                                Toast.makeText(ListSynchronizationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            break;
                    }
                    JsonObjectRequest request = null;
                    synProcessing.setVisibility(View.VISIBLE);
                    switch (sync.getAction()) {
                        case "I":
                            request = new JsonObjectRequest(Request.Method.POST, url, data,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            sync.setDone(true);
                                            synchronizationDB.update(sync);
                                            gridSyncAdapter.update();
                                            Toast.makeText(ListSynchronizationActivity.this, "Registro " + sync.getSynchronizationId() + " sincronizado", Toast.LENGTH_SHORT).show();
                                        }
                                    }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(ListSynchronizationActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                            break;
                        case "U":
                            request = new JsonObjectRequest(Request.Method.PUT, url, data,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            sync.setDone(true);
                                            synchronizationDB.update(sync);
                                            gridSyncAdapter.update();
                                            Toast.makeText(ListSynchronizationActivity.this, "Registro " + sync.getSynchronizationId() + " sincronizado", Toast.LENGTH_SHORT).show();
                                        }
                                    }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(ListSynchronizationActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                            break;
                        case "D":
                            request = new JsonObjectRequest(Request.Method.DELETE, url + "?id=" + sync.getTableId(), null,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            sync.setDone(true);
                                            synchronizationDB.update(sync);
                                            gridSyncAdapter.update();
                                            Toast.makeText(ListSynchronizationActivity.this, "Registro " + sync.getSynchronizationId() + " sincronizado", Toast.LENGTH_SHORT).show();
                                        }
                                    }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(ListSynchronizationActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                            break;
                    }
                    if (request != null) {
                        queue.add(request);
                        queue.addRequestFinishedListener(new RequestQueue.RequestFinishedListener<Object>() {
                            @Override
                            public void onRequestFinished(Request<Object> request) {
                                synProcessing.setVisibility(View.GONE);
                                synProcessing.setVisibility(View.INVISIBLE);
                            }
                        });
                    }
                }
            }
        });
    }

    /**
     * Se ejecuta al volver de otra actividad a esta
     */
    @Override
    public void onResume() {
        super.onResume();
        gridSyncAdapter.update();
    }

    /**
     * Trae el contenido de un archivo de imagen en formato Base64
     * @param pathFile Ruta del archivo de la imagen
     * @return Contenido de un archivo de imagen en formato Base64
     * @throws Exception si no pudo leer el archivo
     */
    private static String encodeFileToBase64Binary(String pathFile) {
        try {
            File file = new File(pathFile);
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] bytes = new byte[(int)file.length()];
            fileInputStream.read(bytes);
            return Base64.getEncoder().encodeToString(bytes);
        } catch (Exception e){
            return "";
        }
    }
    //endregion
}