package com.jhongonzalez.lecturadeantenas.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Clase encargada de la persistencia de las sincronizaciones
 */
public class SynchronizationDB {

    //region Atributos
    /**
     * Conexión a la base de datos
     */
    private final DatabaseHelper db;

    /**
     * Nombre de la tabla
     */
    private final String TABLE = "synchronization";

    /**
     * Nombre de las columnas
     */
    private final String[] COLUMNS = {"synchronization_id", "table_name", "table_id", "date", "done", "[action]"};
    //endregion

    //region Constructores

    /**
     * Crea la conexión a la base de datos
     *
     * @param context Contexto de la aplicación
     */
    public SynchronizationDB(@Nullable Context context) {
        this.db = new DatabaseHelper(context);
    }

    //endregion

    //region Métodos

    /**
     * Trae el listado de sincronizaciones de la base de datos
     *
     * @return Listado de sincronizaciones de la base de datos
     */
    public ArrayList<Synchronization> list() {
        ArrayList<Synchronization> list = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        try (Cursor result = this.db.getReadableDatabase().query(TABLE, COLUMNS,
                null,
                null,
                null,
                null,
                null)) {
            while (result.moveToNext()) {
                Synchronization synchronization = new Synchronization(result.getInt(0));
                synchronization.setTableName(result.getString(1));
                synchronization.setTableId(result.getInt(2));
                try {
                    synchronization.setDate(sdf.parse(result.getString(3)));
                } catch (ParseException e) {
                    synchronization.setDate(new java.util.Date());
                }
                synchronization.setDone(result.getInt(4) == 1);
                synchronization.setAction(result.getString(5));
                list.add(synchronization);
            }
        }
        return list;
    }

    /**
     * Trae el listado de sincronizaciones pendientes de la base de datos
     *
     * @return Listado de sincronizaciones pendientes de la base de datos
     */
    public ArrayList<Synchronization> listPending() {
        ArrayList<Synchronization> list = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT synchronization_id, table_name, table_id, date, done, [action] " +
                        "FROM synchronization " +
                        "WHERE done = 0",
                null)) {
            while (result.moveToNext()) {
                Synchronization synchronization = new Synchronization(result.getInt(0));
                synchronization.setTableName(result.getString(1));
                synchronization.setTableId(result.getInt(2));
                try {
                    synchronization.setDate(sdf.parse(result.getString(3)));
                } catch (ParseException e) {
                    synchronization.setDate(new java.util.Date());
                }
                synchronization.setDone(result.getInt(4) == 1);
                synchronization.setAction(result.getString(5));
                list.add(synchronization);
            }
        }
        return list;
    }

    /**
     * Crea una nueva sincronización
     *
     * @param synchronization Sincronización a insertar
     * @return Sincronización creada
     */
    public Synchronization create(Synchronization synchronization) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        ContentValues values = new ContentValues();
        values.put("table_name", synchronization.getTableName());
        values.put("table_id", synchronization.getTableId());
        values.put("date", sdf.format(synchronization.getDate()));
        values.put("done", synchronization.isDone() ? "1" : "0");
        values.put("[action]", synchronization.getAction());
        synchronization.setSynchronizationId((int) this.db.getWritableDatabase().insert(TABLE, null, values));
        return synchronization;
    }

    /**
     * Actualiza la sincronización en la base de datos
     *
     * @param synchronization Sincronización de la base de datos
     * @return Sincronización actualizada
     */
    public Synchronization update(Synchronization synchronization) {
        int total = 0;
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT COUNT(synchronization_id) AS total FROM synchronization " +
                        "WHERE table_name = ? AND table_id = ?",
                new String[]{synchronization.getTableName(), String.valueOf(synchronization.getTableId())}
        )) {
            while (result.moveToNext()) {
                total = result.getInt(0);
            }
        }
        if (total == 0) {
            return create(synchronization);
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            ContentValues values = new ContentValues();
            values.put("table_name", synchronization.getTableName());
            values.put("table_id", synchronization.getTableId());
            values.put("date", sdf.format(synchronization.getDate()));
            values.put("done", synchronization.isDone() ? "1" : "0");
            values.put("[action]", synchronization.getAction());
            this.db.getWritableDatabase().update(TABLE, values, "table_name = ? AND table_id = ?", new String[]{synchronization.getTableName(), String.valueOf(synchronization.getTableId())});
            return synchronization;
        }
    }

    /**
     * Elimina la sincronización de la base de datos
     *
     * @param synchronization Sincronización a eliminar
     * @return Sincronización eliminada
     */
    public Synchronization delete(Synchronization synchronization) {
        this.db.getWritableDatabase().delete(TABLE, "table_name = ? AND table_id = ?", new String[]{synchronization.getTableName(), String.valueOf(synchronization.getTableId())});
        return synchronization;
    }
    //endregion
}
