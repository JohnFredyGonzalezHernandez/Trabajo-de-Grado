package com.jhongonzalez.lecturadeantenas.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.UserDB;
import com.jhongonzalez.lecturadeantenas.entities.User;
import com.jhongonzalez.lecturadeantenas.utils.Session;
import com.jhongonzalez.lecturadeantenas.view.enb.ListEnbActivity;

public class LoginActivity extends AppCompatActivity {

    private UserDB dbMgr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        dbMgr = new UserDB(this);
    }

    /**
     * Cerrar la aplicación
     *
     * @param view Vista en la que se ejecuta el botón
     */
    public void closeApp(View view) {
        System.exit(0);
    }

    /**
     * Validar los datos ingresados para autenticar el usuario
     *
     * @param view Vista en la que se ejecuta el botón
     */
    public void login(View view) {
        String login = ((EditText) findViewById(R.id.txtUserLogin)).getText().toString();
        String password = ((EditText) findViewById(R.id.txtPasswordLogin)).getText().toString();
        User user = dbMgr.validate(login, password);
        if (user.getUserId() != 0) {
            Session.getInstance().setUser(user);
            startActivity(new Intent(this, ListEnbActivity.class));
        } else {
            Session.getInstance().setUser(null);
            Toast.makeText(this, R.string.error_login, Toast.LENGTH_SHORT).show();
        }
    }
}