package com.jhongonzalez.lecturadeantenas.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.City;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.entities.Regional;
import com.jhongonzalez.lecturadeantenas.entities.Sector;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Clase encargada de la persistencia de los sectores
 */
public class SectorDB {

    //region Atributos
    /**
     * Conexión a la base de datos
     */
    private final DatabaseHelper db;

    /**
     * Nombre de la tabla
     */
    private final String TABLE = "sector";

    //endregion

    //region Constructores

    /**
     * Crea la conexión a la base de datos
     *
     * @param context Contexto de la aplicación
     */
    public SectorDB(@Nullable Context context) {
        this.db = new DatabaseHelper(context);
    }

    //endregion

    //region Métodos

    /**
     * Trae el listado de sectores de la base de datos
     *
     * @param enb Enb del que se quieren listar los sectores
     * @return Listado de sectores de la base de datos
     */
    public ArrayList<Sector> list(Enb enb) {
        ArrayList<Sector> list = new ArrayList<>();
        try (Cursor result = this.db.getReadableDatabase().rawQuery("SELECT " +
                "s.sector_id, e.enb_id, e.name AS enb_name, " +
                "s.name, s.type, s.altitude_before, " +
                "s.azimuth_before, s.electric_tilt_before, s.mechanical_tilt_before, " +
                "s.altitude_after, s.azimuth_after, s.electric_tilt_after, " +
                "s.mechanical_tilt_after, a.aerial_id, a.name, " +
                "s.gnet_track, s.orientation_before, s.orientation_earth_before, " +
                "s.orientation_after, s.orientation_earth_after, s.latitude, " +
                "s.longitude " +
                "FROM " +
                "sector s " +
                "INNER JOIN enb e ON s.enb_id = e.enb_id " +
                "INNER JOIN aerial a ON s.aerial_id = a.aerial_id " +
                "WHERE s.enb_id = ?", new String[]{String.valueOf(enb.getEnbId())})) {
            while (result.moveToNext()) {
                Sector sector = new Sector(result.getInt(0));
                sector.setEnb(new Enb(result.getInt(1)));
                sector.getEnb().setName(result.getString(2));
                sector.setName(result.getString(3));
                sector.setType(result.getInt(4) == 1);
                sector.setAltitudeBefore(result.getInt(5));
                sector.setAzimuthBefore(result.getInt(6));
                sector.setElectricTiltBefore(result.getInt(7));
                sector.setMechanicalTiltBefore(result.getInt(8));
                sector.setAltitudeAfter(result.getInt(9));
                sector.setAzimuthAfter(result.getInt(10));
                sector.setElectricTiltAfter(result.getInt(11));
                sector.setMechanicalTiltAfter(result.getInt(12));
                sector.setAerial(new Aerial(result.getInt(13)));
                sector.getAerial().setName(result.getString(14));
                sector.setGnetTrack(result.getString(15));
                sector.setOrientationBefore(result.getString(16));
                sector.setOrientationEarthBefore(result.getString(17));
                sector.setOrientationAfter(result.getString(18));
                sector.setOrientationEarthAfter(result.getString(19));
                sector.setLatitude(result.getFloat(20));
                sector.setLongitude(result.getFloat(21));
                list.add(sector);
            }
        }
        return list;
    }

    /**
     * Trae un sector de la base de datos
     *
     * @param sector Sector a leer
     * @return Sector de la base de datos
     */
    public Sector read(Sector sector) {
        try (Cursor result = this.db.getReadableDatabase().rawQuery("SELECT " +
                "e.enb_id, e.name AS enb_name, " +
                "s.name, s.type, s.altitude_before, " +
                "s.azimuth_before, s.electric_tilt_before, s.mechanical_tilt_before, " +
                "s.altitude_after, s.azimuth_after, s.electric_tilt_after, " +
                "s.mechanical_tilt_after, a.aerial_id, a.name, " +
                "s.gnet_track, s.orientation_before, s.orientation_earth_before, " +
                "s.orientation_after, s.orientation_earth_after, s.latitude, " +
                "s.longitude " +
                "FROM " +
                "sector s " +
                "INNER JOIN enb e ON s.enb_id = e.enb_id " +
                "INNER JOIN aerial a ON s.aerial_id = a.aerial_id " +
                "WHERE s.sector_id = ?", new String[]{String.valueOf(sector.getSectorId())})) {
            while (result.moveToNext()) {
                sector.setEnb(new Enb(result.getInt(0)));
                sector.getEnb().setName(result.getString(1));
                sector.setName(result.getString(2));
                sector.setType(result.getInt(3) == 1);
                sector.setAltitudeBefore(result.getInt(4));
                sector.setAzimuthBefore(result.getInt(5));
                sector.setElectricTiltBefore(result.getInt(6));
                sector.setMechanicalTiltBefore(result.getInt(7));
                sector.setAltitudeAfter(result.getInt(8));
                sector.setAzimuthAfter(result.getInt(9));
                sector.setElectricTiltAfter(result.getInt(10));
                sector.setMechanicalTiltAfter(result.getInt(11));
                sector.setAerial(new Aerial(result.getInt(12)));
                sector.getAerial().setName(result.getString(13));
                sector.setGnetTrack(result.getString(14));
                sector.setOrientationBefore(result.getString(15));
                sector.setOrientationEarthBefore(result.getString(16));
                sector.setOrientationAfter(result.getString(17));
                sector.setOrientationEarthAfter(result.getString(18));
                sector.setLatitude(result.getFloat(19));
                sector.setLongitude(result.getFloat(20));
            }
        }
        return sector;
    }

    /**
     * Crea un nuevo sector
     *
     * @param sector Sector a insertar
     * @return Sector creado
     */
    public Sector create(Sector sector) {
        ContentValues values = new ContentValues();
        values.put("enb_id", sector.getEnb().getEnbId());
        values.put("name", sector.getName());
        values.put("type", sector.getType() ? "1" : "0");
        values.put("altitude_before", sector.getAltitudeBefore());
        values.put("azimuth_before", sector.getAzimuthBefore());
        values.put("electric_tilt_before", sector.getElectricTiltBefore());
        values.put("mechanical_tilt_before", sector.getMechanicalTiltBefore());
        values.put("altitude_after", sector.getAltitudeAfter());
        values.put("azimuth_after", sector.getAzimuthAfter());
        values.put("electric_tilt_after", sector.getElectricTiltAfter());
        values.put("mechanical_tilt_after", sector.getMechanicalTiltAfter());
        values.put("aerial_id", sector.getAerial().getAerialId());
        values.put("gnet_track", sector.getGnetTrack());
        values.put("orientation_before", sector.getOrientationBefore());
        values.put("orientation_earth_before", sector.getOrientationEarthBefore());
        values.put("orientation_after", sector.getOrientationAfter());
        values.put("orientation_earth_after", sector.getOrientationEarthAfter());
        values.put("latitude", sector.getLatitude());
        values.put("longitude", sector.getLongitude());
        sector.setSectorId((int) this.db.getWritableDatabase().insert(TABLE, null, values));
        return sector;
    }

    /**
     * Actualiza el sector en la base de datos
     *
     * @param sector Sector de la base de datos
     * @return Sector actualizada
     */
    public Sector update(Sector sector) {
        ContentValues values = new ContentValues();
        values.put("enb_id", sector.getEnb().getEnbId());
        values.put("name", sector.getName());
        values.put("type", sector.getType() ? "1" : "0");
        values.put("altitude_before", sector.getAltitudeBefore());
        values.put("azimuth_before", sector.getAzimuthBefore());
        values.put("electric_tilt_before", sector.getElectricTiltBefore());
        values.put("mechanical_tilt_before", sector.getMechanicalTiltBefore());
        values.put("altitude_after", sector.getAltitudeAfter());
        values.put("azimuth_after", sector.getAzimuthAfter());
        values.put("electric_tilt_after", sector.getElectricTiltAfter());
        values.put("mechanical_tilt_after", sector.getMechanicalTiltAfter());
        values.put("aerial_id", sector.getAerial().getAerialId());
        values.put("gnet_track", sector.getGnetTrack());
        values.put("orientation_before", sector.getOrientationBefore());
        values.put("orientation_earth_before", sector.getOrientationEarthBefore());
        values.put("orientation_after", sector.getOrientationAfter());
        values.put("orientation_earth_after", sector.getOrientationEarthAfter());
        values.put("latitude", sector.getLatitude());
        values.put("longitude", sector.getLongitude());
        this.db.getWritableDatabase().update(TABLE, values, "sector_id = ?", new String[]{String.valueOf(sector.getSectorId())});
        return sector;
    }

    /**
     * Elimina el sector de la base de datos
     *
     * @param sector Sector a eliminar
     * @return Sector eliminado
     */
    public Sector delete(Sector sector) {
        this.db.getWritableDatabase().delete(TABLE, "sector_id = ?", new String[]{String.valueOf(sector.getSectorId())});
        return sector;
    }
    //endregion
}
