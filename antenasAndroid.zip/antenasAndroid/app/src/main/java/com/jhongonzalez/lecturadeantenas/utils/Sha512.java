package com.jhongonzalez.lecturadeantenas.utils;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Sha512 {
    /**
     * Genera el SHA512 de una cadena de texto
     *
     * @param input Cadena de texto a la que se le genera el SHA512
     * @return SHA512 de una cadena de texto
     */
    public static String getSha512(String input) {
        MessageDigest digest = null;
        String hash = "";
        try {
            digest = MessageDigest.getInstance("SHA-512");
            digest.reset();
            digest.update(input.getBytes(StandardCharsets.UTF_8));
            hash = String.format("%0128x", new BigInteger(1, digest.digest()));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hash;
    }

}
