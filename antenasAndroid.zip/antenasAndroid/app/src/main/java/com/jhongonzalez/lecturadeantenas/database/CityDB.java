package com.jhongonzalez.lecturadeantenas.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.City;
import com.jhongonzalez.lecturadeantenas.entities.Regional;

import java.util.ArrayList;

/**
 * Clase encargada de la persistencia de las ciudades
 */
public class CityDB {

    //region Atributos
    /**
     * Conexión a la base de datos
     */
    private final DatabaseHelper db;

    /**
     * Nombre de la tabla
     */
    private final String TABLE = "city";

    //endregion

    //region Constructores

    /**
     * Crea la conexión a la base de datos
     *
     * @param context Contexto de la aplicación
     */
    public CityDB(@Nullable Context context) {
        this.db = new DatabaseHelper(context);
    }

    //endregion

    //region Métodos

    /**
     * Trae el listado de ciudades de la base de datos
     *
     * @return Listado de ciudades de la base de datos
     */
    public ArrayList<City> list() {
        ArrayList<City> list = new ArrayList<>();
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT c.city_id, c.name, r.regional_id, r.name AS regional_name " +
                        "FROM city c " +
                        "INNER JOIN regional r ON c.regional_id = r.regional_id", null)) {
            while (result.moveToNext()) {
                City city = new City(result.getInt(0));
                city.setName(result.getString(1));
                city.setRegional(new Regional(result.getInt(2)));
                city.getRegional().setName(result.getString(3));
                list.add(city);
            }
        }
        return list;
    }

    /**
     * Trae una ciudad de la base de datos
     *
     * @param city Ciudad a leer
     * @return Ciudad de la base de datos
     */
    public City read(City city) {
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT c.name, r.regional_id, r.name as regional " +
                        "FROM city c " +
                        "INNER JOIN regional r ON c.regional_id = r.regional_id " +
                        "WHERE c.city_id = ?",
                new String[]{String.valueOf(city.getCityId())})) {
            while (result.moveToNext()) {
                city.setName(result.getString(0));
                city.setRegional(new Regional(result.getInt(1)));
                city.getRegional().setName(result.getString(2));
            }
        }
        return city;
    }

    /**
     * Crea una nueva ciudad
     *
     * @param city Ciudad a insertar
     * @return Ciudad creada
     */
    public City create(City city) {
        ContentValues values = new ContentValues();
        values.put("name", city.getName());
        values.put("regional_id", city.getRegional().getRegionalId());
        city.setCityId((int) this.db.getWritableDatabase().insert(TABLE, null, values));
        return city;
    }

    /**
     * Actualiza la ciudad en la base de datos
     *
     * @param city Ciudad de la base de datos
     * @return Ciudad actualizada
     */
    public City update(City city) {
        ContentValues values = new ContentValues();
        values.put("name", city.getName());
        values.put("regional_id", city.getRegional().getRegionalId());
        this.db.getWritableDatabase().update(TABLE, values, "city_id = ?", new String[]{String.valueOf(city.getCityId())});
        return city;
    }

    /**
     * Elimina la ciudad de la base de datos
     *
     * @param city Ciudad a eliminar
     * @return Ciudad eliminada
     */
    public City delete(City city) {
        this.db.getWritableDatabase().delete(TABLE, "city_id = ?", new String[]{String.valueOf(city.getCityId())});
        return city;
    }

    /**
     * Trae el listado de ciudades que perteneces a una regional
     *
     * @param regional Regional por la que se filtran las ciudades
     * @return Listado de ciudades que perteneces a una regional
     */
    public ArrayList<City> listCitiesByRegional(Regional regional) {
        ArrayList<City> list = new ArrayList<>();
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT c.city_id, c.name, r.regional_id, r.name AS regional_name " +
                        "FROM city c " +
                        "INNER JOIN regional r ON c.regional_id = r.regional_id " +
                        "WHERE r.regional_id = ?", new String[]{String.valueOf(regional.getRegionalId())})) {
            while (result.moveToNext()) {
                City city = new City(result.getInt(0));
                city.setName(result.getString(1));
                city.setRegional(new Regional(result.getInt(2)));
                city.getRegional().setName(result.getString(3));
                list.add(city);
            }
        }
        return list;
    }
    //endregion
}
