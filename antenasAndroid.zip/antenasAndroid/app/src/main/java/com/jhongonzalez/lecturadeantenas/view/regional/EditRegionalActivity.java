package com.jhongonzalez.lecturadeantenas.view.regional;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.RegionalDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Regional;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

public class EditRegionalActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Regional a editar
     */
    private Regional regional;

    /**
     * Administrador de persistencia en bd de la regional
     */
    private RegionalDB regionalDB;

    /**
     * Administrador de persistencia para el envío de los datos al servidor
     */
    private SynchronizationDB synchronizationDB;

    /**
     * Caja de texto con el nombre de la regional
     */
    private EditText txtName;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crea la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_regional);
        regionalDB = new RegionalDB(this);
        synchronizationDB = new SynchronizationDB(this);
        regional = (Regional) getIntent().getSerializableExtra("regional");

        if (regional.getRegionalId() == 0) {
            this.setTitle(R.string.create_regional);
        } else {
            this.setTitle(R.string.edit_regional);
        }

        EditText txtId = findViewById(R.id.txtRegionalId);
        txtName = findViewById(R.id.txtRegionalName);
        Button btnSave = findViewById(R.id.btnSaveRegional);
        Button btnCancel = findViewById(R.id.btnCancelRegional);

        txtId.setText(String.valueOf(regional.getRegionalId()));
        txtId.setEnabled(false);
        txtName.setText(regional.getName());

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regional.setName(txtName.getText().toString());
                Synchronization sync = new Synchronization();
                sync.setTableName("regional");
                if (regional.getRegionalId() == 0) {
                    regional = regionalDB.create(regional);
                    sync.setAction("I");
                    Toast.makeText(EditRegionalActivity.this, R.string.regional_created, Toast.LENGTH_SHORT).show();
                } else {
                    regionalDB.update(regional);
                    sync.setAction("U");
                    Toast.makeText(EditRegionalActivity.this, R.string.regional_updates, Toast.LENGTH_SHORT).show();
                }
                sync.setTableId(regional.getRegionalId());
                synchronizationDB.create(sync);
                finish();
            }
        });
    }
    //endregion
}