package com.jhongonzalez.lecturadeantenas.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.Regional;

import java.util.ArrayList;

/**
 * Clase encargada de la persistencia de las regiones
 */
public class RegionalDB {

    //region Atributos
    /**
     * Conexión a la base de datos
     */
    private final DatabaseHelper db;

    /**
     * Nombre de la tabla
     */
    private final String TABLE = "regional";

    /**
     * Nombre de las columnas
     */
    private final String[] COLUMNS = {"regional_id", "name"};
    //endregion

    //region Constructores

    /**
     * Crea la conexión a la base de datos
     *
     * @param context Contexto de la aplicación
     */
    public RegionalDB(@Nullable Context context) {
        this.db = new DatabaseHelper(context);
    }

    //endregion

    //region Métodos

    /**
     * Trae el listado de regionales de la base de datos
     *
     * @return Listado de regionales de la base de datos
     */
    public ArrayList<Regional> list() {
        ArrayList<Regional> list = new ArrayList<>();
        try (Cursor result = this.db.getReadableDatabase().query(TABLE, COLUMNS,
                null,
                null,
                null,
                null,
                null)) {
            while (result.moveToNext()) {
                Regional regional = new Regional(result.getInt(0));
                regional.setName(result.getString(1));
                list.add(regional);
            }
        }
        return list;
    }

    /**
     * Trae una regional de la base de datos
     *
     * @param regional Regional a leer
     * @return Regional de la base de datos
     */
    public Regional read(Regional regional) {
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT name FROM regional WHERE regional_id = ?",
                new String[]{String.valueOf(regional.getRegionalId())})) {
            while (result.moveToNext()) {
                regional.setName(result.getString(0));
            }
        }
        return regional;
    }

    /**
     * Crea una nueva regional
     *
     * @param regional Regional a insertar
     * @return Regional creada
     */
    public Regional create(Regional regional) {
        ContentValues values = new ContentValues();
        values.put("name", regional.getName());
        regional.setRegionalId((int) this.db.getWritableDatabase().insert(TABLE, null, values));
        return regional;
    }

    /**
     * Actualiza la regional en la base de datos
     *
     * @param regional Regional de la base de datos
     * @return Regional actualizada
     */
    public Regional update(Regional regional) {
        ContentValues values = new ContentValues();
        values.put("name", regional.getName());
        this.db.getWritableDatabase().update(TABLE, values, "regional_id = ?", new String[]{String.valueOf(regional.getRegionalId())});
        return regional;
    }

    /**
     * Elimina la regional de la base de datos
     *
     * @param regional Regional a eliminar
     * @return Regional eliminada
     */
    public Regional delete(Regional regional) {
        this.db.getWritableDatabase().delete(TABLE, "regional_id = ?", new String[]{String.valueOf(regional.getRegionalId())});
        return regional;
    }
    //endregion
}
