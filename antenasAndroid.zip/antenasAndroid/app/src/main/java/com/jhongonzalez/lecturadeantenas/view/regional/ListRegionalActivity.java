package com.jhongonzalez.lecturadeantenas.view.regional;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.adapters.GridRegionalAdapter;
import com.jhongonzalez.lecturadeantenas.entities.Regional;

public class ListRegionalActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Adaptador de la tabla de regionales
     */
    private GridRegionalAdapter gridRegionalAdapter;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al iniciar la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_regional);
        this.setTitle(R.string.list_regionals);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView listRegionals = findViewById(R.id.listRegionals);
        FloatingActionButton fabAddRegional = findViewById(R.id.fabAddRegional);

        gridRegionalAdapter = new GridRegionalAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        listRegionals.setLayoutManager(mLayoutManager);
        listRegionals.setItemAnimator(new DefaultItemAnimator());
        listRegionals.setAdapter(gridRegionalAdapter);

        fabAddRegional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editRegional = new Intent(ListRegionalActivity.this, EditRegionalActivity.class);
                editRegional.putExtra("regional", new Regional());
                startActivity(editRegional);
            }
        });
    }

    /**
     * Se ejecuta al volver de otra actividad a esta
     */
    @Override
    public void onResume() {
        super.onResume();
        gridRegionalAdapter.update();
    }
    //endregion
}