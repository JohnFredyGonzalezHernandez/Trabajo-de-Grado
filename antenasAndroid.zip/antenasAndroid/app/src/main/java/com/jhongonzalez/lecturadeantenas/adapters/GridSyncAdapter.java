package com.jhongonzalez.lecturadeantenas.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

import java.util.ArrayList;

/**
 * Adaptador de la lista de sincronizaciones
 */
public class GridSyncAdapter extends RecyclerView.Adapter<GridSyncAdapter.SyncItemView> {

    //region Atributos
    /**
     * Administrador de base de datos de las sincronizaciones
     */
    private final SynchronizationDB synchronizationDB;

    /**
     * Contexto que llama este adapatador
     */
    private final Context context;

    /**
     * Listado de sincronizaciones
     */
    private ArrayList<Synchronization> list;
    //endregion

    //region Constructores

    /**
     * Crea el adaptador de sincronizaciones
     *
     * @param context Contexto de la aplicación
     */
    public GridSyncAdapter(@Nullable Context context) {
        this.context = context;
        synchronizationDB = new SynchronizationDB(context);
        list = synchronizationDB.listPending();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crear el visor de las filas del listado
     *
     * @param parent   Control padre del listado de sincronizaciones
     * @param viewType Tipo de vista
     * @return Vista del listado
     */
    @NonNull
    @Override
    public SyncItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowSync = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_sync_item, parent, false);
        return new SyncItemView(rowSync);
    }

    /**
     * Ocurre al visualizar un item de la lista
     *
     * @param viewRow  Fila seleccionada
     * @param position Posición seleccionada
     */
    @Override
    public void onBindViewHolder(@NonNull final SyncItemView viewRow, int position) {
        final Synchronization sync = list.get(position);
        viewRow.id.setText(String.valueOf(sync.getSynchronizationId()));
        viewRow.table_name.setText(sync.getTableName());
        viewRow.table_id.setText(String.valueOf(sync.getTableId()));
        viewRow.done.setText(sync.isDone() ? "Completo" : "Incompleto");
    }

    /**
     * Trae el número de items del listado
     *
     * @return Número de items del listado
     */
    @Override
    public int getItemCount() {
        return list.size();
    }

    /**
     * Actuaiza los datos
     */
    public void update() {
        list = synchronizationDB.listPending();
        this.notifyDataSetChanged();
    }

    /**
     * Trae el listado de registros a sincronizar
     *
     * @return Listado de registros a sincronizar
     */
    public ArrayList<Synchronization> getList() {
        return this.list;
    }
    //endregion

    //region Clase interna
    static class SyncItemView extends RecyclerView.ViewHolder {
        final TextView id;
        final TextView table_name;
        final TextView table_id;
        final TextView done;

        SyncItemView(View view) {
            super(view);
            this.id = view.findViewById(R.id.sync_id);
            this.table_name = view.findViewById(R.id.sync_table_name);
            this.table_id = view.findViewById(R.id.sync_table_id);
            this.done = view.findViewById(R.id.sync_done);
        }
    }
    //endregion
}
