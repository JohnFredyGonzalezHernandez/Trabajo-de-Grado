package com.jhongonzalez.lecturadeantenas.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.City;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.entities.Regional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Clase encargada de la persistencia de las enb
 */
public class EnbDB {

    //region Atributos
    /**
     * Conexión a la base de datos
     */
    private final DatabaseHelper db;

    /**
     * Nombre de la tabla
     */
    private final String TABLE = "enb";

    //endregion

    //region Constructores

    /**
     * Crea la conexión a la base de datos
     *
     * @param context Contexto de la aplicación
     */
    public EnbDB(@Nullable Context context) {
        this.db = new DatabaseHelper(context);
    }

    //endregion

    //region Métodos

    /**
     * Trae el listado de enb de la base de datos
     *
     * @return Listado de enb de la base de datos
     */
    public ArrayList<Enb> list() {
        ArrayList<Enb> list = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT " +
                        "e.enb_id, e.name, e.code, " +
                        "e.address, e.city_id, c.name as name_city, " +
                        "c.regional_id, r.name as name_regional, e.keys, " +
                        "e.request_eng, e.request_date, e.execute_eng, " +
                        "e.execute_date, e.reason, e.tec_observations, " +
                        "e.log_observations " +
                        "FROM " +
                        "enb e " +
                        "INNER JOIN city c ON e.city_id = c.city_id " +
                        "INNER JOIN regional r ON c.regional_id = r.regional_id", null)) {
            while (result.moveToNext()) {
                Enb enb = new Enb(result.getInt(0));
                enb.setName(result.getString(1));
                enb.setCode(result.getString(2));
                enb.setAddress(result.getString(3));
                enb.setCity(new City(result.getInt(4)));
                enb.getCity().setName(result.getString(5));
                enb.getCity().setRegional(new Regional(result.getInt(6)));
                enb.getCity().getRegional().setName(result.getString(7));
                enb.setKeys(result.getString(8));
                enb.setRequestEng(result.getString(9));
                try {
                    enb.setRequestDate(sdf.parse(result.getString(10)));
                } catch (ParseException e) {
                    enb.setRequestDate(new java.util.Date());
                }
                enb.setExecuteEng(result.getString(11));
                try {
                    enb.setExecuteDate(sdf.parse(result.getString(12)));
                } catch (ParseException e) {
                    enb.setExecuteDate(new java.util.Date());
                }
                enb.setReason(result.getString(13));
                enb.setTecObservations(result.getString(14));
                enb.setLogObservations(result.getString(15));
                list.add(enb);
            }
        }
        return list;
    }

    /**
     * Trae un enb de la base de datos
     *
     * @param enb Enb a leer
     * @return Enb de la base de datos
     */
    public Enb read(Enb enb) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT e.name, e.code, e.address, " +
                        "e.city_id, c.name as name_city, c.regional_id, " +
                        "r.name as name_regional, e.keys, e.request_eng, " +
                        "e.request_date, e.execute_eng, e.execute_date, " +
                        "e.reason, e.tec_observations, e.log_observations " +
                        "FROM " +
                        "enb e " +
                        "INNER JOIN city c ON e.city_id = c.city_id " +
                        "INNER JOIN regional r ON c.regional_id = r.regional_id WHERE enb_id = ?",
                new String[]{String.valueOf(enb.getEnbId())})) {
            while (result.moveToNext()) {
                enb.setName(result.getString(0));
                enb.setCode(result.getString(1));
                enb.setAddress(result.getString(2));
                enb.setCity(new City(result.getInt(3)));
                enb.getCity().setName(result.getString(4));
                enb.getCity().setRegional(new Regional(result.getInt(5)));
                enb.getCity().getRegional().setName(result.getString(6));
                enb.setKeys(result.getString(7));
                enb.setRequestEng(result.getString(8));
                try {
                    enb.setRequestDate(sdf.parse(result.getString(9)));
                } catch (ParseException e) {
                    enb.setRequestDate(new java.util.Date());
                }
                enb.setExecuteEng(result.getString(10));
                try {
                    enb.setExecuteDate(sdf.parse(result.getString(11)));
                } catch (ParseException e) {
                    enb.setExecuteDate(new java.util.Date());
                }
                enb.setReason(result.getString(12));
                enb.setTecObservations(result.getString(13));
                enb.setLogObservations(result.getString(14));
            }
        }
        return enb;
    }

    /**
     * Crea una nueva enb
     *
     * @param enb Enb a insertar
     * @return Enb creada
     */
    public Enb create(Enb enb) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        ContentValues values = new ContentValues();
        values.put("name", enb.getName());
        values.put("code", enb.getCode());
        values.put("address", enb.getAddress());
        values.put("city_id", enb.getCity().getCityId());
        values.put("keys", enb.getKeys());
        values.put("request_eng", enb.getRequestEng());
        values.put("request_date", sdf.format(enb.getRequestDate()));
        values.put("execute_eng", enb.getExecuteEng());
        values.put("execute_date", sdf.format(enb.getExecuteDate()));
        values.put("reason", enb.getReason());
        values.put("tec_observations", enb.getTecObservations());
        values.put("log_observations", enb.getLogObservations());
        enb.setEnbId((int) this.db.getWritableDatabase().insert(TABLE, null, values));
        return enb;
    }

    /**
     * Actualiza la enb en la base de datos
     *
     * @param enb Enb de la base de datos
     * @return Enb actualizada
     */
    public Enb update(Enb enb) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        ContentValues values = new ContentValues();
        values.put("name", enb.getName());
        values.put("code", enb.getCode());
        values.put("address", enb.getAddress());
        values.put("city_id", enb.getCity().getCityId());
        values.put("keys", enb.getKeys());
        values.put("request_eng", enb.getRequestEng());
        values.put("request_date", sdf.format(enb.getRequestDate()));
        values.put("execute_eng", enb.getExecuteEng());
        values.put("execute_date", sdf.format(enb.getExecuteDate()));
        values.put("reason", enb.getReason());
        values.put("tec_observations", enb.getTecObservations());
        values.put("log_observations", enb.getLogObservations());
        this.db.getWritableDatabase().update(TABLE, values, "enb_id = ?", new String[]{String.valueOf(enb.getEnbId())});
        return enb;
    }

    /**
     * Elimina la enb de la base de datos
     *
     * @param enb Enb a eliminar
     * @return Enb eliminada
     */
    public Enb delete(Enb enb) {
        this.db.getWritableDatabase().delete(TABLE, "enb_id = ?", new String[]{String.valueOf(enb.getEnbId())});
        return enb;
    }
    //endregion
}
