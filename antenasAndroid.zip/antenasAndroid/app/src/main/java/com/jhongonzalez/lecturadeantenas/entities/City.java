package com.jhongonzalez.lecturadeantenas.entities;

import java.io.Serializable;

/**
 * Ciudad a donde pertenece la antena
 */
public class City implements Serializable {

    //region Atributos
    /**
     * Identificador de la ciudad
     */
    private int cityId;

    /**
     * Nombre de la ciudad
     */
    private String name;

    /**
     * Región a la que pertenece la ciudad
     */
    private Regional regional;
    //endregion

    //region Constructores

    /**
     * Crea una ciudad con datos por defecto
     */
    public City() {
        this(0);
    }

    /**
     * Crea una ciudad con un identificador por defecto
     *
     * @param id Identificador de la ciudad
     */
    public City(int id) {
        this.cityId = id;
        this.name = "";
        this.regional = new Regional();
    }
    //endregion

    //region Métodos

    /**
     * Trae el identificador de la ciudad
     *
     * @return Identificador de la ciudad
     */
    public int getCityId() {
        return cityId;
    }

    /**
     * Cambia el identificador de la ciudad
     *
     * @param cityId Nuevo identificador de la ciudad
     */
    public void setCityId(int cityId) {
        this.cityId = cityId;
    }

    /**
     * Trae el nombre de la ciudad
     *
     * @return Nombre de la ciudad
     */
    public String getName() {
        return name;
    }

    /**
     * Cambia el nombre de la ciudad
     *
     * @param name Nuevo nombre de la ciudad
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Trae la región a al que pertenece la ciudad
     *
     * @return Región a al que pertenece la ciudad
     */
    public Regional getRegional() {
        return regional;
    }

    /**
     * Cambia la región a al que pertenece la ciudad
     *
     * @param regional Nueva región a al que pertenece la ciudad
     */
    public void setRegional(Regional regional) {
        this.regional = regional;
    }

    /**
     * Expresa la ciudad como un texto mostrando su nombre
     *
     * @return Nombre de la ciudad
     */
    @Override
    public String toString() {
        return name;
    }

    /**
     * Compara la ciudad actual con otra
     *
     * @param city Ciudad con la que se quiere comparar
     * @return Si son o no iguales
     */
    @Override
    public boolean equals(Object city) {
        if (city.getClass() != City.class) {
            return false;
        }
        return (((City) city).getCityId() == this.cityId);
    }
    //endregion
}
