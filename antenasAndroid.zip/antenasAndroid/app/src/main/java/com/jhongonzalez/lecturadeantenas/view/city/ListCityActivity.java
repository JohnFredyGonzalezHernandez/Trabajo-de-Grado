package com.jhongonzalez.lecturadeantenas.view.city;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.adapters.GridCityAdapter;
import com.jhongonzalez.lecturadeantenas.entities.City;

public class ListCityActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Adpatador de la tabla de ciudades
     */
    private GridCityAdapter gridCityAdapter;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al iniciar la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_city);
        this.setTitle(R.string.list_cities);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView listCities = findViewById(R.id.listCities);
        FloatingActionButton fabAddCity = findViewById(R.id.fabAddCity);

        gridCityAdapter = new GridCityAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        listCities.setLayoutManager(mLayoutManager);
        listCities.setItemAnimator(new DefaultItemAnimator());
        listCities.setAdapter(gridCityAdapter);

        fabAddCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editCity = new Intent(ListCityActivity.this, EditCityActivity.class);
                editCity.putExtra("city", new City());
                startActivity(editCity);
            }
        });
    }

    /**
     * Se ejecuta al volver de otra actividad a esta
     */
    @Override
    public void onResume() {
        super.onResume();
        gridCityAdapter.update();
    }
    //endregion
}