package com.jhongonzalez.lecturadeantenas.entities;

import java.io.Serializable;

/**
 * Sector o antena a la que se quiere tomar medidas
 */
public class Sector implements Serializable {

    //region Atributos
    /**
     * Identificador del sector
     */
    private int sectorId;

    /**
     * Enb al que pertenece el sector
     */
    private Enb enb;

    /**
     * Nombre del sector
     */
    private String name;

    /**
     * Tipo de medida usada (false: ABC, true: XYZ)
     */
    private boolean type;

    /**
     * Altitud sobre el suelo anterior a ser intervenida
     */
    private int altitudeBefore;

    /**
     * Medida del azimuth anterior a ser intervenida
     */
    private int azimuthBefore;

    /**
     * Medida del tilt eléctrico de la antena anterior a ser intervenida
     */
    private int electricTiltBefore;

    /**
     * Medida del tilt mecánico de la antena anterior a ser intervenida
     */
    private int mechanicalTiltBefore;

    /**
     * Altitud sobre el suelo posterior a ser intervenida
     */
    private int altitudeAfter;

    /**
     * Medida del azimuth posterior a ser intervenida
     */
    private int azimuthAfter;

    /**
     * Medida del tilt eléctrico de la antena posterior a ser intervenida
     */
    private int electricTiltAfter;

    /**
     * Medida del tilt mecánico de la antena posterior a ser intervenida
     */
    private int mechanicalTiltAfter;

    /**
     * Tipo de antena
     */
    private Aerial aerial;

    /**
     * Ruta de la imagen tomada del Gnet Track
     */
    private String gnetTrack;

    /**
     * Ruta de la imagen tomada de la orientación anterior a ser intervenida
     */
    private String orientationBefore;

    /**
     * Ruta de la imagen de Google Earth tomada de la orientación anterior a ser intervenida
     */
    private String orientationEarthBefore;

    /**
     * Ruta de la imagen tomada de la orientación posterior a ser intervenida
     */
    private String orientationAfter;

    /**
     * Ruta de la imagen de Google Earth tomada de la orientación posterior a ser intervenida
     */
    private String orientationEarthAfter;

    /**
     * Latitud geográfica de la antena intervenida
     */
    private float latitude;

    /**
     * Longitud geográfica de la antena intervenida
     */
    private float longitude;
    //endregion

    //region Constructores

    /**
     * Crea un sector con datos por defecto
     */
    public Sector() {
        this(0);
    }

    /**
     * Crea un sector con un identificador por defecto
     *
     * @param id Identificador del sector
     */
    public Sector(int id) {
        this.sectorId = id;
        this.enb = new Enb();
        this.name = "";
        this.type = false;
        this.altitudeBefore = 0;
        this.azimuthBefore = 0;
        this.electricTiltBefore = 0;
        this.mechanicalTiltBefore = 0;
        this.altitudeAfter = 0;
        this.azimuthAfter = 0;
        this.electricTiltAfter = 0;
        this.mechanicalTiltAfter = 0;
        this.aerial = new Aerial();
        this.gnetTrack = "";
        this.orientationBefore = "";
        this.orientationEarthBefore = "";
        this.orientationAfter = "";
        this.orientationEarthAfter = "";
        this.latitude = 0;
        this.longitude = 0;
    }

    //endregion

    //region Métodos

    /**
     * Trae el identificador del sector
     *
     * @return Identificador del sector
     */
    public int getSectorId() {
        return sectorId;
    }

    /**
     * Cambia el identificador del sector
     *
     * @param sectorId Nuevo identificador del sector
     */
    public void setSectorId(int sectorId) {
        this.sectorId = sectorId;
    }

    /**
     * Trae el enb al que pertenece del sector
     *
     * @return Enb al que pertenece del sector
     */
    public Enb getEnb() {
        return enb;
    }

    /**
     * Cambia el enb al que pertenece del sector
     *
     * @param enb Nuevo enb al que pertenece del sector
     */
    public void setEnb(Enb enb) {
        this.enb = enb;
    }

    /**
     * Trae el nombre del sector
     *
     * @return Nombre del sector
     */
    public String getName() {
        return name;
    }

    /**
     * Cambia el nombre del sector
     *
     * @param name Nuevo nombre del sector
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Trae el tipo de sector
     *
     * @return Tipo de sector
     */
    public boolean getType() {
        return type;
    }

    /**
     * Cambia el tipo de sector
     *
     * @param type Nuevo tipo de sector
     */
    public void setType(boolean type) {
        this.type = type;
    }

    /**
     * Trae la altitud sobre el suelo anterior a ser intervenida
     *
     * @return Altitud sobre el suelo anterior a ser intervenida
     */
    public int getAltitudeBefore() {
        return altitudeBefore;
    }

    /**
     * Cambia la altitud sobre el suelo anterior a ser intervenida
     *
     * @param altitudeBefore Nueva altitud sobre el suelo anterior a ser intervenida
     */
    public void setAltitudeBefore(int altitudeBefore) {
        this.altitudeBefore = altitudeBefore;
    }

    /**
     * Trae el azimut anterior a ser intervenida
     *
     * @return Azimuth anterior a ser intervenida
     */
    public int getAzimuthBefore() {
        return azimuthBefore;
    }

    /**
     * Cambia el azimut anterior a ser intervenida
     *
     * @param azimuthBefore Nuevo azimut anterior a ser intervenida
     */
    public void setAzimuthBefore(int azimuthBefore) {
        this.azimuthBefore = azimuthBefore;
    }

    /**
     * Trae el electric tilt anterior a ser intervenida
     *
     * @return Electric tilt anterior a ser intervenida
     */
    public int getElectricTiltBefore() {
        return electricTiltBefore;
    }

    /**
     * Cambia el electric tilt anterior a ser intervenida
     *
     * @param electricTiltBefore Nuevo electric tilt anterior a ser intervenida
     */
    public void setElectricTiltBefore(int electricTiltBefore) {
        this.electricTiltBefore = electricTiltBefore;
    }

    /**
     * Trae el mechanical tilt anterior a ser intervenida
     *
     * @return Mechanical tilt anterior a ser intervenida
     */
    public int getMechanicalTiltBefore() {
        return mechanicalTiltBefore;
    }

    /**
     * Cambia el mechanical tilt anterior a ser intervenida
     *
     * @param mechanicalTiltBefore Nuevo mechanical tilt anterior a ser intervenida
     */
    public void setMechanicalTiltBefore(int mechanicalTiltBefore) {
        this.mechanicalTiltBefore = mechanicalTiltBefore;
    }

    /**
     * Trae la altitud sobre el suelo posterior a ser intervenida
     *
     * @return Altitud sobre el suelo posterior a ser intervenida
     */
    public int getAltitudeAfter() {
        return altitudeAfter;
    }

    /**
     * Cambia la altitud sobre el suelo posterior a ser intervenida
     *
     * @param altitudeAfter Nueva altitud sobre el suelo posterior a ser intervenida
     */
    public void setAltitudeAfter(int altitudeAfter) {
        this.altitudeAfter = altitudeAfter;
    }

    /**
     * Trae el azimut posterior a ser intervenida
     *
     * @return Azimuth posterior a ser intervenida
     */
    public int getAzimuthAfter() {
        return azimuthAfter;
    }

    /**
     * Cambia el azimut posterior a ser intervenida
     *
     * @param azimuthAfter Nuevo azimut posterior a ser intervenida
     */
    public void setAzimuthAfter(int azimuthAfter) {
        this.azimuthAfter = azimuthAfter;
    }

    /**
     * Trae el electric tilt posterior a ser intervenida
     *
     * @return Electric tilt posterior a ser intervenida
     */
    public int getElectricTiltAfter() {
        return electricTiltAfter;
    }

    /**
     * Cambia el electric tilt posterior a ser intervenida
     *
     * @param electricTiltAfter Nuevo electric tilt posterior a ser intervenida
     */
    public void setElectricTiltAfter(int electricTiltAfter) {
        this.electricTiltAfter = electricTiltAfter;
    }

    /**
     * Trae el mechanical tilt posterior a ser intervenida
     *
     * @return Mechanical tilt posterior a ser intervenida
     */
    public int getMechanicalTiltAfter() {
        return mechanicalTiltAfter;
    }

    /**
     * Cambia el mechanical tilt posterior a ser intervenida
     *
     * @param mechanicalTiltAfter Nuevo mechanical tilt posterior a ser intervenida
     */
    public void setMechanicalTiltAfter(int mechanicalTiltAfter) {
        this.mechanicalTiltAfter = mechanicalTiltAfter;
    }

    /**
     * Trae el tipo de antena a ser intervenida
     *
     * @return Tipo de antena a ser intervenida
     */
    public Aerial getAerial() {
        return aerial;
    }

    /**
     * Cambia el tipo de antena a ser intervenida
     *
     * @param aerial Nuevo tipo de antena a ser intervenida
     */
    public void setAerial(Aerial aerial) {
        this.aerial = aerial;
    }

    /**
     * Trae la ruta de la imagen del Gnet Track
     *
     * @return Ruta de la imagen del Gnet Track
     */
    public String getGnetTrack() {
        return gnetTrack;
    }

    /**
     * Cambia la ruta de la imagen del Gnet Track
     *
     * @param gnetTrack Nueva ruta de la imagen del Gnet Track
     */
    public void setGnetTrack(String gnetTrack) {
        this.gnetTrack = gnetTrack;
    }

    /**
     * Trae la ruta de la imagen de la orientación anterior a ser intervenida
     *
     * @return Ruta de la imagen de la orientación anterior a ser intervenida
     */
    public String getOrientationBefore() {
        return orientationBefore;
    }

    /**
     * Cambia la ruta de la imagen de la orientación anterior a ser intervenida
     *
     * @param orientationBefore Nueva ruta de la imagen de la orientación anterior a ser intervenida
     */
    public void setOrientationBefore(String orientationBefore) {
        this.orientationBefore = orientationBefore;
    }

    /**
     * Trae la ruta de la imagen de Google Earth de la orientación anterior a ser intervenida
     *
     * @return Ruta de la imagen de Google Earth de la orientación anterior a ser intervenida
     */
    public String getOrientationEarthBefore() {
        return orientationEarthBefore;
    }

    /**
     * Cambia la ruta de la imagen de Google Earth de la orientación anterior a ser intervenida
     *
     * @param orientationEarthBefore Nueva ruta de la imagen de Google Earth de la orientación anterior a ser intervenida
     */
    public void setOrientationEarthBefore(String orientationEarthBefore) {
        this.orientationEarthBefore = orientationEarthBefore;
    }

    /**
     * Trae la ruta de la imagen de la orientación posterior a ser intervenida
     *
     * @return Ruta de la imagen de la orientación posterior a ser intervenida
     */
    public String getOrientationAfter() {
        return orientationAfter;
    }

    /**
     * Cambia la ruta de la imagen de la orientación posterior a ser intervenida
     *
     * @param orientationAfter Nueva ruta de la imagen de la posterior anterior a ser intervenida
     */
    public void setOrientationAfter(String orientationAfter) {
        this.orientationAfter = orientationAfter;
    }

    /**
     * Trae la ruta de la imagen de Google Earth de la orientación posterior a ser intervenida
     *
     * @return Ruta de la imagen de Google Earth de la orientación posterior a ser intervenida
     */
    public String getOrientationEarthAfter() {
        return orientationEarthAfter;
    }

    /**
     * Cambia la ruta de la imagen de Google Earth de la orientación posterior a ser intervenida
     *
     * @param orientationEarthAfter Nueva ruta de la imagen de Google Earth de la orientación posterior a ser intervenida
     */
    public void setOrientationEarthAfter(String orientationEarthAfter) {
        this.orientationEarthAfter = orientationEarthAfter;
    }

    /**
     * Trae la latitud de la antena intervenida
     *
     * @return Latitud de la antena intervenida
     */
    public float getLatitude() {
        return latitude;
    }

    /**
     * Cambia la latitud de la antena intervenida
     *
     * @param latitude Nueva latitud de la antena intervenida
     */
    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    /**
     * Trae la longitud de la antena intervenida
     *
     * @return Longitud de la antena intervenida
     */
    public float getLongitude() {
        return longitude;
    }

    /**
     * Cambia la longitud de la antena intervenida
     *
     * @param longitude Nueva longitud de la antena intervenida
     */
    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    /**
     * Compara el sector actual con otro
     *
     * @param sector Sector con el que se quiere comparar
     * @return Si son o no iguales
     */
    @Override
    public boolean equals(Object sector) {
        if (sector.getClass() != Sector.class) {
            return false;
        }
        return (((Sector) sector).getSectorId() == this.sectorId);
    }
    //endregion
}
