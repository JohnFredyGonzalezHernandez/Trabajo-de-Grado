package com.jhongonzalez.lecturadeantenas.entities;

import java.io.Serializable;

/**
 * Datos de un usuario de la aplicación
 */
public class User implements Serializable {

    //region Atributos
    /**
     * Identificador del usuario
     */
    private int userId;

    /**
     * Nombre de usuario de acceso
     */
    private String userame;

    /**
     * Si es administrador o no
     */
    private boolean admin;
    //endregion

    //region Constructores

    /**
     * Crea un usuario con datos por defecto
     */
    public User() {
        this(0);
    }

    /**
     * Crea un usuario con un identificador por defecto
     *
     * @param id Identificador del usuario
     */
    public User(int id) {
        this.userId = id;
        this.userame = "";
        this.admin = false;
    }
    //endregion

    //region Métodos

    /**
     * Trae el identificador del usuario
     *
     * @return Identificador del usuario
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Cambia el identificador del usuario
     *
     * @param userId Nuevo identificador del usuario
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * Trae el nombre del usuario
     *
     * @return Nombre del usuario
     */
    public String getUserame() {
        return userame;
    }

    /**
     * Cambia el nombre del usuario
     *
     * @param username Nuevo nombre del usuario
     */
    public void setUsername(String username) {
        this.userame = username;
    }

    /**
     * Trae si el usuario es o no administrador
     *
     * @return Si el usuario es o no administrador
     */
    public boolean isAdmin() {
        return admin;
    }

    /**
     * Cambia el indicador si el usuario es o no administrador
     *
     * @param admin Nuevo indicador si el usuario es o no administrador
     */
    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    //endregion
}
