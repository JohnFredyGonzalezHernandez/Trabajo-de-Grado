package com.jhongonzalez.lecturadeantenas.view.enb;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.CityDB;
import com.jhongonzalez.lecturadeantenas.database.EnbDB;
import com.jhongonzalez.lecturadeantenas.database.RegionalDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.City;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.entities.Regional;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class EditEnbActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Enb a editar
     */
    private Enb enb;

    /**
     * Administrador de persistencia en bd del enb
     */
    private EnbDB enbDB;

    /**
     * Administrador de persistencia para el envío de los datos al servidor
     */
    private SynchronizationDB synchronizationDB;

    /**
     * Administrador de persistencia de las ciudades
     */
    private CityDB cityDB;

    /**
     * Listado de ciudades de una regional dterminada
     */
    private ArrayList<City> listCitiesByRegional;

    /**
     * Caja de texto con el nombre del enb
     */
    private EditText txtName;

    /**
     * Caja de texto con el código del enb
     */
    private EditText txtCode;

    /**
     * Caja de texto con la dirección del enb
     */
    private EditText txtAddress;

    /**
     * Combo con el listado de regionales
     */
    private Spinner cmbRegional;

    /**
     * Combo con el listado de ciudades de la regional seleccionada
     */
    private Spinner cmbCity;

    /**
     * Caja de texto con las llaves del enb
     */
    private EditText txtKeys;

    /**
     * Caja de texto con el nombre del ingeniero que solicita el mantenimiento del enb
     */
    private EditText txtRequestEng;

    /**
     * Caja de texto con la fecha de solicitud de mantenimiento del enb
     */
    private EditText txtRequestDate;

    /**
     * Caja de texto con el nombre del ingeniero que ejecuta el mantenimiento del enb
     */
    private EditText txtExecuteEng;

    /**
     * Caja de texto con la fecha de ejecución del mantenimiento del enb
     */
    private EditText txtExecuteDate;

    /**
     * Caja de texto con las razones del mantenimiento del enb
     */
    private EditText txtReason;

    /**
     * Caja de texto con las observaciones técnicas del mantenimiento del enb
     */
    private EditText txtTecObservations;

    /**
     * Caja de texto con las observaciones logísticas del mantenimiento del enb
     */
    private EditText txtLogObservations;

    /**
     * Adaptador del combo de ciudades
     */
    private ArrayAdapter<City> cityAdapter;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crea la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_enb);
        RegionalDB regionalDB = new RegionalDB(this);
        cityDB = new CityDB(this);
        enbDB = new EnbDB(this);
        synchronizationDB = new SynchronizationDB(this);

        listCitiesByRegional = new ArrayList<>();

        ArrayAdapter<Regional> regionalAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, regionalDB.list());
        cityAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, listCitiesByRegional);

        enb = (Enb) getIntent().getSerializableExtra("enb");

        EditText txtId = findViewById(R.id.txtEnbId);
        txtId.setText(String.valueOf(enb.getEnbId()));

        txtName = findViewById(R.id.txtEnbName);
        txtName.setText(enb.getName());

        txtCode = findViewById(R.id.txtEnbCode);
        txtCode.setText(enb.getCode());

        txtAddress = findViewById(R.id.txtEnbAddress);
        txtAddress.setText(enb.getAddress());

        cmbRegional = findViewById(R.id.cmbEnbRegional);
        cmbRegional.setAdapter(regionalAdapter);
        cmbRegional.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                listCitiesByRegional = cityDB.listCitiesByRegional((Regional) cmbRegional.getSelectedItem());
                cityAdapter.clear();
                cityAdapter.addAll(listCitiesByRegional);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                cityAdapter.clear();
            }
        });
        cmbRegional.setSelection(regionalAdapter.getPosition(enb.getCity().getRegional()));

        cmbCity = findViewById(R.id.cmbEnbCity);
        cmbCity.setAdapter(cityAdapter);
        cmbCity.setSelection(cityAdapter.getPosition(enb.getCity()));

        txtKeys = findViewById(R.id.txtEnbKeys);
        txtKeys.setText(enb.getKeys());

        txtRequestEng = findViewById(R.id.txtEnbRequestEng);
        txtRequestEng.setText(enb.getRequestEng());

        txtRequestDate = findViewById(R.id.txtEnbRequestDate);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        txtRequestDate.setText(sdf.format(enb.getRequestDate()));
        txtRequestDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(enb.getRequestDate());
                DatePickerDialog dpd = new DatePickerDialog(EditEnbActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        txtRequestDate.setText(String.format("%02d/%02d/%04d", day, (month + 1), year));
                    }
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
                dpd.show();
            }
        });

        txtExecuteEng = findViewById(R.id.txtEnbExecuteEng);
        txtExecuteEng.setText(enb.getExecuteEng());

        txtExecuteDate = findViewById(R.id.txtEnbExecuteDate);
        txtExecuteDate.setText(sdf.format(enb.getExecuteDate()));
        txtExecuteDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(enb.getExecuteDate());
                DatePickerDialog dpd = new DatePickerDialog(EditEnbActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        txtExecuteDate.setText(String.format("%02d/%02d/%04d", day, (month + 1), year));
                    }
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
                dpd.show();
            }
        });

        txtReason = findViewById(R.id.txtEnbReason);
        txtReason.setText(enb.getReason());

        txtTecObservations = findViewById(R.id.txtEnbTecObservations);
        txtTecObservations.setText(enb.getTecObservations());

        txtLogObservations = findViewById(R.id.txtEnbLogObservations);
        txtLogObservations.setText(enb.getLogObservations());

        Button btnSave = findViewById(R.id.btnSaveEnb);
        Button btnCancel = findViewById(R.id.btnCancelEnb);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                enb.setName(txtName.getText().toString());
                enb.setCode(txtCode.getText().toString());
                enb.setAddress(txtAddress.getText().toString());
                enb.setCity((City) cmbCity.getSelectedItem());
                enb.setKeys(txtKeys.getText().toString());
                enb.setRequestEng(txtRequestEng.getText().toString());
                try {
                    enb.setRequestDate(sdf.parse(txtRequestDate.getText().toString()));
                } catch (ParseException e) {
                    enb.setRequestDate(new Date());
                }
                enb.setExecuteEng(txtExecuteEng.getText().toString());
                try {
                    enb.setExecuteDate(sdf.parse(txtExecuteDate.getText().toString()));
                } catch (ParseException e) {
                    enb.setExecuteDate(new Date());
                }
                enb.setReason(txtReason.getText().toString());
                enb.setTecObservations(txtTecObservations.getText().toString());
                enb.setLogObservations(txtLogObservations.getText().toString());

                Synchronization sync = new Synchronization();
                sync.setTableName("enb");
                if (enb.getEnbId() == 0) {
                    enb = enbDB.create(enb);
                    sync.setAction("I");
                    Toast.makeText(EditEnbActivity.this, R.string.enb_created, Toast.LENGTH_SHORT).show();
                } else {
                    enbDB.update(enb);
                    sync.setAction("U");
                    Toast.makeText(EditEnbActivity.this, R.string.enb_updated, Toast.LENGTH_SHORT).show();
                }
                sync.setTableId(enb.getEnbId());
                synchronizationDB.create(sync);
                finish();
            }
        });
    }
    //endregion
}