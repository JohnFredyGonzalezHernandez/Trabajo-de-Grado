package com.jhongonzalez.lecturadeantenas.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.utils.Sha512;

public class DatabaseHelper extends SQLiteOpenHelper {

    //region Atributos
    /**
     * Nombre de la base de datos
     */
    private static final String DB_NAME = "aerials";

    /**
     * Versión actual de la base de datos
     */
    private static final int DB_VERSION = 1;

    /**
     * Instrucción de creación de la tabla regional
     */
    private static final String CREATE_TABLE_REGIONAL = "CREATE TABLE regional (" +
            "regional_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "name VARCHAR (100) NOT NULL)";

    /**
     * Instrucción de creación de la tabla city
     */
    private static final String CREATE_TABLE_CITY = "CREATE TABLE city (" +
            "city_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "name VARCHAR (100) NOT NULL, " +
            "regional_id INT REFERENCES regional (regional_id) ON DELETE RESTRICT ON UPDATE RESTRICT NOT NULL)";

    /**
     * Instrucción de creación de la tabla enb
     */
    private static final String CREATE_TABLE_ENB = "CREATE TABLE enb (" +
            "enb_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "name VARCHAR (100) NOT NULL, " +
            "code VARCHAR (20)  NOT NULL, " +
            "address VARCHAR (200) NOT NULL, " +
            "city_id INT NOT NULL REFERENCES city (city_id) ON DELETE RESTRICT ON UPDATE RESTRICT, " +
            "keys VARCHAR (100) NOT NULL, " +
            "request_eng VARCHAR (100) NOT NULL, " +
            "request_date DATE NOT NULL, " +
            "execute_eng VARCHAR (100) NOT NULL, " +
            "execute_date DATE NOT NULL," +
            "reason VARCHAR (200) NOT NULL, " +
            "tec_observations VARCHAR (200) NOT NULL, " +
            "log_observations VARCHAR (200) NOT NULL)";

    /**
     * Instrucción de creación de la tabla aerial
     */
    private static final String CREATE_TABLE_AERIAL = "CREATE TABLE aerial (" +
            "aerial_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "name VARCHAR (100) NOT NULL)";

    /**
     * Instrucción de creación de la tabla sector
     */
    private static final String CREATE_TABLE_SECTOR = "CREATE TABLE sector (" +
            "sector_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "enb_id INTEGER REFERENCES enb (enb_id) ON DELETE RESTRICT ON UPDATE RESTRICT NOT NULL, " +
            "name VARCHAR (50) NOT NULL, " +
            "type BOOLEAN NOT NULL, " +
            "altitude_before INTEGER NOT NULL, " +
            "azimuth_before INTEGER NOT NULL, " +
            "electric_tilt_before INTEGER NOT NULL, " +
            "mechanical_tilt_before INTEGER NOT NULL, " +
            "altitude_after INTEGER NOT NULL, " +
            "azimuth_after INTEGER NOT NULL, " +
            "electric_tilt_after INTEGER NOT NULL, " +
            "mechanical_tilt_after INTEGER NOT NULL, " +
            "aerial_id INTEGER REFERENCES aerial (aerial_id) ON DELETE RESTRICT ON UPDATE RESTRICT NOT NULL, " +
            "gnet_track VARCHAR (100) NOT NULL, " +
            "orientation_before VARCHAR (100) NOT NULL, " +
            "orientation_earth_before VARCHAR (100) NOT NULL, " +
            "orientation_after VARCHAR (100) NOT NULL, " +
            "orientation_earth_after VARCHAR (100) NOT NULL, " +
            "latitude DECIMAL (10, 8) NOT NULL, " +
            "longitude DECIMAL (10, 8) NOT NULL)";

    /**
     * Instrucción de creación de la tabla synchronization
     */
    private static final String CREATE_TABLE_SYNCHRONIZATION = "CREATE TABLE synchronization ( " +
            "synchronization_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "table_name VARCHAR (25) NOT NULL, " +
            "table_id INT NOT NULL, " +
            "date DATETIME NOT NULL, " +
            "done BOOLEAN NOT NULL, " +
            "[action] CHAR (1) NOT NULL)";

    private static final String CREATE_TABLE_USER = "CREATE TABLE user (" +
            "user_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "username VARCHAR (50) UNIQUE NOT NULL, " +
            "password VARCHAR (128) NOT NULL, " +
            "admin BOOLEAN NOT NULL)";

    /**
     * Inserción de los datos de la tabla regional
     */
    private static final String INSERT_REGIONALS = "INSERT INTO regional (name) VALUES " +
            "('NORTE'), ('CENTRO'), ('SUR')";

    /**
     * Inserción de los datos de la tabla city
     */
    private static final String INSERT_CITIES = "INSERT INTO city (name, regional_id) VALUES " +
            "('MEDELLIN', 1), ('CALI', 3), ('BOGOTA', 2)";

    private static final String INSERT_AERIALS = "INSERT INTO aerial (name) VALUES " +
            "('HBXX-6516DS-VTM')";

    private static final String INSERT_USERS = "INSERT INTO user (username, password, admin) VALUES " +
            "('admin', '" + Sha512.getSha512("admin") + "', 1), ('jhon', '" + Sha512.getSha512("123456") + "', 0)";

    //endregion

    //region Constructores

    /**
     * Crea la base de datos si no existe o la actualiza si es una nueva versión
     *
     * @param context Contexto de la aplicación
     */
    public DatabaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crearse la base de datos
     *
     * @param db Enlace a la base de datos
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_REGIONAL);
        db.execSQL(CREATE_TABLE_CITY);
        db.execSQL(CREATE_TABLE_ENB);
        db.execSQL(CREATE_TABLE_AERIAL);
        db.execSQL(CREATE_TABLE_SECTOR);
        db.execSQL(CREATE_TABLE_SYNCHRONIZATION);
        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(INSERT_REGIONALS);
        db.execSQL(INSERT_CITIES);
        db.execSQL(INSERT_AERIALS);
        db.execSQL(INSERT_USERS);
    }

    /**
     * Se ejecuta al actualizar la base de datos a una versión más reciente
     *
     * @param db         Enlace a la base de datos
     * @param oldVersion Versión anterior de la base de datos
     * @param newVersion Nueva versión de la base de datos
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    //endregion
}
