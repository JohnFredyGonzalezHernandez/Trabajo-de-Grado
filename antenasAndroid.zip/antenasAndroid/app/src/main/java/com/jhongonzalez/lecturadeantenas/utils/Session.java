package com.jhongonzalez.lecturadeantenas.utils;

import com.jhongonzalez.lecturadeantenas.entities.User;

public class Session {
    //region Atributos

    /**
     * Única instancia de la clase para el manejo de los datos de sesión de la aplicación
     */
    private static Session instance = null;

    /**
     * Usuario logueado en la aplicación
     */
    private User user;

    //endregion

    //region Constructores

    /**
     * Crea una nueva instancia de la clase Session
     */
    private Session() {
        user = null;
    }
    //endregion

    //region Métodos

    /**
     * Trae la única instancia de esta clase
     *
     * @return Única instancia de esta clase
     */
    public static Session getInstance() {
        if (instance == null) {
            instance = new Session();
        }
        return instance;
    }

    /**
     * Trae el usuario logueado en la aplicación o null si no hay ningún usuario logueado
     *
     * @return Usuario logueado en la aplicación o null si no hay ningún usuario logueado
     */
    public User getUser() {
        return user;
    }

    /**
     * Cambia el usuario logueado en la aplicación o null si no hay ningún usuario logueado
     *
     * @param user Usuario logueado en la aplicación o null si no hay ningún usuario logueado
     */
    public void setUser(User user) {
        this.user = user;
    }
    //endregion
}
