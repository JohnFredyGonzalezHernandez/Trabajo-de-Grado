package com.jhongonzalez.lecturadeantenas.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.entities.User;
import com.jhongonzalez.lecturadeantenas.utils.Sha512;

/**
 * Clase encargada de la persistencia de los usuarios
 */
public class UserDB {

    //region Atributos
    /**
     * Conexión a la base de datos
     */
    private final DatabaseHelper db;

    /**
     * Nombre de la tabla
     */
    private final String TABLE = "user";

    /**
     * Nombre de las columnas
     */
    private final String[] COLUMNS = {"user_id", "username", "password", "admin"};
    //endregion

    //region Constructores

    /**
     * Crea la conexión a la base de datos
     *
     * @param context Contexto de la aplicación
     */
    public UserDB(@Nullable Context context) {
        this.db = new DatabaseHelper(context);
    }

    //endregion

    //region Métodos

    /**
     * Actualiza la contraseña de un usuario en la base de datos
     *
     * @param user     Usuario de la base de datos
     * @param password contraseña nueva del usuario de la base de datos
     * @return Usuario actualizado
     */
    public User update(User user, String password) {
        ContentValues values = new ContentValues();
        values.put("password", Sha512.getSha512(password));
        this.db.getWritableDatabase().update(TABLE, values, "user_id = ?", new String[]{String.valueOf(user.getUserId())});
        return user;
    }

    /**
     * Trae un usuario cuyo username y password correspondan a los entregados
     *
     * @return Usuario que corresponde a los datos entregados o un usuario con valores por defecto
     * si no encuentra un usuario que corresponda con dichos datos
     */
    public User validate(String username, String password) {
        User user = new User();
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT user_id, username, admin FROM user WHERE username = ? AND password = ?",
                new String[]{username, Sha512.getSha512(password)})) {
            while (result.moveToNext()) {
                user.setUserId(result.getInt(0));
                user.setUsername(result.getString(1));
                user.setAdmin(result.getInt(2) == 1);
            }
        }
        return user;
    }
    //endregion
}
