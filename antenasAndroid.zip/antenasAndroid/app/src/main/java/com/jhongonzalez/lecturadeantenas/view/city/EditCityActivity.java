package com.jhongonzalez.lecturadeantenas.view.city;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.CityDB;
import com.jhongonzalez.lecturadeantenas.database.RegionalDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.City;
import com.jhongonzalez.lecturadeantenas.entities.Regional;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

public class EditCityActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Ciudad a editar
     */
    private City city;

    /**
     * Administrador de persistencia en bd de la ciudad
     */
    private CityDB cityDB;

    /**
     * Administrador de persistencia para el envío de los datos al servidor
     */
    private SynchronizationDB synchronizationDB;

    /**
     * Caja de texto con el nombre de la ciudad
     */
    private EditText txtName;

    /**
     * Combo con el listado de regionales
     */
    private Spinner cmbRegional;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crea la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_city);
        RegionalDB regionalDB = new RegionalDB(this);
        cityDB = new CityDB(this);
        synchronizationDB = new SynchronizationDB(this);

        ArrayAdapter<Regional> regionalAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, regionalDB.list());

        city = (City) getIntent().getSerializableExtra("city");

        if (city.getCityId() == 0) {
            this.setTitle(R.string.create_city);
        } else {
            this.setTitle(R.string.edit_city);
        }

        EditText txtId = findViewById(R.id.txtCityId);
        txtName = findViewById(R.id.txtCityName);
        cmbRegional = findViewById(R.id.cmbRegional);
        cmbRegional.setAdapter(regionalAdapter);
        Button btnSave = findViewById(R.id.btnSaveCity);
        Button btnCancel = findViewById(R.id.btnCancelCity);

        txtId.setText(String.valueOf(city.getCityId()));
        txtId.setEnabled(false);
        txtName.setText(city.getName());
        cmbRegional.setSelection(regionalAdapter.getPosition(city.getRegional()));

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                city.setName(txtName.getText().toString());
                city.setRegional((Regional) cmbRegional.getSelectedItem());
                Synchronization sync = new Synchronization();
                sync.setTableName("city");
                if (city.getCityId() == 0) {
                    city = cityDB.create(city);
                    sync.setAction("I");
                    Toast.makeText(EditCityActivity.this, R.string.city_created, Toast.LENGTH_SHORT).show();
                } else {
                    cityDB.update(city);
                    sync.setAction("U");
                    Toast.makeText(EditCityActivity.this, R.string.city_updates, Toast.LENGTH_SHORT).show();
                }
                sync.setTableId(city.getCityId());
                synchronizationDB.create(sync);
                finish();
            }
        });
    }
    //endregion
}