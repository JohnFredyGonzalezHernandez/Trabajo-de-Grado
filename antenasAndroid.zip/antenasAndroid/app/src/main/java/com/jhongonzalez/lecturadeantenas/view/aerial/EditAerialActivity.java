package com.jhongonzalez.lecturadeantenas.view.aerial;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.AerialDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

public class EditAerialActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Tipo de antena a editar
     */
    private Aerial aerial;

    /**
     * Administrador de persistencia en bd del tipo de antena
     */
    private AerialDB aerialDB;

    /**
     * Administrador de persistencia para el envío de los datos al servidor
     */
    private SynchronizationDB synchronizationDB;

    /**
     * Caja de texto con el nombre del tipo de antena
     */
    private EditText txtName;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crea la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_aerial);
        aerialDB = new AerialDB(this);
        synchronizationDB = new SynchronizationDB(this);
        aerial = (Aerial) getIntent().getSerializableExtra("aerial");

        if (aerial.getAerialId() == 0) {
            this.setTitle(R.string.create_aerial);
        } else {
            this.setTitle(R.string.edit_aerial);
        }

        EditText txtId = findViewById(R.id.txtAerialId);
        txtName = findViewById(R.id.txtAerialName);
        Button btnSave = findViewById(R.id.btnSaveAerial);
        Button btnCancel = findViewById(R.id.btnCancelAerial);

        txtId.setText(String.valueOf(aerial.getAerialId()));
        txtId.setEnabled(false);
        txtName.setText(aerial.getName());

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                aerial.setName(txtName.getText().toString());
                Synchronization sync = new Synchronization();
                sync.setTableName("aerial");
                if (aerial.getAerialId() == 0) {
                    aerial = aerialDB.create(aerial);
                    sync.setAction("I");
                    Toast.makeText(EditAerialActivity.this, R.string.aerial_created, Toast.LENGTH_SHORT).show();
                } else {
                    aerialDB.update(aerial);
                    sync.setAction("U");
                    Toast.makeText(EditAerialActivity.this, R.string.aerial_updates, Toast.LENGTH_SHORT).show();
                }
                sync.setTableId(aerial.getAerialId());
                synchronizationDB.create(sync);
                finish();
            }
        });
    }
    //endregion
}