package com.jhongonzalez.lecturadeantenas.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.CityDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.City;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;
import com.jhongonzalez.lecturadeantenas.view.city.EditCityActivity;

import java.util.ArrayList;

/**
 * Adaptador de la lista de regionales
 */
public class GridCityAdapter extends RecyclerView.Adapter<GridCityAdapter.CityItemView> {

    //region Atributos
    /**
     * Administrador de base de datos de las ciudades
     */
    private final CityDB cityDB;

    /**
     * Administrador de base de datos de los datos a enviar al servidor
     */
    private final SynchronizationDB synchronizationDB;

    /**
     * Contexto que llama este adapatador
     */
    private final Context context;

    /**
     * Listado de ciudades
     */
    private ArrayList<City> list;
    //endregion

    //region Constructores

    /**
     * Crea el adaptador de ciudades
     *
     * @param context Contexto de la aplicación
     */
    public GridCityAdapter(@Nullable Context context) {
        this.context = context;
        cityDB = new CityDB(context);
        synchronizationDB = new SynchronizationDB(context);
        list = cityDB.list();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crear el visor de las filas del listado
     *
     * @param parent   Control padre del listado
     * @param viewType Tipo de vista
     * @return Vista del listado
     */
    @NonNull
    @Override
    public CityItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowCity = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_city_item, parent, false);
        return new CityItemView(rowCity);
    }

    /**
     * Ocurre al visualizar un item de la lista
     *
     * @param viewRow  Fila seleccionada
     * @param position Posición seleccionada
     */
    @Override
    public void onBindViewHolder(@NonNull final CityItemView viewRow, int position) {
        final City city = list.get(position);
        viewRow.id.setText(String.valueOf(city.getCityId()));
        viewRow.name.setText(city.getName());
        viewRow.regional.setText(city.getRegional().getName());
        viewRow.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editCity = new Intent(context, EditCityActivity.class);
                editCity.putExtra("city", city);
                context.startActivity(editCity);
            }
        });
        viewRow.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(context)
                        .setTitle(R.string.confirmation_delete_title)
                        .setMessage(R.string.confirmation_delete_message)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                cityDB.delete(city);
                                Synchronization sync = new Synchronization();
                                sync.setTableName("city");
                                sync.setTableId(city.getCityId());
                                sync.setAction("D");
                                synchronizationDB.create(sync);
                                update();
                                Toast.makeText(context, R.string.city_deleted, Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
            }
        });
    }

    /**
     * Trae el número de items del listado
     *
     * @return Número de items del listado
     */
    @Override
    public int getItemCount() {
        return list.size();
    }

    /**
     * Actuaiza los datos
     */
    public void update() {
        list = cityDB.list();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Clase interna
    static class CityItemView extends RecyclerView.ViewHolder {
        final TextView id;
        final TextView name;
        final TextView regional;
        final ImageView edit;
        final ImageView delete;

        CityItemView(View view) {
            super(view);
            this.id = view.findViewById(R.id.city_id);
            this.name = view.findViewById(R.id.city_name);
            this.regional = view.findViewById(R.id.city_regional);
            this.edit = view.findViewById(R.id.city_edit);
            this.delete = view.findViewById(R.id.city_delete);
        }
    }
    //endregion
}
