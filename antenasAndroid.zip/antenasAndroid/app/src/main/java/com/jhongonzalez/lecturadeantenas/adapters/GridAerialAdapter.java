package com.jhongonzalez.lecturadeantenas.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.AerialDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;
import com.jhongonzalez.lecturadeantenas.view.aerial.EditAerialActivity;

import java.util.ArrayList;

/**
 * Adaptador de la lista de regionales
 */
public class GridAerialAdapter extends RecyclerView.Adapter<GridAerialAdapter.AerialItemView> {

    //region Atributos
    /**
     * Administrador de base de datos de las antenas
     */
    private final AerialDB aerialDB;

    /**
     * Administrador de base de datos de los datos a enviar al servidor
     */
    private final SynchronizationDB synchronizationDB;

    /**
     * Contexto que llama este adapatador
     */
    private final Context context;

    /**
     * Listado de antenas
     */
    private ArrayList<Aerial> list;
    //endregion

    //region Constructores

    /**
     * Crea el adaptador de antenas
     *
     * @param context Contexto de la aplicación
     */
    public GridAerialAdapter(@Nullable Context context) {
        this.context = context;
        aerialDB = new AerialDB(context);
        synchronizationDB = new SynchronizationDB(context);
        list = aerialDB.list();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crear el visor de las filas del listado
     *
     * @param parent   Control padre del listado de regionales
     * @param viewType Tipo de vista
     * @return Vista del listado
     */
    @NonNull
    @Override
    public AerialItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowRegional = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_aerial_item, parent, false);
        return new AerialItemView(rowRegional);
    }

    /**
     * Ocurre al visualizar un item de la lista
     *
     * @param viewRow  Fila seleccionada
     * @param position Posición seleccionada
     */
    @Override
    public void onBindViewHolder(@NonNull final AerialItemView viewRow, int position) {
        final Aerial aerial = list.get(position);
        viewRow.id.setText(String.valueOf(aerial.getAerialId()));
        viewRow.name.setText(aerial.getName());
        viewRow.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editAerial = new Intent(context, EditAerialActivity.class);
                editAerial.putExtra("aerial", aerial);
                context.startActivity(editAerial);
            }
        });
        viewRow.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(context)
                        .setTitle(R.string.confirmation_delete_title)
                        .setMessage(R.string.confirmation_delete_message)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                aerialDB.delete(aerial);
                                Synchronization sync = new Synchronization();
                                sync.setTableName("aerial");
                                sync.setTableId(aerial.getAerialId());
                                sync.setAction("D");
                                synchronizationDB.create(sync);
                                update();
                                Toast.makeText(context, R.string.aerial_deleted, Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
            }
        });
    }

    /**
     * Trae el número de items del listado
     *
     * @return Número de items del listado
     */
    @Override
    public int getItemCount() {
        return list.size();
    }

    /**
     * Actuaiza los datos
     */
    public void update() {
        list = aerialDB.list();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Clase interna
    static class AerialItemView extends RecyclerView.ViewHolder {
        final TextView id;
        final TextView name;
        final ImageView edit;
        final ImageView delete;

        AerialItemView(View view) {
            super(view);
            this.id = view.findViewById(R.id.aerial_id);
            this.name = view.findViewById(R.id.aerial_name);
            this.edit = view.findViewById(R.id.aerial_edit);
            this.delete = view.findViewById(R.id.aerial_delete);
        }
    }
    //endregion
}
