package com.jhongonzalez.lecturadeantenas.entities;

import java.io.Serializable;
import java.util.Date;

/**
 * Datos de la sincronización de registros de la bd local con el servidor
 */
public class Synchronization implements Serializable {

    //region Atributos
    /**
     * Identificador de la sincronización
     */
    private int synchronizationId;

    /**
     * Nombre de la tabla sincronizada
     */
    private String tableName;

    /**
     * LLave primaria de la tabla sincronizada
     */
    private int tableId;

    /**
     * Fecha de la sincronización
     */
    private Date date;

    /**
     * Indicador de si la sincronización ya se finalizó
     */
    private boolean done;

    /**
     * Acción realizada sobre el registro (I)nsert, (U)pdate, (D)elete
     */
    private String action;
    //endregion

    //region Constructores

    /**
     * Crea una sincronización con datos por defecto
     */
    public Synchronization() {
        this(0);
    }

    /**
     * Crea una sincronización con un identificador por defecto
     *
     * @param id Identificador de la sincronización
     */
    public Synchronization(int id) {
        this.synchronizationId = id;
        this.tableName = "";
        this.tableId = 0;
        this.date = new Date();
        this.done = false;
        this.action = "";
    }
    //endregion

    //region Métodos

    /**
     * Trae el identificador de la sincronización
     *
     * @return Identificador de la sincronización
     */
    public int getSynchronizationId() {
        return synchronizationId;
    }

    /**
     * Cambia el identificador de la sincronización
     *
     * @param synchronizationId Nuevo identificador de la sincronización
     */
    public void setSynchronizationId(int synchronizationId) {
        this.synchronizationId = synchronizationId;
    }

    /**
     * Trae el nombre de la tabla de la sincronización
     *
     * @return Nombre de la tabla de la sincronización
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * Cambia el nombre de la tabla de la sincronización
     *
     * @param tableName Nuevo nombre de la tabla de la sincronización
     */
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    /**
     * Trae la llave primaria de la tabla de la sincronización
     *
     * @return Llave primaria de la tabla de la sincronización
     */
    public int getTableId() {
        return tableId;
    }

    /**
     * Cambia la llave primaria de la tabla de la sincronización
     *
     * @param tableId Nueva llave primaria de la tabla de la sincronización
     */
    public void setTableId(int tableId) {
        this.tableId = tableId;
    }

    /**
     * Trae la fecha de la sincronización
     *
     * @return Fecha de la sincronización
     */
    public Date getDate() {
        return date;
    }

    /**
     * Cambia la fecha de la sincronización
     *
     * @param date Nueva fecha de la sincronización
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Trae si la sincronización ya se realizó
     *
     * @return Si la sincronización ya se realizó
     */
    public boolean isDone() {
        return done;
    }

    /**
     * Cambia si la sincronización ya se realizó
     *
     * @param done Nuevo indicador si la sincronización ya se realizó
     */
    public void setDone(boolean done) {
        this.done = done;
    }

    /**
     * Trae la acción realizada sobre el registro
     *
     * @return Acción realizada sobre el registro
     */
    public String getAction() {
        return this.action;
    }

    /**
     * Cambia la acción realizada sobre el registro
     *
     * @param action Nueva acción realizada sobre el registro
     */
    public void setAction(String action) {
        this.action = action;
    }
    //endregion
}
