package com.jhongonzalez.lecturadeantenas.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.SectorDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.entities.Sector;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;
import com.jhongonzalez.lecturadeantenas.view.sector.EditSectorActivity;

import java.util.ArrayList;

/**
 * Adaptador de la lista de sectores
 */
public class GridSectorAdapter extends RecyclerView.Adapter<GridSectorAdapter.SectorItemView> {

    //region Atributos
    /**
     * Enb al que pertenecen los sectores
     */
    private final Enb enb;

    /**
     * Administrador de base de datos de los datos a enviar al servidor
     */
    private final SynchronizationDB synchronizationDB;

    /**
     * Administrador de base de datos de las sectores
     */
    private final SectorDB sectorDB;

    /**
     * Contexto que llama este adapatador
     */
    private final Context context;

    /**
     * Listado de sectores
     */
    private ArrayList<Sector> list;
    //endregion

    //region Constructores

    /**
     * Crea el adaptador de sectores
     *
     * @param enb     Enb al que pertenecen los sectores
     * @param context Contexto de la aplicación
     */
    public GridSectorAdapter(@Nullable Context context, Enb enb) {
        this.context = context;
        this.enb = enb;
        sectorDB = new SectorDB(context);
        synchronizationDB = new SynchronizationDB(context);
        list = sectorDB.list(this.enb);
        this.notifyDataSetChanged();
    }
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crear el visor de las filas del listado
     *
     * @param parent   Control padre del listado de sectores
     * @param viewType Tipo de vista
     * @return Vista del listado
     */
    @NonNull
    @Override
    public SectorItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowSector = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_sector_item, parent, false);
        return new SectorItemView(rowSector);
    }

    /**
     * Ocurre al visualizar un item de la lista
     *
     * @param viewRow  Fila seleccionada
     * @param position Posición seleccionada
     */
    @Override
    public void onBindViewHolder(@NonNull final SectorItemView viewRow, int position) {
        final Sector sector = list.get(position);
        viewRow.id.setText(String.valueOf(sector.getSectorId()));
        viewRow.name.setText(sector.getName());
        viewRow.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editSector = new Intent(context, EditSectorActivity.class);
                editSector.putExtra("sector", sector);
                context.startActivity(editSector);
            }
        });
        viewRow.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(context)
                        .setTitle(R.string.confirmation_delete_title)
                        .setMessage(R.string.confirmation_delete_message)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                sectorDB.delete(sector);
                                Synchronization sync = new Synchronization();
                                sync.setTableName("sector");
                                sync.setTableId(sector.getSectorId());
                                sync.setAction("D");
                                synchronizationDB.create(sync);
                                update();
                                Toast.makeText(context, R.string.sector_deleted, Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
            }
        });
    }

    /**
     * Trae el número de items del listado
     *
     * @return Número de items del listado
     */
    @Override
    public int getItemCount() {
        return list.size();
    }

    /**
     * Actuaiza los datos
     */
    public void update() {
        list = sectorDB.list(this.enb);
        this.notifyDataSetChanged();
    }
    //endregion

    //region Clase interna
    static class SectorItemView extends RecyclerView.ViewHolder {
        final TextView id;
        final TextView name;
        final ImageView edit;
        final ImageView delete;

        SectorItemView(View view) {
            super(view);
            this.id = view.findViewById(R.id.sector_id);
            this.name = view.findViewById(R.id.sector_name);
            this.edit = view.findViewById(R.id.sector_edit);
            this.delete = view.findViewById(R.id.sector_delete);
        }
    }
    //endregion
}
