package com.jhongonzalez.lecturadeantenas.entities;

import java.io.Serializable;

/**
 * Modelo de antena
 */
public class Aerial implements Serializable {

    //region Atributos
    /**
     * Identificador de la antena
     */
    private int aerialId;

    /**
     * Nombre de la antena
     */
    private String name;
    //endregion

    //region Constructores

    /**
     * Crea una antena con datos por defecto
     */
    public Aerial() {
        this(0);
    }

    /**
     * Crea una antena con un identificador por defecto
     *
     * @param id Identificador de la antena
     */
    public Aerial(int id) {
        this.aerialId = id;
        this.name = "";
    }
    //endregion

    //region Métodos

    /**
     * Trae el identificador de la antena
     *
     * @return Identificador de la antena
     */
    public int getAerialId() {
        return aerialId;
    }

    /**
     * Cambia el identificador de la antena
     *
     * @param aerialId Nuevo identificador de la antena
     */
    public void setAerialId(int aerialId) {
        this.aerialId = aerialId;
    }

    /**
     * Trae el nombre de la antena
     *
     * @return Nombre de la antena
     */
    public String getName() {
        return name;
    }

    /**
     * Cambia el nombre de la antena
     *
     * @param name Nuevo nombre de la antena
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Expresa la antena como un texto mostrando su nombre
     *
     * @return Nombre de la antena
     */
    @Override
    public String toString() {
        return name;
    }

    /**
     * Compara la antena actual con otra
     *
     * @param aerial Antena con la que se quiere comparar
     * @return Si son o no iguales
     */
    @Override
    public boolean equals(Object aerial) {
        if (aerial.getClass() != Aerial.class) {
            return false;
        }
        return (((Aerial) aerial).getAerialId() == this.aerialId);
    }
    //endregion
}
