package com.jhongonzalez.lecturadeantenas.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.RegionalDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Regional;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;
import com.jhongonzalez.lecturadeantenas.view.regional.EditRegionalActivity;

import java.util.ArrayList;

/**
 * Adaptador de la lista de regionales
 */
public class GridRegionalAdapter extends RecyclerView.Adapter<GridRegionalAdapter.RegionalItemView> {

    //region Atributos
    /**
     * Administrador de base de datos de las regionales
     */
    private final RegionalDB regionalDB;

    /**
     * Administrador de base de datos de los datos a enviar al servidor
     */
    private final SynchronizationDB synchronizationDB;

    /**
     * Contexto que llama este adapatador
     */
    private final Context context;

    /**
     * Listado de regionales
     */
    private ArrayList<Regional> list;
    //endregion

    //region Constructores

    /**
     * Crea el adaptador de regionales
     *
     * @param context Contexto de la aplicación
     */
    public GridRegionalAdapter(@Nullable Context context) {
        this.context = context;
        regionalDB = new RegionalDB(context);
        synchronizationDB = new SynchronizationDB(context);
        list = regionalDB.list();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crear el visor de las filas del listado
     *
     * @param parent   Control padre del listado de regionales
     * @param viewType Tipo de vista
     * @return Vista del listado
     */
    @NonNull
    @Override
    public RegionalItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowRegional = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_regional_item, parent, false);
        return new RegionalItemView(rowRegional);
    }

    /**
     * Ocurre al visualizar un item de la lista
     *
     * @param viewRow  Fila seleccionada
     * @param position Posición seleccionada
     */
    @Override
    public void onBindViewHolder(@NonNull final RegionalItemView viewRow, int position) {
        final Regional regional = list.get(position);
        viewRow.id.setText(String.valueOf(regional.getRegionalId()));
        viewRow.name.setText(regional.getName());
        viewRow.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editRegional = new Intent(context, EditRegionalActivity.class);
                editRegional.putExtra("regional", regional);
                context.startActivity(editRegional);
            }
        });
        viewRow.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(context)
                        .setTitle(R.string.confirmation_delete_title)
                        .setMessage(R.string.confirmation_delete_message)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                regionalDB.delete(regional);
                                Synchronization sync = new Synchronization();
                                sync.setTableName("regional");
                                sync.setTableId(regional.getRegionalId());
                                sync.setAction("D");
                                synchronizationDB.create(sync);
                                update();
                                Toast.makeText(context, R.string.regional_deleted, Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
            }
        });
    }

    /**
     * Trae el número de items del listado
     *
     * @return Número de items del listado
     */
    @Override
    public int getItemCount() {
        return list.size();
    }

    /**
     * Actuaiza los datos
     */
    public void update() {
        list = regionalDB.list();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Clase interna
    static class RegionalItemView extends RecyclerView.ViewHolder {
        final TextView id;
        final TextView name;
        final ImageView edit;
        final ImageView delete;

        RegionalItemView(View view) {
            super(view);
            this.id = view.findViewById(R.id.regional_id);
            this.name = view.findViewById(R.id.regional_name);
            this.edit = view.findViewById(R.id.regional_edit);
            this.delete = view.findViewById(R.id.regional_delete);
        }
    }
    //endregion
}
