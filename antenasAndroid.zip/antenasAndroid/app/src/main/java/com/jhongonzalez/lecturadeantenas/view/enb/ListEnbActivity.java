package com.jhongonzalez.lecturadeantenas.view.enb;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.adapters.GridEnbAdapter;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.utils.Session;
import com.jhongonzalez.lecturadeantenas.view.aerial.ListAerialActivity;
import com.jhongonzalez.lecturadeantenas.view.city.ListCityActivity;
import com.jhongonzalez.lecturadeantenas.view.regional.ListRegionalActivity;
import com.jhongonzalez.lecturadeantenas.view.synchronization.ListSynchronizationActivity;

public class ListEnbActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Adaptador de la tabla de enb
     */
    private GridEnbAdapter gridEnbAdapter;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al iniciar la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_enb);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView listEnb = findViewById(R.id.listEnb);
        FloatingActionButton fabAddEnb = findViewById(R.id.fabAddEnb);

        gridEnbAdapter = new GridEnbAdapter(this);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        listEnb.setLayoutManager(mLayoutManager);
        listEnb.setItemAnimator(new DefaultItemAnimator());
        listEnb.setAdapter(gridEnbAdapter);

        fabAddEnb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editEnb = new Intent(ListEnbActivity.this, EditEnbActivity.class);
                editEnb.putExtra("enb", new Enb());
                startActivity(editEnb);
            }
        });
    }

    /**
     * Se ejecuta al crear el menú de la aplicación
     *
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (Session.getInstance().getUser() != null && Session.getInstance().getUser().isAdmin()) {
            getMenuInflater().inflate(R.menu.main_menu_admin, menu);
            return true;
        } else {
            getMenuInflater().inflate(R.menu.main_menu, menu);
            return true;
        }
    }

    /**
     * Se ejecuta al seleccionar un ítem del menú de opciones
     *
     * @param item Ítem seleccionado
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itmRegionals:
                Intent regionals = new Intent(ListEnbActivity.this, ListRegionalActivity.class);
                startActivity(regionals);
                return true;
            case R.id.itmCities:
                Intent cities = new Intent(ListEnbActivity.this, ListCityActivity.class);
                startActivity(cities);
                return true;
            case R.id.itmAerials:
                Intent aerials = new Intent(ListEnbActivity.this, ListAerialActivity.class);
                startActivity(aerials);
                return true;
            case R.id.itmSync:
                Intent sync = new Intent(ListEnbActivity.this, ListSynchronizationActivity.class);
                startActivity(sync);
                return true;
            case R.id.itmCloseApp:
                Intent login = new Intent(Intent.ACTION_MAIN);
                startActivity(login);
                System.exit(0);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * Se ejecuta al volver de otra actividad a esta
     */
    @Override
    public void onResume() {
        super.onResume();
        gridEnbAdapter.update();
    }
    //endregion
}