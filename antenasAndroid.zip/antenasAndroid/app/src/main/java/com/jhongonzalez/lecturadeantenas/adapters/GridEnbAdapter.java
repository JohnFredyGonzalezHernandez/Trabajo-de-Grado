package com.jhongonzalez.lecturadeantenas.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.EnbDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;
import com.jhongonzalez.lecturadeantenas.view.enb.EditEnbActivity;
import com.jhongonzalez.lecturadeantenas.view.sector.ListSectorActivity;

import java.util.ArrayList;

/**
 * Adaptador de la lista de regionales
 */
public class GridEnbAdapter extends RecyclerView.Adapter<GridEnbAdapter.EnbItemView> {

    //region Atributos
    /**
     * Administrador de base de datos de las enb
     */
    private final EnbDB enbDB;

    /**
     * Administrador de base de datos de los datos a enviar al servidor
     */
    private final SynchronizationDB synchronizationDB;

    /**
     * Contexto de la actividad
     */
    private final Context context;

    /**
     * Listado de regionales
     */
    private ArrayList<Enb> list;
    //endregion

    //region Constructores

    /**
     * Crea el adaptador de enb
     *
     * @param context Contexto de la aplicación
     */
    public GridEnbAdapter(@Nullable Context context) {
        this.context = context;
        enbDB = new EnbDB(context);
        synchronizationDB = new SynchronizationDB(context);
        list = enbDB.list();
        this.notifyDataSetChanged();
    }
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crear el visor de las filas del listado
     *
     * @param parent   Control padre del listado
     * @param viewType Tipo de vista
     * @return Vista del listado
     */
    @NonNull
    @Override
    public EnbItemView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowEnb = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_enb_item, parent, false);
        return new EnbItemView(rowEnb);
    }

    /**
     * Ocurre al seleccionar un item de la lista
     *
     * @param viewRow  Fila seleccionada
     * @param position Posición seleccionada
     */
    @Override
    public void onBindViewHolder(@NonNull EnbItemView viewRow, int position) {
        final Enb enb = list.get(position);
        viewRow.id.setText(String.valueOf(enb.getEnbId()));
        viewRow.name.setText(enb.getName());

        viewRow.sectors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent listSectors = new Intent(context, ListSectorActivity.class);
                listSectors.putExtra("enb", enb);
                context.startActivity(listSectors);
            }
        });
        viewRow.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editEnb = new Intent(context, EditEnbActivity.class);
                editEnb.putExtra("enb", enb);
                context.startActivity(editEnb);
            }
        });
        viewRow.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(context)
                        .setTitle(R.string.confirmation_delete_title)
                        .setMessage(R.string.confirmation_delete_message)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                enbDB.delete(enb);
                                Synchronization sync = new Synchronization();
                                sync.setTableName("enb");
                                sync.setTableId(enb.getEnbId());
                                sync.setAction("D");
                                synchronizationDB.create(sync);
                                update();
                                Toast.makeText(context, R.string.enb_deleted, Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
            }
        });
    }

    /**
     * Trae el número de items del listado
     *
     * @return Número de items del listado
     */
    @Override
    public int getItemCount() {
        return list.size();
    }
    //endregion

    /**
     * Actuaiza los datos
     */
    public void update() {
        list = enbDB.list();
        this.notifyDataSetChanged();
    }

    //region Clase interna
    static class EnbItemView extends RecyclerView.ViewHolder {
        final TextView id;
        final TextView name;
        final ImageView sectors;
        final ImageView edit;
        final ImageView delete;

        EnbItemView(View view) {
            super(view);
            this.id = view.findViewById(R.id.enb_id);
            this.name = view.findViewById(R.id.enb_name);
            this.sectors = view.findViewById(R.id.enb_sectors);
            this.edit = view.findViewById(R.id.enb_edit);
            this.delete = view.findViewById(R.id.enb_delete);
        }
    }
    //endregion
}
