package com.jhongonzalez.lecturadeantenas.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import androidx.annotation.Nullable;

import com.jhongonzalez.lecturadeantenas.entities.Aerial;

import java.util.ArrayList;

/**
 * Clase encargada de la persistencia de las regiones
 */
public class AerialDB {

    //region Atributos
    /**
     * Conexión a la base de datos
     */
    private final DatabaseHelper db;

    /**
     * Nombre de la tabla
     */
    private final String TABLE = "aerial";

    /**
     * Nombre de las columnas
     */
    private final String[] COLUMNS = {"aerial_id", "name"};
    //endregion

    //region Constructores

    /**
     * Crea la conexión a la base de datos
     *
     * @param context Contexto de la aplicación
     */
    public AerialDB(@Nullable Context context) {
        this.db = new DatabaseHelper(context);
    }

    //endregion

    //region Métodos

    /**
     * Trae el listado de antenas de la base de datos
     *
     * @return Listado de antenas de la base de datos
     */
    public ArrayList<Aerial> list() {
        ArrayList<Aerial> list = new ArrayList<>();
        try (Cursor result = this.db.getReadableDatabase().query(TABLE, COLUMNS,
                null,
                null,
                null,
                null,
                null)) {
            while (result.moveToNext()) {
                Aerial aerial = new Aerial(result.getInt(0));
                aerial.setName(result.getString(1));
                list.add(aerial);
            }
        }
        return list;
    }

    /**
     * Trae un tipo de antena de la base de datos
     *
     * @param aerial Tipo de antena a leer
     * @return Tipo de antena de la base de datos
     */
    public Aerial read(Aerial aerial) {
        try (Cursor result = this.db.getReadableDatabase().rawQuery(
                "SELECT name FROM aerial WHERE aerial_id = ?",
                new String[]{String.valueOf(aerial.getAerialId())})) {
            while (result.moveToNext()) {
                aerial.setName(result.getString(0));
            }
        }
        return aerial;
    }

    /**
     * Crea una nueva antena
     *
     * @param aerial Antena a insertar
     * @return Antena creada
     */
    public Aerial create(Aerial aerial) {
        ContentValues values = new ContentValues();
        values.put("name", aerial.getName());
        aerial.setAerialId((int) this.db.getWritableDatabase().insert(TABLE, null, values));
        return aerial;
    }

    /**
     * Actualiza la antena en la base de datos
     *
     * @param aerial Antena de la base de datos
     * @return Antena actualizada
     */
    public Aerial update(Aerial aerial) {
        ContentValues values = new ContentValues();
        values.put("name", aerial.getName());
        this.db.getWritableDatabase().update(TABLE, values, "aerial_id = ?", new String[]{String.valueOf(aerial.getAerialId())});
        return aerial;
    }

    /**
     * Elimina la antena de la base de datos
     *
     * @param aerial Antena a eliminar
     * @return Antena eliminada
     */
    public Aerial delete(Aerial aerial) {
        this.db.getWritableDatabase().delete(TABLE, "aerial_id = ?", new String[]{String.valueOf(aerial.getAerialId())});
        return aerial;
    }
    //endregion
}
