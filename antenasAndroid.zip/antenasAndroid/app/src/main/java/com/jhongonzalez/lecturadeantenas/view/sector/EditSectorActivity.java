package com.jhongonzalez.lecturadeantenas.view.sector;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.tabs.TabLayout;
import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.database.AerialDB;
import com.jhongonzalez.lecturadeantenas.database.SectorDB;
import com.jhongonzalez.lecturadeantenas.database.SynchronizationDB;
import com.jhongonzalez.lecturadeantenas.entities.Aerial;
import com.jhongonzalez.lecturadeantenas.entities.Sector;
import com.jhongonzalez.lecturadeantenas.entities.Synchronization;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class EditSectorActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Distancia mínima para actualizar el GPS
     */
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10; // 10 meters

    /**
     * Tiempo mínimo para actualizar el GPS
     */
    private static final long MIN_TIME_BW_UPDATES = 60000; // 1 minute

    /**
     * Valor de retorno al capturar una imagen nueva
     */
    private static final int REQUEST_IMAGE_CAPTURE = 1;

    /**
     * Valor de retorno al seleccionar una imagen existente
     */
    private static final int REQUEST_IMAGE_GALLERY = 2;

    /**
     * Indica si el GPS está activo
     */
    boolean isGPSEnabled = false;

    /**
     * Indica si la red está habilitada
     */
    boolean isNetworkEnabled = false;

    /**
     * Sector a editar
     */
    private Sector sector;

    /**
     * Administrador de persistencia en bd del sector
     */
    private SectorDB sectorDB;

    /**
     * Administrador de persistencia para el envío de los datos al servidor
     */
    private SynchronizationDB synchronizationDB;

    /**
     * Cajas de texto con los valores del sector
     */
    private EditText txtName, txtLatitude, txtLongitude, txtAltitudeBefore, txtAzimuthBefore,
            txtElectricTiltBefore, txtMechanicalTiltBefore, txtAltitudeAfter, txtAzimuthAfter,
            txtElectricTiltAfter, txtMechanicalTiltAfter, txtGnetTrack, txtOrientationBefore,
            txtOrientationEarthBefore, txtOrientationAfter, txtOrientationEarthAfter;

    /**
     * Títulos de las cajas de texto de los valores del sector
     */
    private TextView lblAltitudeBefore, lblAzimuthBefore, lblElectricTiltBefore,
            lblMechanicalTiltBefore, lblAltitudeAfter, lblAzimuthAfter, lblElectricTiltAfter,
            lblMechanicalTiltAfter, lblOrientationBefore, lblOrientationEarthBefore,
            lblOrientationAfter, lblOrientationEarthAfter;

    /**
     * Botón de selección de AWS o APT
     */
    private RadioButton radBtnAws;

    /**
     * Combo de tipos de antenas
     */
    private Spinner cmbAerial;

    /**
     * Visores de imagenes
     */
    private ImageView imgGnetTrack, imgOrientationBefore, imgOrientationAfter,
            imgOrientationEarthBefore, imgOrientationEarthAfter;

    /**
     * Tipo de imagen que actualmente se está procesando
     */
    private int imageViewSrc;//1: imgGnetTrack, 2: imgOrientationBefore, 3: imgOrientationAfter, 4: imgOrientationEarthBefore, 5: imgOrientationEarthAfter

    /**
     * Archivo que guarda la imagen procesada actualmente
     */
    private File fileImage;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al crea la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_sector);
        sectorDB = new SectorDB(this);
        synchronizationDB = new SynchronizationDB(this);
        AerialDB aerialDB = new AerialDB(this);

        ArrayAdapter<Aerial> aerialAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, aerialDB.list());

        sector = (Sector) getIntent().getSerializableExtra("sector");

        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        if (sector.getSectorId() == 0) {
            this.setTitle(R.string.create_sector);
        } else {
            this.setTitle(R.string.edit_sector);
        }

        EditText txtId = findViewById(R.id.txtSectorId);
        radBtnAws = findViewById(R.id.radSectorTypeAws);
        RadioButton radBtnApt = findViewById(R.id.radSectorTypeApt);
        txtName = findViewById(R.id.txtSectorName);
        lblAltitudeBefore = findViewById(R.id.lblSectorAltitudeBefore);
        txtAltitudeBefore = findViewById(R.id.txtSectorAltitudeBefore);
        lblAzimuthBefore = findViewById(R.id.lblSectorAzimuthBefore);
        txtAzimuthBefore = findViewById(R.id.txtSectorAzimuthBefore);
        lblElectricTiltBefore = findViewById(R.id.lblSectorElectricTiltBefore);
        txtElectricTiltBefore = findViewById(R.id.txtSectorElectricTiltBefore);
        lblMechanicalTiltBefore = findViewById(R.id.lblSectorMechanicalTiltBefore);
        txtMechanicalTiltBefore = findViewById(R.id.txtSectorMechanicalTiltBefore);
        lblOrientationBefore = findViewById(R.id.lblSectorOrientationBefore);
        txtOrientationBefore = findViewById(R.id.txtSectorOrientationBefore);
        imgOrientationBefore = findViewById(R.id.imgSectorOrientationBefore);
        lblOrientationEarthBefore = findViewById(R.id.lblSectorOrientationEarthBefore);
        txtOrientationEarthBefore = findViewById(R.id.txtSectorOrientationEarthBefore);
        imgOrientationEarthBefore = findViewById(R.id.imgSectorOrientationEarthBefore);
        lblAltitudeAfter = findViewById(R.id.lblSectorAltitudeAfter);
        txtAltitudeAfter = findViewById(R.id.txtSectorAltitudeAfter);
        lblAzimuthAfter = findViewById(R.id.lblSectorAzimuthAfter);
        txtAzimuthAfter = findViewById(R.id.txtSectorAzimuthAfter);
        lblElectricTiltAfter = findViewById(R.id.lblSectorElectricTiltAfter);
        txtElectricTiltAfter = findViewById(R.id.txtSectorElectricTiltAfter);
        lblMechanicalTiltAfter = findViewById(R.id.lblSectorMechanicalTiltAfter);
        txtMechanicalTiltAfter = findViewById(R.id.txtSectorMechanicalTiltAfter);
        lblOrientationAfter = findViewById(R.id.lblSectorOrientationAfter);
        txtOrientationAfter = findViewById(R.id.txtSectorOrientationAfter);
        imgOrientationAfter = findViewById(R.id.imgSectorOrientationAfter);
        lblOrientationEarthAfter = findViewById(R.id.lblSectorOrientationEarthAfter);
        txtOrientationEarthAfter = findViewById(R.id.txtSectorOrientationEarthAfter);
        imgOrientationEarthAfter = findViewById(R.id.imgSectorOrientationEarthAfter);
        TabLayout tabBeforeAfter = findViewById(R.id.tabBeforeAfter);
        tabBeforeAfter.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    lblAltitudeBefore.setVisibility(View.VISIBLE);
                    txtAltitudeBefore.setVisibility(View.VISIBLE);
                    lblAzimuthBefore.setVisibility(View.VISIBLE);
                    txtAzimuthBefore.setVisibility(View.VISIBLE);
                    lblElectricTiltBefore.setVisibility(View.VISIBLE);
                    txtElectricTiltBefore.setVisibility(View.VISIBLE);
                    lblMechanicalTiltBefore.setVisibility(View.VISIBLE);
                    txtMechanicalTiltBefore.setVisibility(View.VISIBLE);
                    lblOrientationBefore.setVisibility(View.VISIBLE);
                    imgOrientationBefore.setVisibility(View.VISIBLE);
                    lblOrientationEarthBefore.setVisibility(View.VISIBLE);
                    imgOrientationEarthBefore.setVisibility(View.VISIBLE);
                }
                if (tab.getPosition() == 1) {
                    lblAltitudeAfter.setVisibility(View.VISIBLE);
                    txtAltitudeAfter.setVisibility(View.VISIBLE);
                    lblAzimuthAfter.setVisibility(View.VISIBLE);
                    txtAzimuthAfter.setVisibility(View.VISIBLE);
                    lblElectricTiltAfter.setVisibility(View.VISIBLE);
                    txtElectricTiltAfter.setVisibility(View.VISIBLE);
                    lblMechanicalTiltAfter.setVisibility(View.VISIBLE);
                    txtMechanicalTiltAfter.setVisibility(View.VISIBLE);
                    lblOrientationAfter.setVisibility(View.VISIBLE);
                    imgOrientationAfter.setVisibility(View.VISIBLE);
                    lblOrientationEarthAfter.setVisibility(View.VISIBLE);
                    imgOrientationEarthAfter.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) {
                    lblAltitudeBefore.setVisibility(View.INVISIBLE);
                    txtAltitudeBefore.setVisibility(View.INVISIBLE);
                    lblAzimuthBefore.setVisibility(View.INVISIBLE);
                    txtAzimuthBefore.setVisibility(View.INVISIBLE);
                    lblElectricTiltBefore.setVisibility(View.INVISIBLE);
                    txtElectricTiltBefore.setVisibility(View.INVISIBLE);
                    lblMechanicalTiltBefore.setVisibility(View.INVISIBLE);
                    txtMechanicalTiltBefore.setVisibility(View.INVISIBLE);
                    lblOrientationBefore.setVisibility(View.INVISIBLE);
                    imgOrientationBefore.setVisibility(View.INVISIBLE);
                    lblOrientationEarthBefore.setVisibility(View.INVISIBLE);
                    imgOrientationEarthBefore.setVisibility(View.INVISIBLE);
                }
                if (tab.getPosition() == 1) {
                    lblAltitudeAfter.setVisibility(View.INVISIBLE);
                    txtAltitudeAfter.setVisibility(View.INVISIBLE);
                    lblAzimuthAfter.setVisibility(View.INVISIBLE);
                    txtAzimuthAfter.setVisibility(View.INVISIBLE);
                    lblElectricTiltAfter.setVisibility(View.INVISIBLE);
                    txtElectricTiltAfter.setVisibility(View.INVISIBLE);
                    lblMechanicalTiltAfter.setVisibility(View.INVISIBLE);
                    txtMechanicalTiltAfter.setVisibility(View.INVISIBLE);
                    lblOrientationAfter.setVisibility(View.INVISIBLE);
                    imgOrientationAfter.setVisibility(View.INVISIBLE);
                    lblOrientationEarthAfter.setVisibility(View.INVISIBLE);
                    imgOrientationEarthAfter.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        cmbAerial = findViewById(R.id.cmbSectorAerial);
        cmbAerial.setAdapter(aerialAdapter);
        txtLatitude = findViewById(R.id.txtSectorLatitude);
        txtLatitude.setEnabled(false);
        txtLongitude = findViewById(R.id.txtSectorLongitude);
        txtLongitude.setEnabled(false);
        txtGnetTrack = findViewById(R.id.txtSectorGnetTrack);
        imgGnetTrack = findViewById(R.id.imgSectorGnetTrack);
        Button btnSave = findViewById(R.id.btnSaveSector);
        Button btnCancel = findViewById(R.id.btnCancelSector);

        txtId.setText(String.valueOf(sector.getSectorId()));
        txtId.setEnabled(false);
        radBtnAws.setChecked(!sector.getType());
        radBtnApt.setChecked(sector.getType());
        txtName.setText(sector.getName());
        txtAltitudeBefore.setText(String.valueOf(sector.getAltitudeBefore()));
        txtAzimuthBefore.setText(String.valueOf(sector.getAzimuthBefore()));
        txtElectricTiltBefore.setText(String.valueOf(sector.getElectricTiltBefore()));
        txtMechanicalTiltBefore.setText(String.valueOf(sector.getMechanicalTiltBefore()));
        txtAltitudeAfter.setText(String.valueOf(sector.getAltitudeAfter()));
        txtAzimuthAfter.setText(String.valueOf(sector.getAzimuthAfter()));
        txtElectricTiltAfter.setText(String.valueOf(sector.getElectricTiltAfter()));
        txtMechanicalTiltAfter.setText(String.valueOf(sector.getMechanicalTiltAfter()));
        if (!isGPSEnabled && !isNetworkEnabled) {
            txtLatitude.setText(String.valueOf(0));
            txtLongitude.setText(String.valueOf(0));
        } else {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 101);
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES, MIN_DISTANCE_CHANGE_FOR_UPDATES, new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull Location location) {
                    txtLatitude.setText(String.valueOf(location.getLatitude()));
                    txtLongitude.setText(String.valueOf(location.getLongitude()));
                }
            });
        }
        cmbAerial.setSelection(aerialAdapter.getPosition(sector.getAerial()));
        txtGnetTrack.setText(sector.getGnetTrack());
        if (sector.getGnetTrack().equals("")) {
            imgGnetTrack.setImageResource(android.R.drawable.ic_menu_camera);
        } else {
            imgGnetTrack.setImageBitmap(BitmapFactory.decodeFile(getFilesDir() + "/" + sector.getGnetTrack()));
        }
        imgGnetTrack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageViewSrc = 1;
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Seleccionar imagen"), REQUEST_IMAGE_GALLERY);
            }
        });
        txtOrientationBefore.setText(sector.getOrientationBefore());
        if (sector.getOrientationBefore().equals("")) {
            imgOrientationBefore.setImageResource(android.R.drawable.ic_menu_camera);
        } else {
            imgOrientationBefore.setImageBitmap(BitmapFactory.decodeFile(getFilesDir() + "/" + sector.getOrientationBefore()));
        }
        imgOrientationBefore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageViewSrc = 2;
                try {
                    fileImage = File.createTempFile("before_", ".png", getFilesDir());
                    Uri photoURI = FileProvider.getUriForFile(EditSectorActivity.this,
                            "com.jhongonzalez.lecturadeantenas.fileprovider",
                            fileImage);
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        txtOrientationEarthBefore.setText(sector.getOrientationEarthBefore());
        if (sector.getOrientationEarthBefore().equals("")) {
            imgOrientationEarthBefore.setImageResource(android.R.drawable.ic_menu_camera);
        } else {
            imgOrientationEarthBefore.setImageBitmap(BitmapFactory.decodeFile(getFilesDir() + "/" + sector.getOrientationEarthBefore()));
        }
        imgOrientationEarthBefore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageViewSrc = 3;
                try {
                    fileImage = File.createTempFile("before_earth_", ".png", getFilesDir());
                    Uri photoURI = FileProvider.getUriForFile(EditSectorActivity.this,
                            "com.jhongonzalez.lecturadeantenas.fileprovider",
                            fileImage);
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        txtOrientationAfter.setText(sector.getOrientationAfter());
        if (sector.getOrientationAfter().equals("")) {
            imgOrientationAfter.setImageResource(android.R.drawable.ic_menu_camera);
        } else {
            imgOrientationAfter.setImageBitmap(BitmapFactory.decodeFile(getFilesDir() + "/" + sector.getOrientationAfter()));
        }
        imgOrientationAfter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageViewSrc = 4;
                try {
                    fileImage = File.createTempFile("after_", ".png", getFilesDir());
                    Uri photoURI = FileProvider.getUriForFile(EditSectorActivity.this,
                            "com.jhongonzalez.lecturadeantenas.fileprovider",
                            fileImage);
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        txtOrientationEarthAfter.setText(sector.getOrientationEarthAfter());
        if (sector.getOrientationEarthAfter().equals("")) {
            imgOrientationEarthAfter.setImageResource(android.R.drawable.ic_menu_camera);
        } else {
            imgOrientationEarthAfter.setImageBitmap(BitmapFactory.decodeFile(getFilesDir() + "/" + sector.getOrientationEarthAfter()));
        }
        imgOrientationEarthAfter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageViewSrc = 5;
                try {
                    fileImage = File.createTempFile("after_earth_", ".png", getFilesDir());
                    Uri photoURI = FileProvider.getUriForFile(EditSectorActivity.this,
                            "com.jhongonzalez.lecturadeantenas.fileprovider",
                            fileImage);
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        txtLatitude.setText(String.valueOf(sector.getLatitude()));
        txtLongitude.setText(String.valueOf(sector.getLongitude()));

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sector.setName(txtName.getText().toString());
                sector.setType(!radBtnAws.isChecked());
                sector.setAltitudeBefore(Integer.parseInt(txtAltitudeBefore.getText().toString()));
                sector.setAzimuthBefore(Integer.parseInt(txtAzimuthBefore.getText().toString()));
                sector.setElectricTiltBefore(Integer.parseInt(txtElectricTiltBefore.getText().toString()));
                sector.setMechanicalTiltBefore(Integer.parseInt(txtMechanicalTiltBefore.getText().toString()));
                sector.setOrientationBefore(txtOrientationBefore.getText().toString());
                sector.setOrientationEarthBefore(txtOrientationEarthBefore.getText().toString());
                sector.setAltitudeAfter(Integer.parseInt(txtAltitudeAfter.getText().toString()));
                sector.setAzimuthAfter(Integer.parseInt(txtAzimuthAfter.getText().toString()));
                sector.setElectricTiltAfter(Integer.parseInt(txtElectricTiltAfter.getText().toString()));
                sector.setMechanicalTiltAfter(Integer.parseInt(txtMechanicalTiltAfter.getText().toString()));
                sector.setOrientationAfter(txtOrientationAfter.getText().toString());
                sector.setOrientationEarthAfter(txtOrientationEarthAfter.getText().toString());
                sector.setAerial((Aerial) cmbAerial.getSelectedItem());
                sector.setGnetTrack(txtGnetTrack.getText().toString());
                sector.setLatitude(Float.parseFloat(txtLatitude.getText().toString()));
                sector.setLongitude(Float.parseFloat(txtLongitude.getText().toString()));

                Synchronization sync = new Synchronization();
                sync.setTableName("sector");
                if (sector.getSectorId() == 0) {
                    sector = sectorDB.create(sector);
                    sync.setAction("I");
                    Toast.makeText(EditSectorActivity.this, R.string.sector_created, Toast.LENGTH_SHORT).show();
                } else {
                    sectorDB.update(sector);
                    sync.setAction("U");
                    Toast.makeText(EditSectorActivity.this, R.string.sector_updates, Toast.LENGTH_SHORT).show();
                }
                sync.setTableId(sector.getSectorId());
                synchronizationDB.create(sync);
                finish();
            }
        });
    }

    /**
     * Se ejecuta al volver de la captura de una imagen nueva o la selección de una existente
     *
     * @param requestCode Código de respuesta según la acción
     * @param resultCode  Resultado de la operación
     * @param data        Datos de respuesta
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bitmap imageBitmap = BitmapFactory.decodeFile(fileImage.getPath());
            switch (imageViewSrc) {
                case 2:
                    txtOrientationBefore.setText(fileImage.getName());
                    imgOrientationBefore.setImageBitmap(imageBitmap);
                    break;
                case 3:
                    txtOrientationEarthBefore.setText(fileImage.getName());
                    imgOrientationEarthBefore.setImageBitmap(imageBitmap);
                    break;
                case 4:
                    txtOrientationAfter.setText(fileImage.getName());
                    imgOrientationAfter.setImageBitmap(imageBitmap);
                    break;
                case 5:
                    txtOrientationEarthAfter.setText(fileImage.getName());
                    imgOrientationEarthAfter.setImageBitmap(imageBitmap);
                    break;
                default:
                    break;
            }
        } else if (requestCode == REQUEST_IMAGE_GALLERY && resultCode == RESULT_OK) {
            if (imageViewSrc == 1) {
                if (data != null) {
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(data.getData());
                        File file = File.createTempFile("gnet_", ".png", getFilesDir());
                        FileOutputStream out = new FileOutputStream(file);
                        Bitmap imageBitmap = BitmapFactory.decodeStream(inputStream);
                        imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                        imgGnetTrack.setImageBitmap(imageBitmap);
                        txtGnetTrack.setText(file.getName());
                    } catch (IOException e) {
                        Toast.makeText(EditSectorActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }
    //endregion
}