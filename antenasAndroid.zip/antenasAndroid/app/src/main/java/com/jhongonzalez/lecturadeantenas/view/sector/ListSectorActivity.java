package com.jhongonzalez.lecturadeantenas.view.sector;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jhongonzalez.lecturadeantenas.R;
import com.jhongonzalez.lecturadeantenas.adapters.GridSectorAdapter;
import com.jhongonzalez.lecturadeantenas.entities.Enb;
import com.jhongonzalez.lecturadeantenas.entities.Sector;

public class ListSectorActivity extends AppCompatActivity {

    //region Atributos
    /**
     * Adaptador de la tabla de regionales
     */
    private GridSectorAdapter gridSectorAdapter;

    /**
     * Enb al que pertenece el listado de sectores
     */
    private Enb enb;
    //endregion

    //region Métodos

    /**
     * Se ejecuta al iniciar la actividad
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_sector);
        enb = (Enb) getIntent().getSerializableExtra("enb");
        this.setTitle(getString(R.string.list_sectors, enb.getName()));
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView listSectors = findViewById(R.id.listSectors);
        FloatingActionButton fabAddSector = findViewById(R.id.fabAddSector);

        gridSectorAdapter = new GridSectorAdapter(this, enb);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        listSectors.setLayoutManager(mLayoutManager);
        listSectors.setItemAnimator(new DefaultItemAnimator());
        listSectors.setAdapter(gridSectorAdapter);

        fabAddSector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editSector = new Intent(ListSectorActivity.this, EditSectorActivity.class);
                Sector sector = new Sector();
                sector.setEnb(enb);
                editSector.putExtra("sector", sector);
                startActivity(editSector);
            }
        });
    }

    /**
     * Se ejecuta al volver de otra actividad a esta
     */
    @Override
    public void onResume() {
        super.onResume();
        gridSectorAdapter.update();
    }
    //endregion
}